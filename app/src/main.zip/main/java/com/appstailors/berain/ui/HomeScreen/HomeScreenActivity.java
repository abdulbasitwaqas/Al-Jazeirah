package com.appstailors.berain.ui.HomeScreen;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import androidx.viewpager.widget.ViewPager;
import androidx.appcompat.app.AppCompatActivity;

import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;


import com.appstailors.berain.AppController;
import com.appstailors.berain.R;
import com.appstailors.berain.UserSession;
import com.appstailors.berain.object.Areas;
import com.appstailors.berain.object.Cart;
import com.appstailors.berain.object.login.User;
import com.appstailors.berain.ui.LoginActivity;
import com.appstailors.berain.ui.CheckOutActivity;
import com.appstailors.berain.ui.fragment.FragmentHome;
import com.appstailors.berain.ui.fragment.FragmentMore;
import com.appstailors.berain.ui.fragment.FragmentOffers;

import com.appstailors.berain.ui.fragment.FragmentOrders;
import com.appstailors.berain.utils.BerainContextWrapper;
import com.appstailors.berain.utils.Constants;
import com.appstailors.berain.utils.CoreManager;
import com.appstailors.berain.utils.CustomViewPager;
import com.appstailors.berain.utils.ProductsSingleton;
import com.appstailors.berain.utils.ViewPager.ViewPagerAdapter;
import com.clevertap.android.sdk.CleverTapAPI;
import com.roam.appdatabase.DatabaseManager;


import java.util.ArrayList;
import java.util.Locale;

import io.github.inflationx.viewpump.ViewPumpContextWrapper;
import static com.appstailors.berain.utils.Constants.LOGINFROMCART;
import static com.appstailors.berain.utils.Constants.ORDERS_SCREEN;

public class HomeScreenActivity extends AppCompatActivity implements View.OnClickListener {

    private CustomViewPager viewPager;

    View tollview;
    TextView title;
    public   TextView basket_badge;
    private boolean isArabic;
    private View btn_product, btn_offer, btn_order, btn_more;
    TextView tvLogout;
    RelativeLayout rlbadgeView;
    User user=DatabaseManager.getInstance().getFirstOfClass(User.class);
    ProgressDialog mProgressDialog;
     Dialog dialogVersion;
    private ArrayList<Areas> allCityAreas=new ArrayList<>();
    Dialog dialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        isArabic = AppController.setLocale();
        setContentView(R.layout.activity_homescreen);
        setTollView();
        setViews();
        createViewPager();
    }

    private void setViews() {
        viewPager = findViewById(R.id.viewpager);
        viewPager.setEnableSwipe(true);
        ProductsSingleton.getInstance().setCustomViewPager(viewPager);
        CleverTapAPI.getDefaultInstance(HomeScreenActivity.this).pushEvent("Home Activity");
    }

    private void setTollView() {

        tollview = findViewById(R.id.toolbar);
        title = tollview.findViewById(R.id.tvToolbarTitle);
        View badge_view = tollview.findViewById(R.id.badge_view);

        basket_badge = tollview.findViewById(R.id.basket_badge);
        ProductsSingleton.getInstance().setBasket_badge(basket_badge);
        ProductsSingleton.getInstance().setBasketview(badge_view);
        btn_product = findViewById(R.id.view_product);
        btn_offer = findViewById(R.id.view_offers);
        btn_order = findViewById(R.id.view_orders);
        btn_more = findViewById(R.id.view_more);
        tvLogout=findViewById(R.id.tv_logout);
        tvLogout.setOnClickListener(this);
        rlbadgeView=findViewById(R.id.badge_view);

        basket_badge.setVisibility(View.GONE);
        badge_view.setVisibility(View.VISIBLE);
        btn_product.setOnClickListener(this);
        btn_offer.setOnClickListener(this);
        btn_order.setOnClickListener(this);
        btn_more.setOnClickListener(this);
        title.setText(getResources().getString(R.string.st_products));

        badge_view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                User user=DatabaseManager.getInstance().getFirstOfClass(User.class);
                if (user!=null){
                    if(Cart.getTotalItems()>=5) {
                        Intent intent = new Intent(getApplicationContext(), CheckOutActivity.class);
                        intent.putExtra("order", false);
                        startActivityForResult(intent, ORDERS_SCREEN);
                        overridePendingTransition(R.anim.enter_anim, 0);
                    }
                    }else {
                    Constants.fromcart=true;
                    Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                    startActivityForResult(intent,LOGINFROMCART);
                    overridePendingTransition(R.anim.enter_anim,0);
                }
            }
        });

 /*       if (user != null) {
            APIManager.getInstance().refreshToken(new APIManager.Callback() {
                @Override
                public void onResult(boolean z, String response) {
                    if (response.contains("Invalid Key!") || response.contains("Access denied!")) {
                        CoreManager.getInstance().removeUserData();


                        Intent intent=new Intent(getApplicationContext(),HomeScreenActivity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);
                    }

                    else{
                    if (z) {
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            if (jsonObject.optBoolean("status"))
                                user.authToken = jsonObject.optString("auth");
                            user.update();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
                }
            });
        }*/
  /*      APIManager.getInstance().getPopupPromo(new APIManager.Callback() {
            @Override
            public void onResult(boolean z, String response) {
                if (z) {
                    try {
                        if (response.contains("Invalid Key!") || response.contains("Access denied!")) {
                            CoreManager.getInstance().removeUserData();


                            Intent intent=new Intent(getApplicationContext(),HomeScreenActivity.class);
                            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                            startActivity(intent);
                        }
                        else{
                            PopupPromo.fromJson(new JSONObject(response).getJSONObject("rows"));
                            PopupPromo popupPromo = DatabaseManager.getInstance().getFirstOfClass(PopupPromo.class);
                            if (popupPromo.showPopup) {
                                //  setUpPopupPromoLayout(popupPromo);
                                showAlertDialog(popupPromo);
                            }
                        }

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        }, isArabic ? new Language("ar") : new Language("en"));*/

    }

    private void createViewPager() {
        ViewPagerAdapter adapter = new ViewPagerAdapter(getSupportFragmentManager());
        adapter.addFrag(new FragmentHome(), getResources().getString(R.string.products));
        adapter.addFrag(new FragmentOffers(), getResources().getString(R.string.offer));
        adapter.addFrag(new FragmentOrders(), getResources().getString(R.string.order));
        adapter.addFrag(new FragmentMore(), getResources().getString(R.string.more));

        viewPager.setAdapter(adapter);
        viewPager.setOffscreenPageLimit(3);
        AppController.getInstance().setViewPager_home(viewPager);

        setTabs();
        btn_product.setBackgroundResource(R.color.tab_selected);
        btn_offer.setBackgroundResource(R.color.transparent);
        btn_order.setBackgroundResource(R.color.transparent);
        btn_more.setBackgroundResource(R.color.transparent);
    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    private void setTabs() {
        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int i, float v, int i1) {

            }

            @Override
            public void onPageSelected(int i) {
                switch (i) {
                    case 0:
                        title.setText(getResources().getString(R.string.st_products));
                        btn_product.setBackgroundResource(R.color.tab_selected);
                        btn_offer.setBackgroundResource(R.color.transparent);
                        btn_order.setBackgroundResource(R.color.transparent);
                        btn_more.setBackgroundResource(R.color.transparent);
                        tvLogout.setVisibility(View.GONE);
                        rlbadgeView.setVisibility(View.VISIBLE);
                        break;
                    case 1:
                        title.setText(getResources().getString(R.string.offer));
                        btn_product.setBackgroundResource(R.color.transparent);
                        btn_offer.setBackgroundResource(R.color.tab_selected);
                        btn_order.setBackgroundResource(R.color.transparent);
                        btn_more.setBackgroundResource(R.color.transparent);


                        tvLogout.setVisibility(View.GONE);
                        rlbadgeView.setVisibility(View.VISIBLE);

                        break;
                    case 2:
                        User user=DatabaseManager.getInstance().getFirstOfClass(User.class);
                        if (user==null) {
                            Intent intent = new Intent(HomeScreenActivity.this, LoginActivity.class);
                            startActivityForResult(intent, ORDERS_SCREEN);
                            overridePendingTransition(R.anim.enter_anim, 0);
                        }
                        else {
                            viewPager.setCurrentItem(2);
                            btn_product.setBackgroundResource(R.color.transparent);
                            btn_offer.setBackgroundResource(R.color.transparent);
                            btn_order.setBackgroundResource(R.color.tab_selected);
                            btn_more.setBackgroundResource(R.color.transparent);
                            tvLogout.setVisibility(View.GONE);
                            rlbadgeView.setVisibility(View.VISIBLE);
                            title.setText(getResources().getString(R.string.st_orders));
                        }

//                        btn_product.setBackgroundResource(R.color.transparent);
//                        btn_offer.setBackgroundResource(R.color.transparent);
//                        btn_order.setBackgroundResource(R.color.tab_selected);
//                        btn_more.setBackgroundResource(R.color.transparent);
//                        tvLogout.setVisibility(View.GONE);
//                        rlbadgeView.setVisibility(View.VISIBLE);


                        break;
                    case 3:
                         user=DatabaseManager.getInstance().getFirstOfClass(User.class);
                        title.setText(getResources().getString(R.string.more));
                        btn_product.setBackgroundResource(R.color.transparent);
                        btn_offer.setBackgroundResource(R.color.transparent);
                        btn_order.setBackgroundResource(R.color.transparent);
                        btn_more.setBackgroundResource(R.color.tab_selected);
                        rlbadgeView.setVisibility(View.GONE);
                        if (user!=null)
                        tvLogout.setVisibility(View.VISIBLE);
                        break;

                }
            }

            @Override
            public void onPageScrollStateChanged(int i) {

            }
        });
    }

    /*private void showAlertDialog(PopupPromo promo) {

        dialog = new Dialog(HomeScreenActivity.this,R.style.Theme_AppCompat_Light_NoActionBar);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
        lp.copyFrom(dialog.getWindow().getAttributes());
        lp.width = WindowManager.LayoutParams.MATCH_PARENT;
        lp.height = WindowManager.LayoutParams.MATCH_PARENT;

        dialog.setContentView(R.layout.promo_popup_layout);
        ImageButton btnClose = dialog.findViewById(R.id.btnClose);
        ImageView popupImg = dialog.findViewById(R.id.popupImg);
        TextView txtPopupTitle = dialog.findViewById(R.id.txtPopupTitle);
        if (promo.title.trim().length() > 0) {
            txtPopupTitle.setText(promo.title);
            txtPopupTitle.setVisibility(View.VISIBLE);
        } else {
            txtPopupTitle.setVisibility(View.GONE);
        }
        if (promo.popupImage.trim().length() > 0) {
            CircularProgressDrawable cd = new CircularProgressDrawable(this);
            cd.setStrokeWidth(10f);
            cd.setCenterRadius(100f);
            cd.start();
            Glide.with(this)
                    .load(IMAGE_BASE_URL + promo.popupImage)
//                    .placeholder(R.drawable.loading_spinner)
                    .placeholder(cd)
//                    .override(100, 100)
                    .into(popupImg);
            popupImg.setVisibility(View.VISIBLE);
        }
        btnClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
                //   drawer.removeView(popupPromoContainer);

            }
        });

        dialog.show();
        dialog.getWindow().setAttributes(lp);

    }*/

  /*  private void setViewPager(){
        Log.d("viewPagerssss","0aaaaaa");
        user=DatabaseManager.getInstance().getFirstOfClass(User.class);
        if (user != null) {
            showProgress(true);
            APIManager.getInstance().refreshToken(new APIManager.Callback() {
                @Override
                public void onResult(boolean z, String response) {
                    if (z) {
                        try {
                            showProgress(false);
                            JSONObject jsonObject = new JSONObject(response);
                            if (jsonObject.optBoolean("status"))
                                user.authToken = jsonObject.optString("auth");
                            user.update();
                            createViewPager();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                    else {
                        showProgress(false);
                        createViewPager();
                    }
                }
            });
        }
        else{
            createViewPager();
        }
    }*/

    @Override
    protected void attachBaseContext(Context newBase) {
        Context context = BerainContextWrapper.wrap(newBase, new Locale(UserSession.getInstance().getUserLanguage()));
        super.attachBaseContext(ViewPumpContextWrapper.wrap(context));

    }


    @Override
    public void onClick(View view) {
        switch (view.getId()) {

            case R.id.view_product:
                viewPager.setCurrentItem(0);
                btn_product.setBackgroundResource(R.color.tab_selected);
                btn_offer.setBackgroundResource(R.color.transparent);
                btn_order.setBackgroundResource(R.color.transparent);
                btn_more.setBackgroundResource(R.color.transparent);
                tvLogout.setVisibility(View.GONE);
                rlbadgeView.setVisibility(View.VISIBLE);

                break;
            case R.id.view_offers:
                viewPager.setCurrentItem(1);
                btn_product.setBackgroundResource(R.color.transparent);
                btn_offer.setBackgroundResource(R.color.tab_selected);
                btn_order.setBackgroundResource(R.color.transparent);
                btn_more.setBackgroundResource(R.color.transparent);
                tvLogout.setVisibility(View.GONE);
                rlbadgeView.setVisibility(View.VISIBLE);
                break;
            case R.id.view_orders:
                User user=DatabaseManager.getInstance().getFirstOfClass(User.class);

                    if (user==null) {
                        Intent intent = new Intent(HomeScreenActivity.this, LoginActivity.class);
                        startActivityForResult(intent, ORDERS_SCREEN);
                        overridePendingTransition(R.anim.enter_anim, 0);
                    }
                else {
                        viewPager.setCurrentItem(2);
                        btn_product.setBackgroundResource(R.color.transparent);
                        btn_offer.setBackgroundResource(R.color.transparent);
                        btn_order.setBackgroundResource(R.color.tab_selected);
                        btn_more.setBackgroundResource(R.color.transparent);
                        tvLogout.setVisibility(View.GONE);
                        rlbadgeView.setVisibility(View.VISIBLE);
                    }
                break;
            case R.id.view_more:
                 user=DatabaseManager.getInstance().getFirstOfClass(User.class);
                viewPager.setCurrentItem(3);
                btn_product.setBackgroundResource(R.color.transparent);
                btn_offer.setBackgroundResource(R.color.transparent);
                btn_order.setBackgroundResource(R.color.transparent);
                btn_more.setBackgroundResource(R.color.tab_selected);
                if (user!=null)
                tvLogout.setVisibility(View.VISIBLE);
                rlbadgeView.setVisibility(View.GONE);
                break;

            case R.id.tv_logout:
                User user1=DatabaseManager.getInstance().getFirstOfClass(User.class);
                if (user1.hide_price.equals("1")){
                    CoreManager.getInstance().removeUserData();
                    Toast.makeText(this, ""+getResources().getString(R.string.logout), Toast.LENGTH_SHORT).show();
                    user=null;
                    UserSession.getInstance().setSaveHomeAddressObject("");
                    Intent intent=new Intent(getApplicationContext(),HomeScreenActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent);

                }else {
                    CoreManager.getInstance().removeUserData();
                    Toast.makeText(this, ""+getResources().getString(R.string.logout), Toast.LENGTH_SHORT).show();
                    user=null;
                    Intent intent=new Intent(getApplicationContext(),HomeScreenActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent);
                }



                break;

        }
    }

    @Override
    public void onBackPressed() {
        if (viewPager.getCurrentItem() == 0) {
            finish();
        } else {
            viewPager.setCurrentItem(0);
        }
    }

   /* private void setCompanySettings(){
        showProgress(true);

        APIManager.getInstance().getCompanySettings(new APIManager.Callback() {
            @Override
            public void onResult(boolean z, String response) {
                if (z) {
                    showProgress(false);
                    try {
                        if (response.contains("Invalid Key!") || response.contains("Access denied!")) {
                            CoreManager.getInstance().removeUserData();
                            Intent intent=new Intent(getApplicationContext(),HomeScreenActivity.class);
                            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                            startActivity(intent);
                        }
                        else{
                            CompanySetting.fromJson(new JSONObject(response).getJSONArray("rows"));
                            CompanySetting companySetting = DatabaseManager.getInstance().getFirstOfClass(CompanySetting.class);

                            int versionfromserver = Integer.parseInt(companySetting.curAndroidVer.replace(".",""));
                            int versionapp = Integer.parseInt(BuildConfig.VERSION_NAME.replace(".",""));
                            if(versionfromserver>versionapp){
                                openVersionDialog();
                            }
                            else{
                                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd HH:mm:ss");
                                SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

                                SimpleDateFormat sdf3 = new SimpleDateFormat("EEE MMM dd HH:mm:ss zzz yyyy", Locale.ENGLISH);

                                Date strDate = format.parse(companySetting.last_area_updated_date);
                                Date local_date = sdf3.parse(UserSession.getInstance().getDate());

                               Log.d("localdatee",""+strDate);
                               Log.d("localdatee",""+local_date);

                                if(companySetting.loadcityarea.equals("1")&& local_date.getTime() < strDate.getTime()){
                                    showProgress(true);
                                    CoreManager.getInstance().removeCityAreaData();
                                    CoreManager.getInstance().removeUserData();
                                    getCities();
                                }
                                else{
                                    isLocationEnabled();
                                }


                                if(user!=null){


                                    if(companySetting.delete_last_order_address==1&&
                                            UserSession.getInstance().getDeleteValue()!=companySetting.delete_last_order_address){
                                        UserSession.getInstance().setDeleteValue(companySetting.delete_last_order_address);
                                        UserSession.getInstance().destroyUserSession();
                                    }


                                    if(companySetting.delete_addresses==1 ){
                                        CoreManager.getInstance().removeUserAddresses();
                                    }

                                    if (!companySetting.feedback_order.equals("")){
                                        rattingAlertDialog(companySetting.feedback_order);
                                    }

                                }



                            }
                        }
                    } catch (Exception e) {
                        Log.e("Exceptin",e.toString());
                        e.printStackTrace();
                    }
                }
                else{
                    showProgress(false);
                    isLocationEnabled();
                    Toast.makeText(HomeScreenActivity.this, "Something went wrong try again", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }*/

   /* public void getCities() {
        APIManager.getInstance().getCities(new APIManager.Callback() {
            @Override
            public void onResult(boolean z, String response) {
                //  showProgress(false);
                if (z) {
                    try {
                        List<Cities> citiesList=new ArrayList<>();

                        JSONObject jsonObject = new JSONObject(response);
                        Cities.fromJson(jsonObject.getJSONArray("rows"));
                        JSONArray jsonArray = jsonObject.getJSONArray("rows");
                        for (int i = 0; i < jsonArray.length(); i++) {
                            citiesList = DatabaseManager.getInstance().getAllOfClass(Cities.class);
                        }
                        ProductsSingleton.getInstance().setCities(citiesList);
                        getCityArea();
                    } catch (Exception e) {
                        Log.e("EX_city",e.toString());
                        e.printStackTrace();
                    }
                }
            }
        });
    }

    public void getCityArea() {
        //showProgress(true);
        APIManager.getInstance().getCityArea(new APIManager.Callback() {
            @Override
            public void onResult(boolean z, String response) {

                // showProgress(false);
                if (z) {

                    allCityAreas = new ArrayList<>();
                    try {

                        JSONObject jsonObject = new JSONObject(response);
                        JSONArray jsonArray = jsonObject.getJSONArray("rows");
                        Areas.fromJson(jsonObject.getJSONArray("rows"));
                        allCityAreas = (ArrayList<Areas>) DatabaseManager.getInstance().getAllOfClass(Areas.class);
                        ProductsSingleton.getInstance().setCityAreas(allCityAreas);

                        Date c = Calendar.getInstance().getTime();
                       // SimpleDateFormat df = new SimpleDateFormat("yyyy-mm-dd HH:mm");
                        //String formattedDate = df.format(c);
                        UserSession.getInstance().setDate(c.toString()+"");
                        isLocationEnabled();
                        //changeCityAreas(position);
                    } catch (Exception e) {
                        Log.e("EX_area",e.toString());
                        e.printStackTrace();
                    }
                }
            }
        }  );
    }*/

/*
    private void openVersionDialog() {
        dialogVersion = new Dialog(this);
        dialogVersion.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialogVersion.setContentView(R.layout.version_dialog);
        TextView title = (TextView) dialogVersion.findViewById(R.id.title);
        title.setText(getResources().getString(R.string.update_version));
        TextView message = (TextView) dialogVersion.findViewById(R.id.message);
        message.setText(getResources().getString(R.string.update_version_msg));

        Button ok = (Button) dialogVersion.findViewById(R.id.okBtn);
        Button cancel = (Button) dialogVersion.findViewById(R.id.cancelBtn);
        dialogVersion.setCancelable(false);

        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + getPackageName())));
                } catch (android.content.ActivityNotFoundException anfe) {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + getPackageName())));
                }

            }
        });

        dialogVersion.show();
    }

    private void rattingAlertDialog(final String orderNumber) {
        final Dialog dialog = new Dialog(this);
        dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.setContentView(R.layout.ratting_alert_dialog);
        ImageView imageClose = dialog.findViewById(R.id.imageClose);
        TextView tvOrderTitle = dialog.findViewById(R.id.tvOrderTitle);
        final TextView tvSubmitRating = dialog.findViewById(R.id.tvSubmitRating);
        final RatingBar ratingYourSatisfaction = dialog.findViewById(R.id.ratingYourSatisfaction);
        final RatingBar ratingOverallEcperience = dialog.findViewById(R.id.ratingOverallEcperience);


        tvOrderTitle.setText(getResources().getString(R.string.st_orderarrived)+": "+orderNumber+"\n"+getResources().getString(R.string.st_rateorder));

        ratingYourSatisfaction.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {

            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating,
                                        boolean fromUser) {
                Log.d("rating",""+rating);
                if (rating>0 && ratingOverallEcperience.getRating()>0){
                    tvSubmitRating.setVisibility(View.VISIBLE);
                }else {
                    tvSubmitRating.setVisibility(View.GONE);
                }

            }
        });

        ratingOverallEcperience.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {

            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating,
                                        boolean fromUser) {
                if (rating>0 && ratingYourSatisfaction.getRating()>0){
                    tvSubmitRating.setVisibility(View.VISIBLE);
                }else {
                    tvSubmitRating.setVisibility(View.GONE);
                }
            }
        });


        tvSubmitRating.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Log.d("request body",""+new Gson().toJson(new RetingRequest(user.userId, orderNumber, ""+ratingOverallEcperience.getRating(),
                        ""+ratingYourSatisfaction.getRating(), "0")));

                showProgress(true);
                Log.d("ratings",""+ratingYourSatisfaction.getRating()+","+ratingOverallEcperience.getRating());

                APIManager.getInstance().saveOrderRating(new APIManager.Callback() {
                    @Override
                    public void onResult(boolean z, String response) {
                        showProgress(false);
                        try {
                            Toast.makeText(HomeScreenActivity.this, new JSONObject(response).getString("status"), Toast.LENGTH_SHORT).show();
                        } catch (Exception ex) {

                        }
                        dialog.dismiss();
                    }
                }, new RetingRequest(user.userId, orderNumber, ""+ratingOverallEcperience.getRating(), ""+ratingYourSatisfaction.getRating(), "0"));

            //dialog.dismiss();
            }
        });

        dialog.setCancelable(false);

        imageClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showProgress(true);
                APIManager.getInstance().saveOrderRating(new APIManager.Callback() {
                    @Override
                    public void onResult(boolean z, String response) {showProgress(false);
                        try {
                           // Toast.makeText(HomeScreenActivity.this, new JSONObject(response).getString("status"), Toast.LENGTH_SHORT).show();

                        } catch (Exception ex) {

                        }
                    }
                }, new RetingRequest(user.userId, orderNumber, "", "", "1"));


                dialog.dismiss();
            }
        });
        dialog.show();
    }
*/


    private void showProgress(boolean show) {
        if (show) {
            if (mProgressDialog != null && mProgressDialog.isShowing()) {
                mProgressDialog.dismiss();
            }
            mProgressDialog = new ProgressDialog(HomeScreenActivity.this);
            mProgressDialog.setMessage(getResources().getString(R.string.please_wait));
            mProgressDialog.setIndeterminate(false);
            mProgressDialog.setCancelable(false);
            mProgressDialog.show();
        } else {
            if (mProgressDialog != null && mProgressDialog.isShowing()) {
                mProgressDialog.dismiss();
            }
        }


    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if(dialogVersion!=null && dialogVersion.isShowing()){
            dialogVersion.dismiss();
        }

        if(dialog!=null && dialog.isShowing()){
            dialog.dismiss();
        }
        showProgress(false);
    }
}
