package com.appstailors.berain.object;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;
import com.roam.appdatabase.DatabaseManager;
import com.roam.appdatabase.managed.ManagedObject;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 */


@DatabaseTable
public class CompanySetting extends ManagedObject {
    @DatabaseField(defaultValue = "0")
    public int minOrder;

    @DatabaseField(defaultValue = "0")
    public int vat;


    @DatabaseField
    public String curAndroidVer;
    @DatabaseField
    public String is_ticket_enable;

    @DatabaseField(defaultValue = "")
    public String whats_app = "";
    @DatabaseField(defaultValue = "")
    public String helpLine="";
    @DatabaseField(defaultValue = "")
    public String email="";

    @DatabaseField(defaultValue = "1")
    public String sadadDelivery;
    @DatabaseField(defaultValue = "")
    public String stc_qitaf_msg_en;
    @DatabaseField(defaultValue = "")
    public String stc_qitaf_msg_ar;

    @DatabaseField(defaultValue = "")
    public String show_vat;

    @DatabaseField(defaultValue = "")
    public String enable_other_channels;

    public static void fromJson(JSONObject json) {
        DatabaseManager.getInstance().destroyAllForClass(CompanySetting.class);
        CompanySetting result = DatabaseManager.getInstance().getFirstOfClass(CompanySetting.class);
        boolean created = result == null;
        if (result == null) {
            result = new CompanySetting();
        }
        result.minOrder = json.optInt("min_order");
        result.vat = json.optInt("vat");
        result.helpLine = json.optString("help_line");
        result.sadadDelivery = json.optString("is_sadad_enable");
        result.curAndroidVer = json.optString("cur_android_ver");
        result.is_ticket_enable = json.optString("is_ticket_enable");
        result.stc_qitaf_msg_en = json.optString("stc_qitaf_msg_en");
        result.stc_qitaf_msg_ar = json.optString("stc_qitaf_msg_ar");
        result.show_vat = json.optString("show_vat");
        result.whats_app = json.optString("whats_app");
        result.email = json.optString("email");
        result.enable_other_channels = json.optString("enable_other_channels");
        if (created) result.create();
        else result.update();

    }
}
