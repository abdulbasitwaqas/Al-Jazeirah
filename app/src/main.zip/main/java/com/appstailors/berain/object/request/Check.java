package com.appstailors.berain.object.request;

import java.io.Serializable;

/**
 * Created by Mustanser Iqbal on 12/2/2017.
 */

public class Check implements Serializable {

    private String check = "headerinfo";
}
