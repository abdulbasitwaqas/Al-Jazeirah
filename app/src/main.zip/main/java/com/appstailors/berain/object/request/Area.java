package com.appstailors.berain.object.request;

/**
 * Created by Mustanser Iqbal on 12/7/2017.
 */

public class Area {
    String city_id;

    public Area() {

    }
}
