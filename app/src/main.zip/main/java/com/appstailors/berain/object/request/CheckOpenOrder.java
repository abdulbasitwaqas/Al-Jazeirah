package com.appstailors.berain.object.request;

public class CheckOpenOrder {
    private String client_id;

    public CheckOpenOrder(String client_id) {
        this.client_id = client_id;
    }
}
