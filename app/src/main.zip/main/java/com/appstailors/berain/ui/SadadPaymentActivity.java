/*
package com.appstailors.berain.ui;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.appstailors.berain.AppController;
import com.appstailors.berain.R;
import com.appstailors.berain.UserSession;
import com.appstailors.berain.object.Cart;
import com.appstailors.berain.object.CompanySetting;
import com.appstailors.berain.object.PlaceOrder;
import com.appstailors.berain.object.login.User;
import com.appstailors.berain.object.request.CheckOutWithPayment;
import com.appstailors.berain.object.request.CheckOutWithSadadID;
import com.appstailors.berain.utils.APIManager;
import com.appstailors.berain.utils.BerainContextWrapper;
import com.appstailors.berain.utils.Constants;
import com.edesign.stspayment.Approve.ApproveRequest;
import com.edesign.stspayment.Approve.ApproveResponse;
import com.edesign.stspayment.Approve.ApproveService;
import com.edesign.stspayment.Payment.PaymentRequest;
import com.edesign.stspayment.Payment.PaymentResponse;
import com.edesign.stspayment.Payment.PaymentService;
import com.google.gson.Gson;
import com.roam.appdatabase.DatabaseManager;

import org.json.JSONObject;

import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import static com.appstailors.berain.utils.Constants.AMOUNT;
import static com.appstailors.berain.utils.Constants.FINISH;
import static com.appstailors.berain.utils.Constants.ORDER_REFERENCE;
import static com.appstailors.berain.utils.Constants.PAYMENT_MFU;
import static com.appstailors.berain.utils.Constants.SADAD_SCREEN;
import static com.appstailors.berain.utils.Utils.convertString;

public class SadadPaymentActivity extends AppCompatActivity {

    private LinearLayout creditLayout, sadadLayout;
    private RelativeLayout rootView, webLayout;
    private EditText sadadId, cardNum, cardCVV, cardOwnerName;
    private String paymentMethod;
    private Double amount;
    private Spinner monthSpinner, yeasrSpinner;
    private boolean isArabic;
    private ProgressDialog mProgressDialog;
    double amountForTax;
    private WebView webView;
    private List<String> urls;
    String price;
    private String estnNo;
    private String mfuNo;
    private String authencationUrl, publicIp;
    private Map<String, String> sadatResponse;
    private ProgressBar progress_bar;
    PlaceOrder placeOrder;

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        isArabic = AppController.setLocale();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sdad_payment);

        if (isArabic) {
            getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        } else {
            getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        }


        placeOrder=new Gson().fromJson(getIntent().getStringExtra("placeorder"),PlaceOrder.class);

        Log.e("get",placeOrder.getAddressData().getOrd_address_id());

        CompanySetting companySetting = DatabaseManager.getInstance().getFirstOfClass(CompanySetting.class);

        TextView totalAmount = findViewById(R.id.sub_total);


        price = String.format("%.2f", Double.parseDouble(getIntent().getStringExtra("price")));

        price=convertString(price);
        totalAmount.setText(" : " +convertString(price));

        initToolBar();
        String months[] = {getResources().getString(R.string.january), getResources().getString(R.string.february),
                getResources().getString(R.string.march), getResources().getString(R.string.april),
                getResources().getString(R.string.may), getResources().getString(R.string.june),
                getResources().getString(R.string.july), getResources().getString(R.string.august), getResources().getString(R.string.september),
                getResources().getString(R.string.october), getResources().getString(R.string.november), getResources().getString(R.string.december)};

        String years[] = {
                getResources().getString(R.string.year_3),
                getResources().getString(R.string.year_4), getResources().getString(R.string.year_5),
                getResources().getString(R.string.year_6), getResources().getString(R.string.year_7),
                getResources().getString(R.string.year_8), getResources().getString(R.string.year_9),
                getResources().getString(R.string.year_10), getResources().getString(R.string.year_10),
                getResources().getString(R.string.year_12), getResources().getString(R.string.year_13)};


        webLayout = findViewById(R.id.web_layout);
        rootView = findViewById(R.id.rootView);
        webView = findViewById(R.id.webView);
        progress_bar = findViewById(R.id.progress_bar);


        sadadLayout = findViewById(R.id.sadadPayment_layout);
        creditLayout = findViewById(R.id.creditCard_layout);

        cardNum = findViewById(R.id.card_number);
        cardOwnerName = findViewById(R.id.card_holder_name);
        cardCVV = findViewById(R.id.card_cvv);

        sadadId = findViewById(R.id.sadad_id_et);

//        sadadId.setText("arun123");
        monthSpinner = findViewById(R.id.card_month);
        yeasrSpinner = findViewById(R.id.card_year);

        ArrayAdapter<String> spinnerArrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, months);
        spinnerArrayAdapter.setDropDownViewResource(R.layout.spinner_drop_down_item); // The drop down view
        monthSpinner.setAdapter(spinnerArrayAdapter);

        spinnerArrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, years);
        spinnerArrayAdapter.setDropDownViewResource(R.layout.spinner_drop_down_item); // The drop down view
        yeasrSpinner.setAdapter(spinnerArrayAdapter);

//        cardNum.setText("5271045423029111");
//        cardOwnerName.setText("Syed");
//        cardCVV.setText("123");
        findViewById(R.id.proceed_btn).setOnClickListener(new View.OnClickListener() {
            @SuppressLint("StaticFieldLeak")
            @Override
            public void onClick(View v) {

                showProgress(true);
                findViewById(R.id.proceed_btn).setEnabled(false);

                processPayment();
            }
        });

//        amountForTax = (Double.parseDouble("" + getIntent().getFloatExtra(AMOUNT, 0f)) * companySetting.vat) / 100;
        amountForTax = ((Double.parseDouble("" + getIntent().getFloatExtra(AMOUNT, 0f)) * companySetting.vat) / 100);
        amount = (Double.parseDouble("" + getIntent().getFloatExtra(AMOUNT, 0f)) + amountForTax);

        paymentMethod = "" + (getIntent().getIntExtra("payment_type",0));


        if (paymentMethod.equals("1")) {
            creditLayout.setVisibility(View.VISIBLE);
            sadadLayout.setVisibility(View.GONE);
        } else {
            creditLayout.setVisibility(View.GONE);
            sadadLayout.setVisibility(View.VISIBLE);
        }

        showProgress(true);
        APIManager.getInstance().getUserPublicIp(new APIManager.Callback() {
            @Override
            public void onResult(boolean z, String response) {
                showProgress(false);
                if (z) {
                    publicIp = response.replace("\n", "");
                    Log.e("Test",publicIp);
                }
                else {
                    Log.e("Test","...........");

                }
            }

        });
    }


    private void initToolBar() {
        View mToolbar =findViewById(R.id.toolbar);
        TextView title=mToolbar.findViewById(R.id.tvToolbarTitle);
        ImageView iv_backbtn=mToolbar.findViewById(R.id.imageViewBack);
        iv_backbtn.setVisibility(View.VISIBLE);
        iv_backbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        if(isArabic){
            title.setText("بيانات الدفع");
        }
        else {
            title.setText("Payment Details");
        }


    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {

            case android.R.id.home: {
                setResult(Activity.RESULT_OK);
                SadadPaymentActivity.this.finish();
                break;
            }
        }
        return super.onOptionsItemSelected(item);
    }

    private void processPayment() {

        String itemId = "88";

        // staging key : OWE1Njc0YzQyMDRhODQwNmMyM2IxMmY0
        // live key : YTQzM2I0NWMyNDE0Y2QzY2QyMzc0YmZj
        // staging MerchantID: 0001000002
        // live MerchantID: 0010000058

        final PaymentRequest request = new PaymentRequest();
        request.setPaymentAuthenticationToken("AuthenticationToken", "YTQzM2I0NWMyNDE0Y2QzY2QyMzc0YmZj");
        request.isLogging(true);
        request.setPaymentType("smartRoute");
        request.add("MessageID", "9");
            String transactionId=String.valueOf(System.currentTimeMillis())+"";
        request.add("TransactionID", transactionId);
        Log.e("TransactionId",transactionId);
        request.add("MerchantID", "0010000058");

        Double amou= ((Double.parseDouble(price)) );

        amou=amou* 100;
        amou=Math.ceil(amou);
        String am=amou+"";
        Double aDouble=new Double(am);
        int int_amount=aDouble.intValue();
        request.add("Amount", "" + int_amount);
        request.add("CurrencyISOCode", "682");
        request.add("PaymentMethod", paymentMethod);
        if (paymentMethod.equals("1")) {
            String year = yeasrSpinner.getSelectedItem().toString();
            request.add("ExpiryDateYear", year.substring(year.length() - 2, year.length()));
            int month = (monthSpinner.getSelectedItemPosition() + 1);
            request.add("ExpiryDateMonth", month < 10 ? "0" + month : "" + month);
            request.add("CardHolderName", cardOwnerName.getText().toString());
            request.add("CardNumber", cardNum.getText().toString());
            request.add("SecurityCode", cardCVV.getText().toString());
        } else if (paymentMethod.equals("2")) {
            request.add("SadadOlpId", sadadId.getText().toString());
            request.add("mfu", PAYMENT_MFU);
        }
        request.add("ItemID", itemId);
        request.add("ClientIPaddress", "" + ""+publicIp);
//        request.add("ClientIPaddress", "39.51.221.228");
        request.add("Channel", "0");
        request.add("FrameworkInfo", "10.0");

        Handler handler = new Handler();
        save_temp_order_payment(transactionId);
        final Runnable r = new Runnable() {
            public void run() {
                parsePaymentResponse(request);
            }
        };
        handler.postDelayed(r, 2000);
    }

    private void parsePaymentResponse(PaymentRequest request) {
        PaymentService service = new PaymentService(this);
        PaymentResponse response = service.process(request);

        if (response.get("execCode").equals("0")) {
            Log.e("STATUS",response.get("Response.StatusCode"));
            if (paymentMethod.equals("1") && response.get("Response.StatusCode").equals("00000")) {
                sadatResponse = response.getResponse();
                placeOrderWithCreditCardInfo();
            } else if (paymentMethod.equals("2") && response.get("Response.StatusCode").equals("20002")) {

                sadatResponse = response.getResponse();
                estnNo = response.get("Response.estn");
                mfuNo = response.get("Response.mfu");
                authencationUrl = response.get("Response.AuthenticationURL");
                // check if sadad paramters are in the response then we need to create sadad webview
                if (estnNo != null && authencationUrl != null && mfuNo != null) {
                    //      Intent intent = new Intent(SmartRoutePaymentActivity.this, WebViewTest.class);

                    //intent.putExtra("Estn", estnNo);
                    //intent.putExtra("AuthenticationURL", authencationUrl);
                    //intent.putExtra("Mfu", mfuNo);
                    //intent.putExtra("smartRouteMap", (Serializable) response.getResponse());
                    Log.d("Estn", estnNo);
                    Log.d("AuthenticationURL", authencationUrl);
                    Log.d("Mfu", mfuNo);
                    // startActivity(intent);
                    webLayout.setVisibility(View.VISIBLE);
                    rootView.setVisibility(View.GONE);
                    startWebView(authencationUrl + "?estn=" + estnNo + "&mfu=" + mfuNo);
                    showProgress(false);
                    findViewById(R.id.proceed_btn).setEnabled(true);
                }
            } else {
                showProgress(false);
                findViewById(R.id.proceed_btn).setEnabled(true);
                Toast.makeText(SadadPaymentActivity.this, response.get("Response.StatusDescription"), Toast.LENGTH_LONG).show();
            }
        } else {
            findViewById(R.id.proceed_btn).setEnabled(true);
            showProgress(false);
        }

    }

       private void save_temp_order_payment(String transactionId) {
           User user = DatabaseManager.getInstance().getFirstOfClass(User.class);
           CheckOutWithSadadID checkOut = new CheckOutWithSadadID();
           checkOut.setUserId(user.userId);
           List<Cart> cartList = DatabaseManager.getInstance().getAllOfClass(Cart.class);
           List<CheckOutWithSadadID.Cart> cartItems = new ArrayList<>();
           for (Cart userCart : cartList) {
               CheckOutWithSadadID.Cart cart = new CheckOutWithSadadID.Cart();
               cart.setCount(userCart.count);
               cart.setDishId(userCart.productId);
               cart.setPrice(("" + userCart.amount));
               cartItems.add(cart);
           }
           CompanySetting companySetting = DatabaseManager.getInstance().getFirstOfClass(CompanySetting.class);
           checkOut.setPayment_type("" + placeOrder.getPayment_type());
           checkOut.setAmount_vat("" + placeOrder.getAmount_vat());
           checkOut.setPrice_without_vat(placeOrder.getPrice_without_vat());
           checkOut.setReferral(placeOrder.getReferral());
           checkOut.setPayment_type(placeOrder.getPayment_type());
           checkOut.setPrefered_date(placeOrder.getPrefered_date());
           checkOut.setPrefered_time(placeOrder.getPrefered_time());
           checkOut.setInclude_wallet(placeOrder.getInclude_wallet());
           checkOut.setPromocode(placeOrder.getPromocode());
           checkOut.setStc_otp(placeOrder.getStc_otp());
           CheckOutWithSadadID.AddressData addressData = new CheckOutWithSadadID.AddressData();
           addressData.setAdd_area(placeOrder.getAddressData().getAdd_area());
           addressData.setAdd_detail(placeOrder.getAddressData().getAdd_detail());
           addressData.setAdd_latitude(placeOrder.getAddressData().getAdd_latitude());
           addressData.setAdd_longitude(placeOrder.getAddressData().getAdd_longitude());
           addressData.setAdd_name(placeOrder.getAddressData().getAdd_name());
           addressData.setAdd_street_name(placeOrder.getAddressData().getAdd_street_name());
           addressData.setOrd_address_id(placeOrder.getAddressData().getOrd_address_id());
           checkOut.setAddressData(addressData);
           checkOut.setRecurring(placeOrder.getRecurring());
            checkOut.setTransactionID(transactionId);
            checkOut.setFoc_items(placeOrder.getFoc_items());
           Log.e("Request", new Gson().toJson(checkOut));

           checkOut.setCart(cartItems);
        if (user != null) {
            showProgress(true);
            APIManager.getInstance().save_temp_order_payment(new APIManager.Callback() {
                @Override
                public void onResult(boolean z, String response) {

                    if (z) {


                    } else {
                    }


                }
            }, checkOut);
        }
    }

    private boolean showProgress(boolean show) {
        if (show) {
            if (mProgressDialog != null && mProgressDialog.isShowing()) {
                mProgressDialog.dismiss();
            }
            mProgressDialog = new ProgressDialog(this);
            mProgressDialog.setMessage(getResources().getString(R.string.please_wait));
            mProgressDialog.setIndeterminate(false);
            mProgressDialog.setCancelable(false);
            mProgressDialog.show();
            return true;
        } else {
            if (mProgressDialog != null && mProgressDialog.isShowing()) {
                mProgressDialog.dismiss();
            }
            return true;
        }
    }

    private void placeOrderWithCreditCardInfo() {
        User user = DatabaseManager.getInstance().getFirstOfClass(User.class);
        CheckOutWithPayment checkOut;
        checkOut = new CheckOutWithPayment();
        checkOut.setUserId(user.userId);

        List<Cart> cartList = DatabaseManager.getInstance().getAllOfClass(Cart.class);
        List<CheckOutWithPayment.Cart> cartItems = new ArrayList<>();
        for (Cart userCart : cartList) {
            CheckOutWithPayment.Cart cart = new CheckOutWithPayment.Cart();
            cart.setCount(userCart.count);
            cart.setDishId(userCart.productId);
            cart.setPrice(("" + userCart.amount));
            cartItems.add(cart);
        }
        CompanySetting companySetting = DatabaseManager.getInstance().getFirstOfClass(CompanySetting.class);
        checkOut.setPayment_type("" + placeOrder.getPayment_type());
        checkOut.setAmount_vat("" + placeOrder.getAmount_vat());
        checkOut.setPrice_without_vat(placeOrder.getPrice_without_vat());
        checkOut.setReferral(placeOrder.getReferral());
        checkOut.setPayment_type(placeOrder.getPayment_type());
        checkOut.setPrefered_date(placeOrder.getPrefered_date());
        checkOut.setPrefered_time(placeOrder.getPrefered_time());
        checkOut.setInclude_wallet(placeOrder.getInclude_wallet());
        checkOut.setPromocode(placeOrder.getPromocode());
        checkOut.setStc_otp(placeOrder.getStc_otp());
        checkOut.setRecurring(placeOrder.getRecurring());


        CheckOutWithPayment.AddressData addressData = new CheckOutWithPayment.AddressData();
        addressData.setAdd_area(placeOrder.getAddressData().getAdd_area());
        addressData.setAdd_detail(placeOrder.getAddressData().getAdd_detail());
        addressData.setAdd_latitude(placeOrder.getAddressData().getAdd_latitude());
        addressData.setAdd_longitude(placeOrder.getAddressData().getAdd_longitude());
        addressData.setAdd_name(placeOrder.getAddressData().getAdd_name());
        addressData.setAdd_street_name(placeOrder.getAddressData().getAdd_street_name());
        addressData.setOrd_address_id(placeOrder.getAddressData().getOrd_address_id());
        checkOut.setAddressData(addressData);
        checkOut.setFoc_items(placeOrder.getFoc_items());
        checkOut.setResponse(Constants.getSadadCardResponse(sadatResponse));
        Log.e("Request", new Gson().toJson(checkOut));

        final double amountForTax = (Double.parseDouble("" + Cart.getTotalPrice()) * companySetting.vat) / 100;
//        SadadCardResponse sadadCardResponse = new SadadCardResponse();
//        sadadCardResponse.setTransactionID(sadatResponse.get("Response.TransactionID"));
//        checkOut.setResponse(sadadCardResponse);


//        if (getIntent().getIntExtra(PAYMENT_METHOD, 0) == 2) {
 //   checkOut.setResponse(Constants.getSadadCardResponse(sadatResponse));
//        } else if (getIntent().getIntExtra(PAYMENT_METHOD, 0) == 3) {
//            SadadCardResponse sadadCardResponse = new SadadCardResponse();
//            sadadCardResponse.setTransactionID(sadatResponse.get("Response.TransactionID"));
//            checkOut.setResponse(sadadCardResponse);
//        }

        checkOut.setCart(cartItems);
        String res = checkOut.toString();
        APIManager.getInstance().placeOrderByCreditCard(new APIManager.Callback() {
            @Override
            public void onResult(boolean z, String response) {
                showProgress(false);
                if (z) {

                    try {
                        Log.e("RESPONSE",sadatResponse.get("Response.TransactionID"));
                        if(response.contains("address_id")){
                            Intent intent=new Intent(SadadPaymentActivity.this,SuccessfullOrder.class);
                            intent.putExtra("address_id",new JSONObject(response).getString("address_id"));
                            intent.putExtra("id",new JSONObject(response).getString("id"));
                            intent.putExtra(AMOUNT, Cart.getFormattedAmount(Double.parseDouble("" + Cart.getTotalPrice()) + amountForTax));
                            intent.putExtra(ORDER_REFERENCE, sadatResponse.get("Response.TransactionID"));
                            intent.putExtra("amount_Vat", amountForTax+"");
                            intent.putExtra("amount_withoutVat", String.valueOf(Cart.getTotalPrice()));
                            intent.putExtra("cc",true);


                            startActivity(intent);
                            finish();
                            overridePendingTransition(R.anim.enter_anim,0);
                        }



                    } catch (Exception e) {
                        Log.e("Ex",e.toString());
                        e.printStackTrace();
                        findViewById(R.id.proceed_btn).setEnabled(true);
                    }
                } else {
                    findViewById(R.id.proceed_btn).setEnabled(true);
                }
            }
        }, checkOut);
    }

    private void placeOrderBySadadId() {

        User user = DatabaseManager.getInstance().getFirstOfClass(User.class);
        CheckOutWithSadadID checkOut = new CheckOutWithSadadID();


        checkOut.setUserId(user.userId);

        List<Cart> cartList = DatabaseManager.getInstance().getAllOfClass(Cart.class);
        List<CheckOutWithSadadID.Cart> cartItems = new ArrayList<>();
        for (Cart userCart : cartList) {
            CheckOutWithSadadID.Cart cart = new CheckOutWithSadadID.Cart();
            cart.setCount(userCart.count);
            cart.setDishId(userCart.productId);
            cart.setPrice(("" + userCart.amount));
            cartItems.add(cart);
        }
        CompanySetting companySetting = DatabaseManager.getInstance().getFirstOfClass(CompanySetting.class);
        checkOut.setPayment_type("" + placeOrder.getPayment_type());
        checkOut.setAmount_vat("" + placeOrder.getAmount_vat());
        checkOut.setPrice_without_vat(placeOrder.getPrice_without_vat());
        checkOut.setReferral(placeOrder.getReferral());
        checkOut.setPayment_type(placeOrder.getPayment_type());
        checkOut.setPrefered_date(placeOrder.getPrefered_date());
        checkOut.setPrefered_time(placeOrder.getPrefered_time());
        checkOut.setInclude_wallet(placeOrder.getInclude_wallet());
        checkOut.setPromocode(placeOrder.getPromocode());
        CheckOutWithSadadID.AddressData addressData = new CheckOutWithSadadID.AddressData();
        addressData.setAdd_area(placeOrder.getAddressData().getAdd_area());
        addressData.setAdd_detail(placeOrder.getAddressData().getAdd_detail());
        addressData.setAdd_latitude(placeOrder.getAddressData().getAdd_latitude());
        addressData.setAdd_longitude(placeOrder.getAddressData().getAdd_longitude());
        addressData.setAdd_name(placeOrder.getAddressData().getAdd_name());
        addressData.setAdd_street_name(placeOrder.getAddressData().getAdd_street_name());
        addressData.setOrd_address_id(placeOrder.getAddressData().getOrd_address_id());
        checkOut.setAddressData(addressData);
        checkOut.setRecurring(placeOrder.getRecurring());
        checkOut.setFoc_items(placeOrder.getFoc_items());
        checkOut.setResponse(Constants.getSadadIdResponse(sadatResponse));
        checkOut.setCart(cartItems);
        final double amountForTax = (Double.parseDouble("" + Cart.getTotalPrice()) * companySetting.vat) / 100;
        Log.e("Request", new Gson().toJson(checkOut));

        APIManager.getInstance().placeOrderBySadadId(new APIManager.Callback() {
            @Override
            public void onResult(boolean z, String response) {
                showProgress(false);
                if (z) {

                    try {
                        if(response.contains("address_id")) {
                            Intent intent = new Intent(SadadPaymentActivity.this, SuccessfullOrder.class);

                            intent.putExtra("address_id", new JSONObject(response).getString("address_id"));
                            intent.putExtra("id", new JSONObject(response).getString("id"));
                            intent.putExtra(AMOUNT, Cart.getFormattedAmount(Double.parseDouble("" + Cart.getTotalPrice()) + amountForTax));
                            intent.putExtra(ORDER_REFERENCE, sadatResponse.get("Response.TransactionID"));
                            intent.putExtra("amount_Vat", amountForTax + "");
                            intent.putExtra("amount_withoutVat", String.valueOf(Cart.getTotalPrice()));
                            intent.putExtra("cc", true);


                            startActivityForResult(intent, SADAD_SCREEN);
                            finish();
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                } else {
                    findViewById(R.id.proceed_btn).setEnabled(true);
                }
            }
        }, checkOut);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {

        if (requestCode == SADAD_SCREEN) {
            if (resultCode == RESULT_OK) {
                if (data != null && data.hasExtra(FINISH)) {
                    setResult(RESULT_OK, data);
                    finish();
                }
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    protected void attachBaseContext(Context newBase) {
        Context context = BerainContextWrapper.wrap(newBase, new Locale(UserSession.getInstance().getUserLanguage()));
        super.attachBaseContext(ViewPumpContextWrapper.wrap(context));
    }


    private void startWebView(String url) {
        webView.setWebViewClient(new WebViewClient());       // Javascript enabled on webview
        webView.getSettings().setJavaScriptEnabled(true);
        //Load url in webview
        webView.loadUrl(url);
        final AlertDialog alertDialog = new AlertDialog.Builder(this).create();
        Log.d("sts-SDK", "Sratrtin Webview :" + url);
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                progress_bar.setVisibility(View.VISIBLE);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                progress_bar.setVisibility(View.GONE);
                try {
//                    Intent intent = getIntent();
//                    String mfu = intent.getStringExtra("Mfu");
                    String estn = null;
                    urls = new ArrayList<String>();
                    Log.d("sts-SDK", "your current url when webpage loading.. finish" + url);
                    urls.add(url);
                    if (url != null && mfuNo != null && url.startsWith(mfuNo)) {
                        String queryString = urls.get(urls.size() - 1).substring(urls.get(urls.size() - 1).lastIndexOf("?") + 1);
                        try {
                            Map<String, String> requestMap = convertToHashMap(queryString);
                            estn = requestMap.get("estn");
                        } catch (Exception e) {
                            Log.e("sts-SDK", "Exception at preparing request" + Log.getStackTraceString(e));
                        }
                    }
                    super.onPageFinished(view, url);
//                    Intent recievedIntent = getIntent();
                    if (estn != null && !("").equals(estn)) {
                        approveRequest(estn);
                    }
                } catch (Exception e) {
                    Log.e("sts-SDK", Log.getStackTraceString(e));
                }
            }

            @Override
            public void onLoadResource(WebView view, String url) {                 // TODO Auto-generated method stub
                super.onLoadResource(view, url);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                System.out.println("URL when you click on any link on webview:-" + url);
                return super.shouldOverrideUrlLoading(view, url);
            }

            @Override
            public void onReceivedError(WebView view, int errorCode, String
                    description, String failingUrl) {
                try {

                    progress_bar.setVisibility(View.GONE);
                    alertDialog.setTitle("Error");
                    alertDialog.setMessage(description);
                    alertDialog.setButton(DialogInterface.BUTTON_POSITIVE, "OK", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            return;
                        }
                    });
                    alertDialog.show();

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

    }


    Map<String, String> convertToHashMap(String src) throws Exception {
        Map<String, String> query_pairs = new LinkedHashMap<String, String>();
        String[] pairs = src.split("&");
        for (String pair : pairs) {
            int idx = pair.indexOf("=");
            query_pairs.put(URLDecoder.decode(pair.substring(0, idx), "UTF-8"), URLDecoder.decode(pair.substring(idx + 1), "UTF-8"));
        }
        return query_pairs;
    }

    private void approveRequest(String estn) {
        if (showProgress(true)) {

            webLayout.setVisibility(View.VISIBLE);
            rootView.setVisibility(View.GONE);

            ApproveRequest approveRequest = new ApproveRequest();
            approveRequest.setPaymentType("smartRoute");
            approveRequest.isLogging(true);
            approveRequest.setPaymentAuthenticationToken("AuthenticationToken", "YTQzM2I0NWMyNDE0Y2QzY2QyMzc0YmZj");
            approveRequest.add("PaymentMethod", "2");
            approveRequest.add("MerchantID", "0010000058");
            approveRequest.add("MessageID", "10");
            approveRequest.add("TransactionID", sadatResponse.get("Response.TransactionID"));
            approveRequest.add("estn", estn);

            ApproveService approveService = new ApproveService(this);
            ApproveResponse approveResponse = approveService.process(approveRequest);
            if (approveResponse.getResponse() != null) {
                sadatResponse = approveResponse.getResponse();
                if (sadatResponse.get("Response.StatusCode").equals("10008")) {
                    showProgress(false);
                    webLayout.setVisibility(View.GONE);
                    rootView.setVisibility(View.VISIBLE);
//                    creditLayout.setVisibility(View.GONE);
//                    sadadLayout.setVisibility(View.VISIBLE);
                } else {
                    placeOrderBySadadId();
                }
            } else {
                showProgress(false);
            }
        }
    }

    public String getLocalIpAddress() {
        try {
            for (Enumeration<NetworkInterface> en = NetworkInterface.getNetworkInterfaces();
                 en.hasMoreElements(); ) {
                NetworkInterface intf = en.nextElement();
                for (Enumeration<InetAddress> enumIpAddr = intf.getInetAddresses(); enumIpAddr.hasMoreElements(); ) {
                    InetAddress inetAddress = enumIpAddr.nextElement();
                    if (!inetAddress.isLoopbackAddress()) {
                        return inetAddress.getHostAddress();
                    }
                }
            }
        } catch (Exception ex) {
            Log.e("IP Address", ex.toString());
        }
        return null;
    }
}
*/
