package com.appstailors.berain.object.request;

public class Language {
    private String lang;

    public Language(String lang) {
        this.lang = lang;
    }

}
