package com.appstailors.berain;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.preference.PreferenceManager;

public class UserSession {
    private static final UserSession instance = new UserSession();
    private SharedPreferences sp;
    private Editor spEditor;


    public static synchronized UserSession getInstance() {
        return instance;
    }

    public void setContext(Context context) {
        this.sp = PreferenceManager.getDefaultSharedPreferences(context);
    }

    public UserSession(Context context) {
        this.sp = PreferenceManager.getDefaultSharedPreferences(context);
    }

    public UserSession() {
    }

    public boolean setUserLanguage(String language) {
        spEditor = sp.edit();
        spEditor.putString("user_language", language);
        spEditor.commit();
        return true;
    }

    public String getUserLanguage() {
        return sp.getString("user_language", "ar");
    }


    public boolean setStartDate(String startDate) {
        spEditor = sp.edit();
        spEditor.putString("login_startDate", startDate);
        spEditor.commit();
        return true;
    }

    public String getStartDate() {
        return sp.getString("login_startDate", "");
    }

    public String getCityId() {
        return sp.getString("city_id", "0");
    }

    public boolean setToken(String language) {
        spEditor = sp.edit();
        spEditor.putString("token", language);
        spEditor.commit();
        return true;
    }

    public String getToken() {
        return sp.getString("token", "");
    }

    public boolean setLastAreaUpdatedDate(String token) {
        spEditor = sp.edit();
        spEditor.putString("LastAreaUpdatedDate", token);
        spEditor.commit();
        return true;
    }
    public String getLastAreaUpdatedDate() {
        return sp.getString("LastAreaUpdatedDate", "");
    }

    public boolean setSaveHomeAddressObject(String addressObject) {
        spEditor = sp.edit();
        spEditor.putString("addressObject", addressObject);
        spEditor.commit();
        return true;
    }
    public String getSaveAddressObject() {
        return sp.getString("addressObject", "");
    }

}
