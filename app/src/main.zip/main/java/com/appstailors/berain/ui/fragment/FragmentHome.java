package com.appstailors.berain.ui.fragment;


import android.Manifest;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.appsflyer.AFInAppEventParameterName;
import com.appstailors.berain.object.request.ProductsRequest;
import com.clevertap.android.sdk.CleverTapAPI;
import com.google.android.material.tabs.TabLayout;
import androidx.fragment.app.Fragment;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.appstailors.berain.AppController;
import com.appstailors.berain.R;
import com.appstailors.berain.UserSession;
import com.appstailors.berain.object.Cart;
import com.appstailors.berain.object.CompanySetting;
import com.appstailors.berain.object.ProductByLocation;
import com.appstailors.berain.object.Promotions.Promotion;
import com.appstailors.berain.object.login.User;
import com.appstailors.berain.ui.AddAddressActivity;
import com.appstailors.berain.ui.ChooseAddressActivity;
import com.appstailors.berain.ui.HomeScreen.HomeScreenActivity;
import com.appstailors.berain.ui.LoginActivity;
import com.appstailors.berain.ui.CheckOutActivity;
import com.appstailors.berain.utils.APIManager;
import com.appstailors.berain.utils.Constants;
import com.appstailors.berain.utils.CoreManager;
import com.appstailors.berain.utils.CustomViewPager;
import com.appstailors.berain.utils.ProductsSingleton;
import com.appstailors.berain.utils.ViewPager.ViewPagerAdapter;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.roam.appdatabase.DatabaseManager;
import com.squareup.picasso.Picasso;
import com.viewpagerindicator.CirclePageIndicator;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

import static com.appstailors.berain.utils.Constants.LOGINFROMCART;
import static com.appstailors.berain.utils.Constants.ORDERS_SCREEN;
import static com.appstailors.berain.utils.Constants.PROMO_BASE_URL;
import static com.appstailors.berain.utils.Constants.fromcart;
import static com.appstailors.berain.utils.Constants.special_promotion;

/**
 * A simple {@link Fragment} subclass.
 */
public class FragmentHome extends Fragment implements View.OnClickListener{
    private View rootView;
    private boolean isArabic;

    private TabLayout tabs;
    private CustomViewPager viewpager_products;
    int currentPage = 0;
    int NUM_PAGES = 0;
    ViewPager viewPagerSlider;

    private View cartview;
    FrameLayout flSlider;
    public static Fragment getInstance() {
        return new FragmentHome();
    }
    CirclePageIndicator indicator;

    private ProgressDialog mProgressDialog;
    public TextView textview_location,tv_show_vat;
    private static final int REQUEST_FOR_ADDRESS = 11;
    CountDownTimer countDownTimer;
    Dialog dialog;
    boolean checkaddress=false;
    Gson gson;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        isArabic = AppController.setLocale();
        rootView = getLayoutInflater().inflate(R.layout.fragment_homes, container, false);
        if (isArabic) {
            getActivity().getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        } else {
            getActivity(). getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        }
        createGson();
        setViews();

     /*   String s ="{\"id\":\"8ac7a4a17338137b017351e3bbed750f\",\"paymentType\":\"DB\",\"paymentBrand\":\"VISA\",\"amount\":\"243.47\",\"currency\":\"SAR\",\"descriptor\":\"6088.5463.2297 berain\",\"merchantTransactionId\":\"5f0ed1bf9ddb6331945\",\"result\":{\"code\":\"000.100.110\",\"description\":\"Request successfully processed in 'Merchant in Integrator Test Mode'\"},\"resultDetails\":{\"CscResultCode\":\"Unsupported\",\"TransactionIdentfier\":\"1234567890123456789\",\"ConnectorTxID1\":\"8ac7a4a17338137b017351e3bbed750f\",\"connectorId\":\"540\",\"VerStatus\":\"E\",\"BatchNo\":\"20111101\",\"endToEndId\":\"26233508514971\",\"AuthorizeId\":\"061452\",\"AvsResultCode\":\"Unsupported\"},\"card\":{\"bin\":\"411111\",\"binCountry\":\"US\",\"last4Digits\":\"1111\",\"expiryMonth\":\"05\",\"expiryYear\":\"2022\"},\"customer\":{\"ip\":\"37.111.134.236\",\"ipCountry\":\"PK\"},\"customParameters\":{\"SHOPPER_MSDKIntegrationType\":\"Checkout UI\",\"SHOPPER_device\":\"Xiaomi xiaomi Redmi Note 8\",\"CTPE_DESCRIPTOR_TEMPLATE\":\"\",\"SHOPPER_OS\":\"Android 9\",\"SHOPPER_MSDKVersion\":\"2.39.0\"},\"risk\":{\"score\":\"100\"},\"buildNumber\":\"27bb71f973af47fd04e9da0b91cbe1abe4230da0@2020-07-14 09:27:59 +0000\",\"timestamp\":\"2020-07-15 09:52:38+0000\",\"ndc\":\"129E65CD9E2394873DAF34AA16EA47E0.uat01-vm-tx03\"}";
        try {
            Log.d("responsssss", String.valueOf(new JSONObject(s)));
        } catch (JSONException e) {
            e.printStackTrace();
        }*/


        return rootView;
    }

    private void setViews() {
        viewPagerSlider=rootView.findViewById(R.id.productsNew_viewPagerSlider);
        tabs = rootView.findViewById(R.id.tabs);
        viewpager_products = rootView.findViewById(R.id.viewpager_products);
        textview_location = rootView.findViewById(R.id.textview_location);
        tv_show_vat = rootView.findViewById(R.id.tv_show_vat);
        cartview=rootView.findViewById(R.id.cartview);
        flSlider=rootView.findViewById(R.id.fragmentHome_flSlider);
        TextView tv_cartamount=rootView.findViewById(R.id.tv_cartamount);
        indicator=rootView.findViewById(R.id.productsNew_sliderIndicator);
        ProductsSingleton.getInstance().setCartView(cartview);
        ProductsSingleton.getInstance().setTv_cartamount(tv_cartamount);
        cartview.setVisibility(View.GONE);
        ProductsSingleton.getInstance().setSlider(flSlider);
        textview_location.setOnClickListener(this);


        final CompanySetting companySetting = DatabaseManager.getInstance().getFirstOfClass(CompanySetting.class);
        Log.d("companysetting",companySetting.minOrder+"");

        if (companySetting.show_vat.equals("1")){
            tv_show_vat.setVisibility(View.VISIBLE);
        }
        else {
            tv_show_vat.setVisibility(View.GONE);

        }

        ProductsSingleton.getInstance().getCartView().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                User user=DatabaseManager.getInstance().getFirstOfClass(User.class);
                if(Cart.getTotalItems()< companySetting.minOrder){
                    Toast.makeText(getActivity(), getResources().getString(R.string.min_order_amount)+" "+companySetting.minOrder, Toast.LENGTH_SHORT).show();
                }
                else{
                    if (user!=null){
                        Intent intent = new Intent(getActivity(), CheckOutActivity.class);
                        intent.putExtra("order",false);
                        startActivityForResult(intent, ORDERS_SCREEN);
                        getActivity().overridePendingTransition(R.anim.enter_anim,0);
                    }else {
                        fromcart=true;
                        Intent intent = new Intent(getActivity(), LoginActivity.class);
                        startActivityForResult(intent,LOGINFROMCART);
                        getActivity().overridePendingTransition(R.anim.enter_anim,0);
                    }
                }
            }
        });
        
        
        User user=DatabaseManager.getInstance().getFirstOfClass(User.class);
        if (user!=null){
            if (user.hide_price.equals("1")){
                ProductsSingleton.getInstance().getTv_cartamount().setVisibility(View.GONE);
            }
        }
    }

    private void initSlider(List<Promotion> sliderList){

        viewPagerSlider.setAdapter(new ImageSliderAdapter(getActivity(), sliderList));

        indicator.setViewPager(viewPagerSlider);

        final float density = getResources().getDisplayMetrics().density;
        indicator.setRadius(3 * density);

        NUM_PAGES =sliderList.size();

        // Auto start of viewpager
        final Handler handler = new Handler();
        final Runnable Update = new Runnable() {
            public void run() {
                if (currentPage == NUM_PAGES) {
                    currentPage = 0;
                }
                viewPagerSlider.setCurrentItem(currentPage++, true);

            }
        };
        Timer swipeTimer = new Timer();
        swipeTimer.schedule(new TimerTask() {
            @Override
            public void run() {
                handler.post(Update);
            }
        }, 3000, 3000);


        // Pager listener over indicator
        indicator.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {

            @Override
            public void onPageSelected(int position) {
                currentPage = position;

            }

            @Override
            public void onPageScrolled(int pos, float arg1, int arg2) {

            }

            @Override
            public void onPageScrollStateChanged(int pos) {

            }
        });
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        getProductByLocation();
    }
    private void createGson() {
        GsonBuilder gsonBuilder = new GsonBuilder();
        gsonBuilder.setDateFormat("M/d/yy hh:mm a");
        gson = gsonBuilder.create();
    }
    private void getProductByLocation() {
        try {
            if (UserSession.getInstance().getSaveAddressObject().equals("")) {
                textview_location.setText("");
                startActivity(new Intent(getActivity(), AddAddressActivity.class));

            } else {
                JSONObject addressObj = new JSONObject(UserSession.getInstance().getSaveAddressObject());
                textview_location.setText("" + addressObj.getString("details"));
                getProducts(Integer.parseInt(addressObj.getString("areaId")),addressObj.getString("add_type"));
                Log.d("addresstype", addressObj.toString());

            }

        } catch (JSONException e) {
            e.printStackTrace();
        }



        User user=DatabaseManager.getInstance().getFirstOfClass(User.class);
        if (user!=null){
            if (user.hide_price.equals("1")){
                ProductsSingleton.getInstance().getTv_cartamount().setVisibility(View.GONE);
            }
        }

    }

    private void showProgress(boolean show) {
        if (show) {
            if (mProgressDialog != null && mProgressDialog.isShowing()) {
                mProgressDialog.dismiss();
            }
            mProgressDialog = new ProgressDialog(getActivity());
            mProgressDialog.setMessage(getResources().getString(R.string.please_wait));
            mProgressDialog.setIndeterminate(false);
            mProgressDialog.setCancelable(false);
            mProgressDialog.show();
        } else {
            if (mProgressDialog != null && mProgressDialog.isShowing()) {
                mProgressDialog.dismiss();
            }
        }
    }

    private void getProducts(final int area_id,String add_type) {
        showProgress(true);
        User user=DatabaseManager.getInstance().getFirstOfClass(User.class);
        String userId="";
        if (user!=null)
            userId=user.userId;

        Log.e("sizearea_id",area_id+"");
        Log.e("sizearea_id",new Gson().toJson( new ProductsRequest(area_id,userId,add_type)));

        APIManager.getInstance().getProducts(new APIManager.Callback() {
            @Override
            public void onResult(boolean z, String response) {
                showProgress(false);
                checkaddress = false;
                if (z) {
                    if (response.contains("Access denied") || response.contains("Invalid Key!")) {
                        CoreManager.getInstance().removeUserData();
                        Toast.makeText(getActivity(), "" + getResources().getString(R.string.logout), Toast.LENGTH_SHORT).show();

                        Intent intent = new Intent(getActivity(), HomeScreenActivity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);
                    } else {
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            Type listType = new TypeToken<List<Promotion>>() {}.getType();
                            List<Promotion> promotionbyLocation = gson.fromJson(jsonObject.getString("promotions"), listType);
                            ProductsSingleton.getInstance().setPromotionList(promotionbyLocation);
                            ProductsSingleton.getInstance().setPromotionList(promotionbyLocation);

                            List<Promotion> sliderList = new ArrayList<>();
                            if (isArabic) {
                                for (int i = 0; i < promotionbyLocation.size(); i++) {
                                    if (!promotionbyLocation.get(i).getImageMobileAr().equals("")) {
                                        sliderList.add(promotionbyLocation.get(i));
                                    }
                                }
                            } else {
                                for (int i = 0; i < promotionbyLocation.size(); i++) {
                                    if (!promotionbyLocation.get(i).getImageMobileEn().equals("")) {
                                        sliderList.add(promotionbyLocation.get(i));
                                    }
                                }
                            }

                            if (promotionbyLocation.size() > 0) {
                                flSlider.setVisibility(View.VISIBLE);

                                initSlider(sliderList);
                                if (sliderList.size()>0) {
                                    flSlider.setVisibility(View.VISIBLE);
                                } else {
                                    flSlider.setVisibility(View.GONE);
                                }

                            } else {
                                flSlider.setVisibility(View.GONE);
                            }

                            ArrayList<ProductByLocation> productByLocations = new ArrayList<>();
                            JSONArray jsonArray = jsonObject.getJSONArray("rows");
                            if (jsonArray.length()>0) {
                                for (int i = 0; i < jsonArray.length(); i++) {
                                    productByLocations.add(new Gson().fromJson(jsonArray.getJSONObject(i).toString(), ProductByLocation.class));
                                }
                                ProductsSingleton.getInstance().setProductByLocations(productByLocations);
                                getActivity().runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        updateCart();
                                        createViewPager();

                                    }
                                });
                            }else {
                                Toast.makeText(getActivity(), ""+jsonObject.getString("Message"), Toast.LENGTH_SHORT).show();
                                Cart.emptyCart();
                                ProductsSingleton.getInstance().getCartView().setVisibility(View.GONE);
                                ProductsSingleton.getInstance().getBasket_badge().setVisibility(View.GONE);
                                viewpager_products.setVisibility(View.GONE);
                            }
                            
                            if(fromcart){
                                fromcart=false;
                                if( Constants.fromproduct){
                                    Constants.fromproduct=false;
                                    User user=DatabaseManager.getInstance().getFirstOfClass(User.class);
                                    if(Cart.getTotalItems()>0){
                                        if(user!=null) {
                                            Intent intent = new Intent(getActivity(), CheckOutActivity.class);
                                            intent.putExtra("order", false);
                                            startActivityForResult(intent, ORDERS_SCREEN);
                                            getActivity().overridePendingTransition(R.anim.enter_anim, 0);
                                        }
                                    }
                                }

                            }
                        } catch (Exception e) {
                            Log.e("EXcePRO", e.toString());
                            e.printStackTrace();
                        }
                }

                }
            }
        }, area_id,userId,add_type);
    }

    private void updateCart(){
        List<Cart> cartList;
        cartList = DatabaseManager.getInstance().getAllOfClass(Cart.class);
        for(int j=0;j<cartList.size();j++){
            boolean cartCheck = true;
            for (int k = 0; k < ProductsSingleton.getInstance().getProductByLocations().size(); k++) {
                Log.d("cartitemcount",  ""+ProductsSingleton.getInstance().getProductByLocations().get(k).getId().toString()+","+cartList.get(j).productId.toString());

                if (ProductsSingleton.getInstance().getProductByLocations().get(k).getId().toString().equals(cartList.get(j).productId.toString())) {
                    Log.d("cartitemcount", cartList.get(j).count + "");
                    Cart.addMultipleItem(ProductsSingleton.getInstance().getProductByLocations().get(k).getId(),cartList.get(j).count,ProductsSingleton.getInstance().getProductByLocations().get(k));
                    cartCheck = false;
                }
            }
            if (cartCheck)
            {
                Log.d("cartitemcount",  "....."+cartCheck);

                Cart.deleteProductFromCart(cartList.get(j).productId);
            }
        }


        User user  = DatabaseManager.getInstance().getFirstOfClass(User.class);
        if (user!=null){
            if (user.hide_price.equals("1")){
                ProductsSingleton.getInstance().getTv_cartamount().setVisibility(View.GONE);
            }
        }
    }

    private void createViewPager() {
        ViewPagerAdapter adapter = new ViewPagerAdapter(getChildFragmentManager());
        adapter.addFrag(new CategoryFragmentGlass(), getResources().getString(R.string.st_glass));
        adapter.addFrag(new CategoryFragmentPlastic(), getResources().getString(R.string.st_plastic));

        viewpager_products.setAdapter(adapter);
        viewpager_products.setCurrentItem(1);
        viewpager_products.setOffscreenPageLimit(1);
        tabs.setupWithViewPager(viewpager_products);
        tabs.setSelectedTabIndicatorColor(getResources().getColor(R.color.plastic_cat_color));
        tabs.setTabTextColors(getResources().getColor(R.color.tab_selected),
                getResources().getColor(R.color.plastic_cat_color));
        tabs.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {

                switch (tab.getPosition()) {
                    case 0:
                        tabs.setSelectedTabIndicatorColor(getResources().getColor(R.color.tab_selected));
                        tabs.setTabTextColors(getResources().getColor(R.color.plastic_cat_color),
                                getResources().getColor(R.color.tab_selected));
                        Map<String, Object> eventValue = new HashMap<String, Object>();
                        eventValue.put(AFInAppEventParameterName.PARAM_1,""+"Glass");
                        CleverTapAPI.getDefaultInstance(getActivity()).pushEvent("Category Viewed:",eventValue);                        break;
                    case 1:
                        tabs.setSelectedTabIndicatorColor(getResources().getColor(R.color.plastic_cat_color));
                        tabs.setTabTextColors(getResources().getColor(R.color.tab_selected),
                                getResources().getColor(R.color.plastic_cat_color));

                        Map<String, Object> eventValue1 = new HashMap<String, Object>();
                        eventValue1.put(AFInAppEventParameterName.PARAM_1,""+"Plastic");
                        CleverTapAPI.getDefaultInstance(getActivity()).pushEvent("Category Viewed:",eventValue1);
                        break;
                }

            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });


    }

    public class ImageSliderAdapter extends PagerAdapter {

        private Context mContext;
        private  List<Promotion> imageList;
        private LayoutInflater inflater;



//
        public ImageSliderAdapter(Context context, List<Promotion> list) {
            mContext = context;
            imageList = list;
            inflater = LayoutInflater.from(context);
        }


        @Override
        public Object instantiateItem(ViewGroup collection, int position) {
            ViewGroup imageLayout = (ViewGroup) inflater.inflate(R.layout.si_slidingimage_layout, collection, false);

            final ImageView imageView = imageLayout.findViewById(R.id.imageview);
            final ProgressBar progress_bar = imageLayout.findViewById(R.id.progress_bar);
            imageView.setVisibility(View.GONE);
            progress_bar.setVisibility(View.VISIBLE);

            try {

                if (!isArabic) {
                    Picasso.with(getActivity()).load(PROMO_BASE_URL + imageList.get(position).getImageMobileEn())

                            .into(imageView, new com.squareup.picasso.Callback() {
                                @Override
                                public void onSuccess() {
                                    imageView.setVisibility(View.VISIBLE);
                                    progress_bar.setVisibility(View.GONE);
                                }

                                @Override
                                public void onError() {

                                }
                            });


                } else {

                    Picasso.with(getActivity()).load(PROMO_BASE_URL + imageList.get(position).getImageMobileAr())

                            .into(imageView, new com.squareup.picasso.Callback() {
                                @Override
                                public void onSuccess() {
                                    imageView.setVisibility(View.VISIBLE);
                                    progress_bar.setVisibility(View.GONE);
                                }

                                @Override
                                public void onError() {

                                }
                            });


                }
            } catch (Exception e) {
                Log.e("IMage SLider Adapter :", e.getMessage());

            }

            // imageView.setImage(ImageSource.uri( Common.PhotoURl+imageList.get(position).getPhotoSource()));

            collection.addView(imageLayout);
            return imageLayout;
        }

        @Override
        public void destroyItem(ViewGroup collection, int position, Object view) {
            collection.removeView((View) view);
        }

        @Override
        public int getCount() {
            //return CustomPagerEnum.values().length;
            return imageList.size();
        }

        @Override
        public boolean isViewFromObject(View view, Object object) {
            return view == object;
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return imageList.get(position).toString();
        }
    }
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.textview_location:
                User user = DatabaseManager.getInstance().getFirstOfClass(User.class);
                if (user != null) {
                    Intent intent = new Intent(getActivity(), ChooseAddressActivity.class);
                    startActivityForResult(intent, REQUEST_FOR_ADDRESS);
                } else {
                    String permission = Manifest.permission.ACCESS_FINE_LOCATION;
                    int res = getContext().checkCallingOrSelfPermission(permission);
                    if (res == PackageManager.PERMISSION_GRANTED) {
                        Intent intent = new Intent(getActivity(), AddAddressActivity.class);
                        intent.putExtra("fromHome",1);
                        startActivityForResult(intent, REQUEST_FOR_ADDRESS);
                        getActivity().overridePendingTransition(R.anim.enter_anim, 0);
                    } else {
                        Toast.makeText(getActivity(), "Enable Location in Settings", Toast.LENGTH_SHORT).show();
                        if (countDownTimer != null) {
                            countDownTimer.cancel();
                        }
                    }
                }

                break;
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        getActivity().registerReceiver(mReceiverOnAddressChange, new IntentFilter("data_action_add_change"));

        if (checkaddress)
        {
            getProductByLocation();
        }
        if (special_promotion){
            getProductByLocation();
            special_promotion = false;
        }else
        if(fromcart){
            fromcart=false;
            if( Constants.fromproduct){
                Constants.fromproduct=false;
                User user=DatabaseManager.getInstance().getFirstOfClass(User.class);
                if(Cart.getTotalItems()>0){
                    if(user!=null) {
                        Intent intent = new Intent(getActivity(), CheckOutActivity.class);
                        intent.putExtra("order", false);
                        startActivityForResult(intent, ORDERS_SCREEN);
                        getActivity().overridePendingTransition(R.anim.enter_anim, 0);
                    }
                }
            }

        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        LocalBroadcastManager.getInstance(getActivity()).unregisterReceiver(mReceiverOnAddressChange);
        if(mProgressDialog!=null && mProgressDialog.isShowing()){
            mProgressDialog.dismiss();
        }
        if(dialog!=null && dialog.isShowing()){
            dialog.dismiss();
        }

    }

    private BroadcastReceiver mReceiverOnAddressChange = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            try {
                String string = (String) intent.getSerializableExtra("onAddressChange");
                Log.d("changeddd", string + "....");
                if (string.equals("changed")) {
                    //getProductByLocation();
                    checkaddress = true;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    };

}
