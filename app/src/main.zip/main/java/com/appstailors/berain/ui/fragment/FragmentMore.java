package com.appstailors.berain.ui.fragment;


import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Paint;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import com.appstailors.berain.AppController;
import com.appstailors.berain.R;
import com.appstailors.berain.UserSession;
import com.appstailors.berain.object.CompanySetting;
import com.appstailors.berain.object.login.User;
import com.appstailors.berain.ui.ChooseAddressActivity;
import com.appstailors.berain.ui.EditProfileActivity;
import com.appstailors.berain.ui.HomeScreen.HomeScreenActivity;
import com.appstailors.berain.ui.ShareActivity;
import com.appstailors.berain.ui.Ticket;
import com.appstailors.berain.ui.TicketList;
import com.appstailors.berain.ui.WalletInformationActivity;
import com.appstailors.berain.utils.Constants;
import com.roam.appdatabase.DatabaseManager;

//import com.alaseeldates.Manifest;

/**
 * A simple {@link Fragment} subclass.
 */
public class FragmentMore extends Fragment implements View.OnClickListener {


    private  boolean isArabic;
    View view,viewWhatsapp,viewMail;
    User user;
    LinearLayout layotContactInfo,layoutProfile,layoutLanguage,layoutTickets,layoutShareApp;
    TextView tvPersonalInfo,tvWallet,tvTicketsList,tvAddTickets,tvAddress,tvContactNumber,tvContactMail,tvContactWhatsapp;
    boolean profileCheck = false;
    boolean ticketCheck = false;
    ImageView imageProfile,imageTickets;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
         view= inflater.inflate(R.layout.fragment_more, container, false);
        initViews(view);
        return view;
    }

    private void initViews(View view) {
        layotContactInfo = view.findViewById(R.id.layotContactInfo);
        layoutProfile = view.findViewById(R.id.layoutProfile);
        layoutLanguage = view.findViewById(R.id.layoutLanguage);
        tvWallet = view.findViewById(R.id.tvWallet);
        layoutShareApp = view.findViewById(R.id.layoutShareApp);
        tvPersonalInfo = view.findViewById(R.id.tvPersonalInfo);
        layoutTickets = view.findViewById(R.id.layoutTickets);
        tvAddress = view.findViewById(R.id.tvAddress);
        tvContactNumber = view.findViewById(R.id.tvContactNumber);
        tvContactMail = view.findViewById(R.id.tvContactMail);
        viewMail = view.findViewById(R.id.viewMail);
        tvContactWhatsapp = view.findViewById(R.id.tvContactWhatsapp);
        viewWhatsapp = view.findViewById(R.id.viewWhatsapp);

        tvTicketsList = view.findViewById(R.id.tvTicketsList);
        tvAddTickets = view.findViewById(R.id.tvAddTickets);
        imageTickets = view.findViewById(R.id.imageTickets);
        imageProfile = view.findViewById(R.id.imageProfile);

        layoutProfile.setOnClickListener(this);
        tvTicketsList.setOnClickListener(this);
        tvAddTickets.setOnClickListener(this);
        tvWallet.setOnClickListener(this);
        layoutLanguage.setOnClickListener(this);
        layoutShareApp.setOnClickListener(this);
        tvPersonalInfo.setOnClickListener(this);
        layoutTickets.setOnClickListener(this);
        tvAddress.setOnClickListener(this);
        tvContactNumber.setOnClickListener(this);
        tvContactMail.setOnClickListener(this);
        tvContactWhatsapp.setOnClickListener(this);
        setViews();
    }
    public void setViews(){
        user= DatabaseManager.getInstance().getFirstOfClass(User.class);
        if (user != null) {
            LocalBroadcastManager.getInstance(getActivity()).registerReceiver(promotion_reciever, new IntentFilter("ticketlist"));
        }
        CompanySetting companySetting = DatabaseManager.getInstance().getFirstOfClass(CompanySetting.class);
        if (user != null)
        {
            layoutProfile.setVisibility(View.VISIBLE);
            layoutLanguage.setVisibility(View.VISIBLE);
            layoutShareApp.setVisibility(View.VISIBLE);
            tvPersonalInfo.setVisibility(View.VISIBLE);
            tvAddress.setVisibility(View.VISIBLE);

            if(companySetting.is_ticket_enable.equals("1")) {
                layoutTickets.setVisibility(View.VISIBLE);
                tvAddTickets.setVisibility(View.VISIBLE);
                tvTicketsList.setVisibility(View.VISIBLE);
            }else {
                layoutTickets.setVisibility(View.GONE);
                tvAddTickets.setVisibility(View.GONE);
                tvTicketsList.setVisibility(View.GONE);
            }

            if (user.hide_price.equals("1")){
                tvWallet.setVisibility(View.GONE);
            }else {
                tvWallet.setVisibility(View.VISIBLE);
            }

        }else {
            layoutProfile.setVisibility(View.GONE);
            layoutLanguage.setVisibility(View.VISIBLE);
            layoutShareApp.setVisibility(View.VISIBLE);
            tvWallet.setVisibility(View.GONE);
            layoutTickets.setVisibility(View.GONE);
            tvAddTickets.setVisibility(View.GONE);
            tvTicketsList.setVisibility(View.GONE);
        }

        tvPersonalInfo.setVisibility(View.GONE);
        tvAddress.setVisibility(View.GONE);

        if (!companySetting.helpLine.equals("")||!companySetting.email.equals("")||!companySetting.whats_app.equals("")){
            layotContactInfo.setVisibility(View.VISIBLE);
        }else {
            layotContactInfo.setVisibility(View.GONE);
        }

        tvContactWhatsapp.setText(companySetting.whats_app);
        tvContactMail.setText(companySetting.email);
        tvContactNumber.setText(companySetting.helpLine);

        if (companySetting.whats_app.equals("")) {
            tvContactWhatsapp.setVisibility(View.GONE);
            viewWhatsapp.setVisibility(View.GONE);

        }
        if (companySetting.email.equals("")) {
            tvContactMail.setVisibility(View.GONE);
            viewMail.setVisibility(View.GONE);

        }
        if (companySetting.helpLine.equals(""))
            tvContactNumber.setVisibility(View.GONE);

    }

    @Override
    public void onResume() {
        setViews();
        super.onResume();
    }

  private BroadcastReceiver promotion_reciever = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.getStringExtra("switch") != null) {
                startActivity(new Intent(getActivity(), TicketList.class));
                getActivity().overridePendingTransition(R.anim.enter_anim, 0);
            }
        }
    };
    public FragmentMore() {
        // Required empty public constructor
    }
    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if (isVisibleToUser) {
            user= DatabaseManager.getInstance().getFirstOfClass(User.class);
            isArabic = AppController.setLocale();
            if (isArabic) {
                //prepareDataList_ar();
            } else {
                //prepareDataList_en();
            }
        }
    }



    @Override
    public void onDestroy() {
        super.onDestroy();
        if (user != null) {
            LocalBroadcastManager.getInstance(getActivity()).unregisterReceiver(promotion_reciever);
        }
    }


    @Override
    public void onClick(View v) {

        switch (v.getId())
        {
                case R.id.layoutProfile:
                    if (profileCheck)
                    {
                        tvPersonalInfo.setVisibility(View.GONE);
                        tvAddress.setVisibility(View.GONE);
                        imageProfile.setImageResource(R.drawable.ic_keyboard_arrow_down_black_24dp);
                        profileCheck = false;
                    }else {
                        tvPersonalInfo.setVisibility(View.VISIBLE);
                        tvAddress.setVisibility(View.VISIBLE);
                        imageProfile.setImageResource(R.drawable.ic_keyboard_arrow_up_black_24dp);
                        profileCheck = true;
                    }
                break;
                case R.id.layoutTickets:

                    if (ticketCheck)
                    {
                        tvTicketsList.setVisibility(View.GONE);
                        tvAddTickets.setVisibility(View.GONE);
                        imageTickets.setImageResource(R.drawable.ic_keyboard_arrow_down_black_24dp);

                        ticketCheck = false;
                    }else {
                        tvTicketsList.setVisibility(View.VISIBLE);
                        tvAddTickets.setVisibility(View.VISIBLE);
                        imageTickets.setImageResource(R.drawable.ic_keyboard_arrow_up_black_24dp);

                        ticketCheck = true;
                    }

                break;

                case R.id.layoutLanguage:
                    if (UserSession.getInstance().getUserLanguage().equals(Constants.ENGLISH)) {
                        UserSession.getInstance().setUserLanguage(Constants.ARABIC);
                    } else {
                        UserSession.getInstance().setUserLanguage(Constants.ENGLISH);
                    }
                    getActivity().finish();
                    startActivity(new Intent(getActivity(), HomeScreenActivity.class));
                    getActivity().overridePendingTransition(R.anim.enter_anim, 0);
                break;


                case R.id.layoutShareApp:
                    startActivity(new Intent(getActivity(), ShareActivity.class));
                    getActivity().overridePendingTransition(R.anim.enter_anim, 0);
                break;


                case R.id.tvPersonalInfo:
                    startActivity(new Intent(getActivity(), EditProfileActivity.class));
                    getActivity().overridePendingTransition(R.anim.enter_anim, 0);

                break;

                case R.id.tvContactMail:
                    contacUsMail();
                break;

                case R.id.tvWallet:
                    //contacUsMail();
                    startActivity(new Intent(getActivity(), WalletInformationActivity.class));
                    getActivity().overridePendingTransition(R.anim.enter_anim, 0);
                break;

                case R.id.tvContactNumber:
                  /*   if(isPermissionGranted()){
                            contacUsNumber();
                        }
                    */
                break;

                case R.id.tvContactWhatsapp:
                    CompanySetting companySetting = DatabaseManager.getInstance().getFirstOfClass(CompanySetting.class);
                    openWhatsApp(""+companySetting.whats_app);

                break;

                case R.id.tvAddress:
                    Constants.fromore=true;
                    startActivity(new Intent(getActivity(), ChooseAddressActivity.class));
                    getActivity().overridePendingTransition(R.anim.enter_anim, 0);
                break;

                case R.id.tvTicketsList:
                    startActivity(new Intent(getActivity(), TicketList.class));
                    getActivity().overridePendingTransition(R.anim.enter_anim, 0);
                break;

                case R.id.tvAddTickets:
                    startActivity(new Intent(getActivity(), Ticket.class));
                    getActivity().overridePendingTransition(R.anim.enter_anim, 0);
                break;


        }
    }

    public void openWhatsApp( String whatsApp){
        Intent sendIntent = new Intent();
        sendIntent.setAction(Intent.ACTION_VIEW);
        String url = "https://api.whatsapp.com/send?phone=" + whatsApp;
        sendIntent.setData(Uri.parse(url));
       startActivity(sendIntent);
    }

  /*  public void contacUsNumber(){
        Intent intent = new Intent(Intent.ACTION_DIAL);
        intent.setData(Uri.parse("tel:"+tvContactNumber.getText() ));
        startActivity(intent);
    }*/

    public void contacUsMail(){
        Intent emailIntent = new Intent(Intent.ACTION_SENDTO, Uri.fromParts(
                "mailto",""+tvContactMail.getText().toString(), null));
        emailIntent.putExtra(Intent.EXTRA_SUBJECT, "");
        emailIntent.putExtra(Intent.EXTRA_TEXT, "");
        startActivity(Intent.createChooser(emailIntent, "Send email..."));
    }

/*
    public  boolean isPermissionGranted() {
        if (Build.VERSION.SDK_INT >= 23) {
            if (getActivity().checkSelfPermission(android.Manifest.permission.CALL_PHONE)
                    == PackageManager.PERMISSION_GRANTED) {
                Log.v("TAG","Permission is granted");
                return true;
            } else {

                Log.v("TAG","Permission is revoked");
                ActivityCompat.requestPermissions(getActivity(), new String[]{
                        android.Manifest.permission.CALL_PHONE}, 1);

                return false;
            }
        }
        else { //permission is automatically granted on sdk<23 upon installation
            Log.v("TAG","Permission is granted");
            return true;
        }
    }


    @Override
    public void onRequestPermissionsResult(int requestCode,String permissions[], int[] grantResults) {
        switch (requestCode) {

            case 1: {

                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(getApplicationContext(), "Permission granted", Toast.LENGTH_SHORT).show();
                    contacUsNumber();
                } else {
                    Toast.makeText(getApplicationContext(), "Permission denied", Toast.LENGTH_SHORT).show();
                }
                return;
            }

        }
    }
*/


}
