package com.appstailors.berain.adapter;

import android.app.Activity;
import android.content.Context;
import android.graphics.Paint;
import android.graphics.Typeface;
import androidx.recyclerview.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.appsflyer.AFInAppEventParameterName;
import com.appsflyer.AFInAppEventType;
import com.appsflyer.AppsFlyerLib;
import com.appstailors.berain.AppController;
import com.appstailors.berain.R;
import com.appstailors.berain.object.Cart;
import com.appstailors.berain.object.ProductByLocation;
import com.appstailors.berain.object.login.User;
import com.appstailors.berain.ui.fragment.CategoryFragmentPlastic;
import com.appstailors.berain.utils.ProductsSingleton;
import com.appstailors.berain.utils.Utils;
import com.bumptech.glide.Glide;
import com.clevertap.android.sdk.CleverTapAPI;
import com.roam.appdatabase.DatabaseManager;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.appstailors.berain.utils.Constants.IMAGE_BASE_URL;


public class ProductbyLocationAdapterPlastic extends RecyclerView.Adapter<ProductbyLocationAdapterPlastic.MyViewHolder> {

    private List<ProductByLocation> productList;
    private Context mContext;
    public TextView tv_cartamount;
    public Activity activity;
    private CategoryFragmentPlastic mProductsFragment;
    private boolean isArabic;
    boolean promotionCheck = true;

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView tvBeforePrice,tv_before_sr,si_home_Products_tvPrice,tv_sr, si_home_Products_tvTitle, si_home_Products_tvDetails;
        private ImageView productsImage;
        private LinearLayout addMoreLayout;
        private EditText editext_productquantity;
        private Button addproduct_button,minusproduct_button;

        private View priceview;
        View layoutPromotions;
        TextView tvPromotionFreeItems;
        TextView tvPromotionRemainingItems;

        public MyViewHolder(View view) {
            super(view);
            si_home_Products_tvPrice =  view.findViewById(R.id.tvProductPrice);
            si_home_Products_tvTitle = view.findViewById(R.id.tvProductTitle);
            si_home_Products_tvDetails =  view.findViewById(R.id.tvProductDetails);
            productsImage =  view.findViewById(R.id.imageProductThumb);
            editext_productquantity =  view.findViewById(R.id.edtCounterQuantity);
            addproduct_button =  view.findViewById(R.id.btnCounterPlus);
            minusproduct_button =  view.findViewById(R.id.btnCounterMinus);
            tv_sr =  view.findViewById(R.id.tv_sr);
            priceview =  view.findViewById(R.id.priceview);
            layoutPromotions =itemView.findViewById(R.id.layoutPromotions);
            tvPromotionFreeItems=itemView.findViewById(R.id.tvPromotionFreeItems);
            tvPromotionRemainingItems=itemView.findViewById(R.id.tvPromotionRemainingItems);
            tvBeforePrice=itemView.findViewById(R.id.tvBeforePrice);
            tv_before_sr=itemView.findViewById(R.id.tv_before_sr);
        }
    }


    public ProductbyLocationAdapterPlastic(CategoryFragmentPlastic mProductsFragment,Activity activity ,Context context, ArrayList<ProductByLocation> productList) {
        this.productList = productList;
        this.mContext = context;
        this.activity=activity;
        this.mProductsFragment=mProductsFragment;
        this.isArabic = AppController.setLocale();
    }



    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.model_home_products, parent, false);
        return new MyViewHolder(view);
    }


    @Override
    public void onBindViewHolder(final MyViewHolder holder, final int position) {
           if(isArabic){
               ArabicData(holder,position);
               activity.getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
           }
           else{
               EnglishData(holder,position);
               activity. getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_LTR);

           }


        if (productList.get(position).getCount()>0) {
            holder.layoutPromotions.setVisibility(View.GONE);
            promotionCheck =true;
            checkPromotion(productList.get(position).getCount() + "", productList.get(position).getId(), holder);
        }
        else {
            holder.layoutPromotions.setVisibility(View.GONE);
        }



        if (productList.get(position).getBefore_discount()==null ||
                productList.get(position).getBefore_discount().equals("")||
                productList.get(position).getBefore_discount().equals("0")){
                holder.tv_before_sr.setVisibility(View.GONE);
                holder.tvBeforePrice.setVisibility(View.GONE);
        }else {
            holder.tv_before_sr.setVisibility(View.VISIBLE);
            holder.tvBeforePrice.setVisibility(View.VISIBLE);
            holder.tvBeforePrice.setText(productList.get(position).getBefore_discount());
            holder.tvBeforePrice.setPaintFlags( holder.tvBeforePrice.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);

        }


        Glide.with(mContext)
                .load(IMAGE_BASE_URL + productList.get(position).getImg())
                .placeholder(R.drawable.loading_spinner)
                .into(holder.productsImage);
        holder.priceview.setBackgroundResource(R.drawable.bg_price_home_plastic);
        holder.editext_productquantity.setText(productList.get(position).getCount()+"");


        holder.productsImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

//                Intent intent=new Intent(mContext, ProductDetails.class);
//                intent.putExtra("product_image",productList.get(position).getImg());
//                intent.putExtra("product_price",productList.get(position).getPrice());
//                intent.putExtra("product_id",productList.get(position).getId());
//                if(isArabic){
//                    intent.putExtra("product_name",productList.get(position).getNameAr());
//                    intent.putExtra("product_cat",productList.get(position).getCatAr());
//                }
//                else{
//                    intent.putExtra("product_name",productList.get(position).getNameEn());
//                    intent.putExtra("product_cat",productList.get(position).getCatEn());
//                }
//                intent.putExtra("product_count",productList.get(position).getCount()+"");
//                intent.putExtra("product_object",new Gson().toJson(productList.get(position)));
//
//                activity.startActivity(intent);
//                activity.overridePendingTransition(R.anim.enter_anim,0);

            }
        });
        holder.addproduct_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int count = productList.get(position).getCount() + 1;
                productList.get(position).setCount(count);

                holder.editext_productquantity.setText(productList.get(position).getCount()+"");
                Cart result = DatabaseManager.getInstance().getFirstMatching("productId", productList.get(position).getId(),
                        Cart.class);
                if(result==null){
                    Cart.addToCart( productList.get(position), -1,1);
                }
                else{
                    Cart.addOneItem(productList.get(position).getId());
                }

                ProductsSingleton.getInstance().getBasket_badge().setVisibility(View.VISIBLE);
                new Utils().updateAmount(isArabic);
                    ProductsSingleton.getInstance().getBasket_badge().setText(Cart.getTotalItems()+"");

                mProductsFragment.showCartLayout();
                mProductsFragment.getCartNumber();
                notifyDataSetChanged();

                Map<String, Object> eventValue = new HashMap<String, Object>();
                eventValue.put(AFInAppEventParameterName.CONTENT_ID,productList.get(position).getId());
                //eventValue.put(AFInAppEventParameterName.CURRENCY,"SAR");
                eventValue.put(AFInAppEventParameterName.PRICE,""+productList.get(position).getPrice());
                eventValue.put(AFInAppEventParameterName.PARAM_1,"Product Name "+productList.get(position).getNameEn());
                eventValue.put(AFInAppEventParameterName.PARAM_2,"Quantity"+"1");
                eventValue.put(AFInAppEventParameterName.PARAM_3,"Stock Availability"+"Yes");
                // AppsFlyerLib.getInstance().trackEvent(mContext , AFInAppEventType.ADD_TO_CART , eventValue);
                CleverTapAPI.getDefaultInstance(mContext).pushEvent("Added to Cart:",eventValue);
            }
        });

        holder.minusproduct_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (productList.get(position).getCount() < 1) {
                    int count = 0;
                    productList.get(position).setCount(count);
                    holder.editext_productquantity.setText(productList.get(position).getCount() + "");


                }

               else if (productList.get(position).getCount() == 1) {
                    int count = productList.get(position).getCount() - 1;
                    productList.get(position).setCount(count);
                    holder.editext_productquantity.setText(productList.get(position).getCount()+"");
                    Cart.deleteProductFromCart(productList.get(position).getId());
                    updateAmount();
                    productList.get(position).setAddedToCart(false);
                    ProductsSingleton.getInstance().getBasket_badge().setText(Cart.getTotalItems()+"");

                    mProductsFragment.getCartNumber();
                    notifyDataSetChanged();
                } else {
                    int count = productList.get(position).getCount() - 1;
                    productList.get(position).setCount(count);
                    holder.editext_productquantity.setText(productList.get(position).getCount()+"");
                    Cart.removeOneItem(productList.get(position).getId());
                    updateAmount();
                    ProductsSingleton.getInstance().getBasket_badge().setText(Cart.getTotalItems()+"");
                    mProductsFragment.getCartNumber();
                    notifyDataSetChanged();
                }
            }
        });
        holder.tv_sr.setText(mContext.getResources().getString(R.string.currency));
        setProductCount(holder.editext_productquantity,position);
        User user  = DatabaseManager.getInstance().getFirstOfClass(User.class);
        if (user!=null){
            if (user.hide_price.equals("1")){
                holder.si_home_Products_tvPrice.setVisibility(View.GONE);
                holder.tv_sr.setVisibility(View.GONE);
                holder.priceview.setVisibility(View.GONE);            }
        }

    }

    private void setProductCount(final EditText editText_productcount, final int  position){

        editText_productcount.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                if (editText_productcount.getText().toString().matches("[0-9]+")) {
                  //  productList.get(position).setCount(Integer.parseInt(editText_productcount.getText().toString()));
                }
                else{

                }
            }
            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        editText_productcount.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if ((event != null && (event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) || (actionId == EditorInfo.IME_ACTION_DONE)) {
                        if(editText_productcount.getText().toString().equals("")){
                            editText_productcount.setText("0");
                        }

                    int count = Integer.parseInt(editText_productcount.getText().toString());
                        if(count<1){
                            Cart.deleteProductFromCart(productList.get(position).getId());
                            productList.get(position).setCount(count);
                            updateAmount();
                        }
                        else{
                            Cart result = DatabaseManager.getInstance().getFirstMatching("productId", productList.get(position).getId(),
                                    Cart.class);
                            Cart.removeItems(productList.get(position).getId());
                            productList.get(position).setCount(count);
                            if(result==null){
                                Cart.addToCart( productList.get(position), -1,count);
                            }
                            else{
                                Cart.addMultipleItem(productList.get(position).getId(),count,productList.get(position));
                            }
                        }




                    updateAmount();

                    ProductsSingleton.getInstance().getBasket_badge().setText(Cart.getTotalItems()+"");

                    if(Cart.getTotalItems()>0){
                        ProductsSingleton.getInstance().getCartView().setVisibility(View.VISIBLE);
                        ProductsSingleton.getInstance().getBasket_badge().setVisibility(View.VISIBLE);
                    }
                    else{

                        ProductsSingleton.getInstance().getBasket_badge().setVisibility(View.GONE);
                    }
                    notifyDataSetChanged();
                }
                return false;
            }
        });


    }

 /*   private void setGift(int count, String b_quantity, MyViewHolder cartRecyclerHolder, int position,
                         String type) {

        if (productList.get(position).isPromotion_available()) {

            if (count % Double.parseDouble(b_quantity) == 0) {
                cartRecyclerHolder.giftview.setVisibility(View.VISIBLE);
                cartRecyclerHolder.iv_cart_gift.setVisibility(View.VISIBLE);
                productList.get(position).setFree_items(count / Double.parseDouble(b_quantity) + "");
                Double aDouble = new Double(productList.get(position).getFree_items());
                int items = aDouble.intValue();
                cartRecyclerHolder.tv_gift.setText("X " + items + "");

            } else {
                if (Double.parseDouble(productList.get(position).getFree_items()) > 0) {
                    cartRecyclerHolder.iv_cart_gift.setVisibility(View.VISIBLE);
                    cartRecyclerHolder.giftview.setVisibility(View.VISIBLE);
                    if (count / Double.parseDouble(b_quantity) < Double.parseDouble(productList.get(position).getFree_items())) {

                        Double aDouble = new Double((count / Double.parseDouble(b_quantity)) + "");
                        int items = aDouble.intValue();
                        productList.get(position).setFree_items(items + "");
                        cartRecyclerHolder.tv_gift.setText("X " + items + "");

                    } else {
                        Double aDouble = new Double((productList.get(position).getFree_items()));
                        int items = aDouble.intValue();
                        cartRecyclerHolder.tv_gift.setText("X " + items + "");

                    }

                } else {
                    cartRecyclerHolder.iv_cart_gift.setVisibility(View.GONE);
                    cartRecyclerHolder.giftview.setVisibility(View.GONE);

                }
            }
        } else {
            cartRecyclerHolder.iv_cart_gift.setVisibility(View.GONE);
            cartRecyclerHolder.giftview.setVisibility(View.GONE);

        }

        if (Double.parseDouble(productList.get(position).getFree_items()) >=1) {
            cartRecyclerHolder.iv_cart_gift.setVisibility(View.VISIBLE);
            cartRecyclerHolder.giftview.setVisibility(View.VISIBLE);

        }
        else{
            cartRecyclerHolder.iv_cart_gift.setVisibility(View.GONE);
            cartRecyclerHolder.giftview.setVisibility(View.GONE);

        }


    }*/



    private void checkPromotion(String count, String productId,MyViewHolder myViewHolder){
        if (ProductsSingleton.getInstance().getPromotionList()!= null&&ProductsSingleton.getInstance().getPromotionList().size() > 0) {
            for (int i = 0; i < ProductsSingleton.getInstance().getPromotionList().size(); i++) {
                if (promotionCheck) {
                    setPromotion(count, productId, i, myViewHolder);
                }
            }
        }
    }
    private void setPromotion(String count, String productId, int position, MyViewHolder myViewHolder) {


        if (ProductsSingleton.getInstance().getPromotionList().get(position).getProduct_id_list().size() == 0) {

            if (ProductsSingleton.getInstance().getPromotionList().get(position).getRange_limit().size() > 0) {

                for (int j = 0; j < ProductsSingleton.getInstance().getPromotionList().get(position).getRange_limit().size(); j++) {

                    Double max = Double.valueOf(ProductsSingleton.getInstance().getPromotionList().get(position).getRange_limit().get(j).getMax());
                    Double min = Double.valueOf(ProductsSingleton.getInstance().getPromotionList().get(position).getRange_limit().get(j).getMin());
                    if (Integer.valueOf(count) >= min && Integer.valueOf(count) <= max) {

                        if (j == ProductsSingleton.getInstance().getPromotionList().get(position).getRange_limit().size() - 1) {
                            myViewHolder.tvPromotionRemainingItems.setText("" + mContext.getResources().getString(R.string._string_Remaining) + "0");
                        } else {
                            myViewHolder.tvPromotionRemainingItems.setText("" + mContext.getResources().getString(R.string._string_Remaining) + (int) (max - Integer.valueOf(count) + 1));
                        }

                        myViewHolder.tvPromotionFreeItems.setText("x " + Integer.parseInt(ProductsSingleton.getInstance().getPromotionList().get(position).getRange_limit().get(j).getAdd_on()));
                        myViewHolder.layoutPromotions.setVisibility(View.VISIBLE);
                        // promotionCheck = false;
                        //break;
                    } else if (Integer.valueOf(count) > 0 && Integer.valueOf(count) < min && j == 0) {
                        myViewHolder.layoutPromotions.setVisibility(View.VISIBLE);
                        Log.d("count......", "....." + (productId));
                        myViewHolder.tvPromotionRemainingItems.setText("" + mContext.getResources().getString(R.string._string_Remaining) + (int) (min - Integer.valueOf(count)));
                        myViewHolder.tvPromotionFreeItems.setText("x " + 0);
                        // promotionCheck = false;
                        // break;
                    } else if ((j == ProductsSingleton.getInstance().getPromotionList().get(position).getRange_limit().size() - 1) && Integer.valueOf(count) >= max) {
                        myViewHolder.tvPromotionRemainingItems.setText("" + mContext.getResources().getString(R.string._string_Remaining) + "0");
                        myViewHolder.tvPromotionFreeItems.setText("x " + Integer.parseInt(ProductsSingleton.getInstance().getPromotionList().get(position).getRange_limit().get(j).getAdd_on()));
                        myViewHolder.layoutPromotions.setVisibility(View.VISIBLE);
                        //promotionCheck = false;
                        // break;
                    }

                }
            } else if (ProductsSingleton.getInstance().getPromotionList().get(position).getPromotion_level().equals("product")) {
                if (Double.parseDouble(ProductsSingleton.getInstance().getPromotionList().get(position).getQuantity()) > 0 &&
                        Double.parseDouble(ProductsSingleton.getInstance().getPromotionList().get(position).getAddOn()) > 0) {
                    Log.d("printsome", "" + productId);
                    Double baseQuanitity = Double.parseDouble(ProductsSingleton.getInstance().getPromotionList().get(position).getQuantity());
                    Double addOn = Double.parseDouble(ProductsSingleton.getInstance().getPromotionList().get(position).getAddOn());
                    Double counter = Double.parseDouble(count);
                    Double mod = counter % baseQuanitity;
                    myViewHolder.tvPromotionRemainingItems.setText("" + mContext.getResources().getString(R.string._string_Remaining) + (int) (baseQuanitity - mod));
                    Double freeItemcount = ((counter - mod) / baseQuanitity) * addOn;
                    myViewHolder.tvPromotionFreeItems.setText("x " + (int) Math.round(freeItemcount) + "");
                    myViewHolder.layoutPromotions.setVisibility(View.VISIBLE);
                    Log.d("printsome11111", "" + productId);
                    //promotionCheck = false;
                }
            }

        } else

        {

            for (int i = 0; i < ProductsSingleton.getInstance().getPromotionList().get(position).getProduct_id_list().size(); i++) {

                if (ProductsSingleton.getInstance().getPromotionList().get(position).getProduct_id_list().get(i).equals(productId)) {

                    if (ProductsSingleton.getInstance().getPromotionList().get(position).getRange_limit().size() > 0) {

                        for (int j = 0; j < ProductsSingleton.getInstance().getPromotionList().get(position).getRange_limit().size(); j++) {

                            Double max = Double.valueOf(ProductsSingleton.getInstance().getPromotionList().get(position).getRange_limit().get(j).getMax());
                            Double min = Double.valueOf(ProductsSingleton.getInstance().getPromotionList().get(position).getRange_limit().get(j).getMin());
                            if (Integer.valueOf(count) >= min && Integer.valueOf(count) <= max) {

                                if (j == ProductsSingleton.getInstance().getPromotionList().get(position).getRange_limit().size() - 1) {
                                    myViewHolder.tvPromotionRemainingItems.setText("" + mContext.getResources().getString(R.string._string_Remaining) + "0");
                                } else {
                                    myViewHolder.tvPromotionRemainingItems.setText("" + mContext.getResources().getString(R.string._string_Remaining) + (int) (max - Integer.valueOf(count) + 1));
                                }

                                myViewHolder.tvPromotionFreeItems.setText("x " + Integer.parseInt(ProductsSingleton.getInstance().getPromotionList().get(position).getRange_limit().get(j).getAdd_on()));
                                myViewHolder.layoutPromotions.setVisibility(View.VISIBLE);
                                promotionCheck = false;
                                break;
                            } else if (Integer.valueOf(count) > 0 && Integer.valueOf(count) < min && j == 0) {
                                myViewHolder.layoutPromotions.setVisibility(View.VISIBLE);
                                Log.d("count......", "....." + (productId));
                                myViewHolder.tvPromotionRemainingItems.setText("" + mContext.getResources().getString(R.string._string_Remaining) + (int) (min - Integer.valueOf(count)));
                                myViewHolder.tvPromotionFreeItems.setText("x " + 0);
                                promotionCheck = false;
                                break;
                            } else if ((j == ProductsSingleton.getInstance().getPromotionList().get(position).getRange_limit().size() - 1) && Integer.valueOf(count) >= max) {
                                myViewHolder.tvPromotionRemainingItems.setText("" + mContext.getResources().getString(R.string._string_Remaining) + "0");
                                myViewHolder.tvPromotionFreeItems.setText("x " + Integer.parseInt(ProductsSingleton.getInstance().getPromotionList().get(position).getRange_limit().get(j).getAdd_on()));
                                myViewHolder.layoutPromotions.setVisibility(View.VISIBLE);
                                promotionCheck = false;
                                break;
                            }

                        }
                    } else if (ProductsSingleton.getInstance().getPromotionList().get(position).getPromotion_level().equals("product")) {
                        if (Double.parseDouble(ProductsSingleton.getInstance().getPromotionList().get(position).getQuantity()) > 0 &&
                                Double.parseDouble(ProductsSingleton.getInstance().getPromotionList().get(position).getAddOn()) > 0) {
                            Log.d("printsome", "" + productId);
                            Double baseQuanitity = Double.parseDouble(ProductsSingleton.getInstance().getPromotionList().get(position).getQuantity());
                            Double addOn = Double.parseDouble(ProductsSingleton.getInstance().getPromotionList().get(position).getAddOn());
                            Double counter = Double.parseDouble(count);
                            Double mod = counter % baseQuanitity;
                            myViewHolder.tvPromotionRemainingItems.setText("" + mContext.getResources().getString(R.string._string_Remaining) + (int) (baseQuanitity - mod));
                            Double freeItemcount = ((counter - mod) / baseQuanitity) * addOn;
                            myViewHolder.tvPromotionFreeItems.setText("x " + (int) Math.round(freeItemcount) + "");
                            myViewHolder.layoutPromotions.setVisibility(View.VISIBLE);
                            Log.d("printsome11111", "" + productId);
                            promotionCheck = false;
                        }
                    }

                    break;
                } else {
                    myViewHolder.layoutPromotions.setVisibility(View.GONE);
                }

            }

        }

    }


/*
    private void setPromotion(String count, String productId, int position, MyViewHolder myViewHolder){
        for (int i = 0; i < ProductsSingleton.getInstance().getPromotionList().get(position).getProduct_id_list().size(); i++){

            if (ProductsSingleton.getInstance().getPromotionList().get(position).getProduct_id_list().get(i).equals(productId)){

                if (ProductsSingleton.getInstance().getPromotionList().get(position).getRange_limit().size()>0) {

                    for (int j = 0; j < ProductsSingleton.getInstance().getPromotionList().get(position).getRange_limit().size(); j++) {

                        Double max = Double.valueOf(ProductsSingleton.getInstance().getPromotionList().get(position).getRange_limit().get(j).getMax());
                        Double min = Double.valueOf(ProductsSingleton.getInstance().getPromotionList().get(position).getRange_limit().get(j).getMin());
                        if (Integer.valueOf(count) >= min && Integer.valueOf(count) <= max) {

                            if (j == ProductsSingleton.getInstance().getPromotionList().get(position).getRange_limit().size()-1){
                                myViewHolder.tvPromotionRemainingItems.setText(""+mContext.getResources().getString(R.string._string_Remaining)+"0");
                            }else {
                                myViewHolder.tvPromotionRemainingItems.setText(""+mContext.getResources().getString(R.string._string_Remaining) + (int) (max - Integer.valueOf(count) + 1));
                            }

                            myViewHolder.tvPromotionFreeItems.setText("x " + Integer.parseInt(ProductsSingleton.getInstance().getPromotionList().get(position).getRange_limit().get(j).getAdd_on()));
                            myViewHolder.layoutPromotions.setVisibility(View.VISIBLE);
                            promotionCheck =false;
                            break;
                        } else if (Integer.valueOf(count) > 0 && Integer.valueOf(count) < min && j == 0) {
                            myViewHolder.layoutPromotions.setVisibility(View.VISIBLE);
                            Log.d("count......", "....." + (productId));
                            myViewHolder.tvPromotionRemainingItems.setText(""+mContext.getResources().getString(R.string._string_Remaining) + (int)(min - Integer.valueOf(count)));
                            myViewHolder.tvPromotionFreeItems.setText("x " + 0);
                            promotionCheck =false;
                            break;
                        }else if ((j == ProductsSingleton.getInstance().getPromotionList().get(position).getRange_limit().size()-1)&&Integer.valueOf(count) >= max){
                            myViewHolder.tvPromotionRemainingItems.setText(""+mContext.getResources().getString(R.string._string_Remaining)+"0");
                            myViewHolder.tvPromotionFreeItems.setText("x " + Integer.parseInt(ProductsSingleton.getInstance().getPromotionList().get(position).getRange_limit().get(j).getAdd_on()));
                            myViewHolder.layoutPromotions.setVisibility(View.VISIBLE);
                            promotionCheck =false;
                            break;
                        }

                    }
                }else
                if (ProductsSingleton.getInstance().getPromotionList().get(position).getPromotion_level().equals("product")){
                    if (Double.parseDouble(ProductsSingleton.getInstance().getPromotionList().get(position).getQuantity())>0&&
                            Double.parseDouble(ProductsSingleton.getInstance().getPromotionList().get(position).getAddOn())>0)
                    {
                        Log.d("printsome",""+productId);
                        Double baseQuanitity = Double.parseDouble(ProductsSingleton.getInstance().getPromotionList().get(position).getQuantity());
                        Double addOn = Double.parseDouble(ProductsSingleton.getInstance().getPromotionList().get(position).getAddOn());
                        Double counter = Double.parseDouble(count);
                        Double mod = counter%baseQuanitity;
                        myViewHolder.tvPromotionRemainingItems.setText(""+mContext.getResources().getString(R.string._string_Remaining)+(int)(baseQuanitity-mod));
                        Double freeItemcount = ((counter-mod)/baseQuanitity)*addOn;
                        myViewHolder.tvPromotionFreeItems.setText("x "+(int)Math.round(freeItemcount)+"");
                        myViewHolder.layoutPromotions.setVisibility(View.VISIBLE);
                        Log.d("printsome11111",""+productId);
                        promotionCheck =false;
                    }
                }

                break;
            }
            else {
                myViewHolder.layoutPromotions.setVisibility(View.GONE);
            }

        }

    }
*/


    private void ArabicData(MyViewHolder holder,int position){
        //    holder.si_home_Products_tvTitle.
          //          setTypeface(Typeface.createFromAsset(mContext.getAssets(), "fonts/roboto_bold.ttf"), Typeface.NORMAL);
            holder.si_home_Products_tvPrice.setText(Utils.convertString(productList.get(position).getPrice_vat()));
            holder.si_home_Products_tvTitle.
                    setTypeface(Typeface.createFromAsset(mContext.getAssets(), "fonts/neo_sans_bold.ttf"), Typeface.BOLD);


            String name=productList.get(position).getNameAr().replace(")","");

            String replacename=name.replaceAll("[\\(\\(]","%");

            String[] name_array=replacename.split("%");
            holder.si_home_Products_tvTitle.setText(name_array[0]);

            if(name_array.length>1){

                holder.si_home_Products_tvDetails.setText("("+name_array[1]+")");
            }
            else{


            }

        }

    private void EnglishData(MyViewHolder holder, int position){
       // holder.si_home_Products_tvTitle.setTypeface(Typeface.createFromAsset(mContext.getAssets(), "fonts/roboto_bold.ttf"), Typeface.NORMAL);
        //holder.si_home_Products_tvDetails.setTypeface(Typeface.createFromAsset(mContext.getAssets(), "roboto_regular.ttf"), Typeface.NORMAL);

        holder.si_home_Products_tvPrice.setText(productList.get(position).getPrice_vat());
        String[] name_array=productList.get(position).getNameEn().trim().split("\\(");

        holder.si_home_Products_tvTitle.setText(name_array[0]);

        if(name_array.length>1){

            holder.si_home_Products_tvDetails.setText("("+name_array[1]);
        }
        else{
            holder.si_home_Products_tvDetails.setText(productList.get(position).getNameEn());

        }
    }

    @Override
    public int getItemCount() {
        return productList.size();
    }

    @Override
    public int getItemViewType(int position) {
        return position;
    }


    public void setProductList(List<ProductByLocation> productList) {
        this.productList = productList;
        notifyDataSetChanged();
    }

    public void updateAmount() {

        String[] data = Cart.getTotalItemsAndPrice();
        if (data != null) {

                String amount=String.format("%.2f",Cart.getTotalPriceVat());
                ProductsSingleton.getInstance().getTv_cartamount().setText(Utils.convertString(amount)+" "+mContext.getResources().getString(R.string.currency));

        } else {
            ProductsSingleton.getInstance().getCartView().setVisibility(View.GONE);


        }

        if(Cart.getTotalItems()<1){
            ProductsSingleton.getInstance().getBasketview().setVisibility(View.VISIBLE);
        }
        else{
            ProductsSingleton.getInstance().getBasketview().setVisibility(View.VISIBLE);

        }

    }

    @Override
    public long getItemId(int position) {
        return position;
    }
}
