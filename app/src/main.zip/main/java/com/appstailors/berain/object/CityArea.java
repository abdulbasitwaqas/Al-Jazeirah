package com.appstailors.berain.object;

/**
 * Created by Mustanser Iqbal on 12/7/2017.
 */

public class CityArea {

    private int area_active, area_city_id, area_country_id, area_id;

    private String area_title_ar, area_title_en;

    private String google_area_en, google_area_ar;

    public int getArea_active() {
        return area_active;
    }

    public void setArea_active(int area_active) {
        this.area_active = area_active;
    }

    public int getArea_city_id() {
        return area_city_id;
    }

    public void setArea_city_id(int area_city_id) {
        this.area_city_id = area_city_id;
    }

    public int getArea_country_id() {
        return area_country_id;
    }

    public void setArea_country_id(int area_country_id) {
        this.area_country_id = area_country_id;
    }

    public int getArea_id() {
        return area_id;
    }

    public void setArea_id(int area_id) {
        this.area_id = area_id;
    }

    public String getArea_title_ar() {
        return area_title_ar;
    }

    public void setArea_title_ar(String area_title_ar) {
        this.area_title_ar = area_title_ar;
    }

    public String getArea_title_en() {
        return area_title_en;
    }

    public void setArea_title_en(String area_title_en) {
        this.area_title_en = area_title_en;
    }

    public String getGoogle_area_en() {
        return google_area_en;
    }

    public void setGoogle_area_en(String google_area_en) {
        this.google_area_en = google_area_en;
    }

    public String getGoogle_area_ar() {
        return google_area_ar;
    }

    public void setGoogle_area_ar(String google_area_ar) {
        this.google_area_ar = google_area_ar;
    }
}
