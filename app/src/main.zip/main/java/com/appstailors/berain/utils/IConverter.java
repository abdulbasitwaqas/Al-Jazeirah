package com.appstailors.berain.utils;

import java.io.File;

/**
 * Created by optymyzetech on 24/12/2018.
 */

   public interface IConverter {

    public void getConvertedFile(File file);
}
