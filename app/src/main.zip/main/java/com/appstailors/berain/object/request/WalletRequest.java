package com.appstailors.berain.object.request;

public class WalletRequest {
    private String user_id;
    public WalletRequest(String user_id){
        this.user_id=user_id;
    }

}
