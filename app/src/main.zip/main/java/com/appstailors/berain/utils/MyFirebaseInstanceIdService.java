package com.appstailors.berain.utils;
import android.content.Context;
import android.util.Log;
import com.appstailors.berain.UserSession;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.FirebaseInstanceIdService;
import java.util.Locale;

public class MyFirebaseInstanceIdService extends FirebaseInstanceIdService {
    private static final String TAG = "MYFireBaseToken";
    @Override
    public void onTokenRefresh() {
        super.onTokenRefresh();
        String refreshedtoken = FirebaseInstanceId.getInstance().getToken();
        Log.e("Refreshed Token",refreshedtoken);
        System.out.println("Refresh Token is"+refreshedtoken);
//        storeToken(refreshedtoken);
    }

}
