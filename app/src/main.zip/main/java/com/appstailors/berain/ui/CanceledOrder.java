package com.appstailors.berain.ui;

import android.content.Context;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.appstailors.berain.R;
import com.appstailors.berain.UserSession;
import com.appstailors.berain.utils.BerainContextWrapper;
import com.appstailors.berain.utils.ProductsSingleton;

import java.util.Locale;

import io.github.inflationx.viewpump.ViewPumpContextWrapper;

public class CanceledOrder extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_canceled_order);

        Button canceledOrder_btnMyOrders=findViewById(R.id.canceledOrder_btnMyOrders);
        canceledOrder_btnMyOrders.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ProductsSingleton.getInstance().getCustomViewPager().setCurrentItem(0);
                finish();
                overridePendingTransition(R.anim.enter_anim,0);
            }
        });




    }

    @Override
    protected void attachBaseContext(Context newBase) {
        Context context = BerainContextWrapper.wrap(newBase, new Locale(UserSession.getInstance().getUserLanguage()));
        super.attachBaseContext(ViewPumpContextWrapper.wrap(context));
    }
}
