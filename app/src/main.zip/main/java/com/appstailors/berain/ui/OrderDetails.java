package com.appstailors.berain.ui;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatCheckBox;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RatingBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.appstailors.berain.AppController;
import com.appstailors.berain.R;
import com.appstailors.berain.UserSession;
import com.appstailors.berain.adapter.OrderSummaryRecycler;
import com.appstailors.berain.adapter.YourOrderDetailRecycler;
import com.appstailors.berain.object.Cart;
import com.appstailors.berain.object.ProductByLocation;
import com.appstailors.berain.object.YourOrderDetails.OrderDetail;
import com.appstailors.berain.object.YourOrderDetails.YourOrderDetail;
import com.appstailors.berain.object.login.User;
import com.appstailors.berain.object.request.OrderRequest;
import com.appstailors.berain.object.request.RetingRequest;
import com.appstailors.berain.utils.APIManager;
import com.appstailors.berain.utils.BerainContextWrapper;
import com.appstailors.berain.utils.ProductsSingleton;
import com.appstailors.berain.utils.Utils;
import com.google.gson.Gson;

import com.roam.appdatabase.DatabaseManager;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import io.github.inflationx.viewpump.ViewPumpContextWrapper;

import static com.appstailors.berain.utils.Constants.ORDERS_SCREEN;

public class OrderDetails extends AppCompatActivity implements View.OnClickListener {
    String order_id;
    private static final String TAG ="Order Detail Activity" ;
    private ProgressDialog mProgressDialog;
    private boolean isArabic;
    LinearLayout llOrderShipped,llOrderVerified,llDelivered;
    LinearLayout rlPayementDetailView;
    LinearLayout orderdetailLayoutmain,layoutQitaf;
    RelativeLayout layoutNoDataFound;
    //Recycler
    RecyclerView orderdetailItemsList;
    YourOrderDetailRecycler orderAdapter;
    List<OrderDetail> orderDetailList=new ArrayList<>();
    ImageView imageViewBack;
    RelativeLayout rlCart;
    TextView tvToolbarTitle;
    TextView tvOrderID, tvReOrder;
    //Top Layer steps
   // LinearLayout llStepper;
    ImageView imageviewPlaced, imageviewVerified, imageViewShipped, imageViewDelivered;
    TextView tvOrderPlaced,tvVerified,tvShipped,tvDelivered,tv_qitaf_rewardpoints;
    View viewOrderPlaced,viewVerified,viewShipped,layoutWalletDiscount;
    ;
    //below Recycler
    AppCompatCheckBox radioButtonWallet;
    public TextView tvPaymentType, tvChangePaymentMethod, tvDeliveryAddress, tvChangeAddress,tvTransactionIdApplePay,tvTransactionId;
    public EditText editTextPromocode;
    public RadioButton radioButtonMorning, radioButtonEvening, radioButtonAnytime;
    public RadioButton radioButtonScheduleNone, radioButtonScheduleWeekly, radioButtonScheduleEveryMonth;
    RelativeLayout rlPromoView;
    //bottom Payment Details
    TextView tvOrderItems,tv_please_rate,tvWalletDiscountValue,tvVAT, tvPromocodeValueA,tvPromocodeValueB,tvWallet,tvGrandTotal,tvDevliveryMan,tvDevliveryTime,tvSubmitRating;

    RecyclerView orderSummaryRecyclerView;
    TextView tvOrderSummery,orderSummarytvPaymentType,tvUseWallet,tvSummaryAddress,tvSummaryDeliveryTime,tvSummarySchedule,editUserRemarks;

    private View ratingview;
    LinearLayout layoutProductQuality;
    RatingBar ProductQuality,DeliveryTime,retingDeliveryMan;
    User user= DatabaseManager.getInstance().getFirstOfClass(User.class);
    View orderDetaiMain,wallet_view, layoutPromocodeB,layoutPromocodeA;
    boolean isViewSummery =false;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_detail);
        isArabic = AppController.setLocale();
        order_id =getIntent().getStringExtra("order_id");
        initViews();
        TextView tv_items = findViewById(R.id.tv_items);
        TextView tv_paymentoptions = findViewById(R.id.tv_paymentoptions);

        TextView tv_da = findViewById(R.id.tv_da);
        TextView tv_dt = findViewById(R.id.tv_dt);
        TextView tv_so = findViewById(R.id.tv_so);

        if (isArabic) {
            tv_items.setTypeface(Typeface.createFromAsset(getAssets(),
                    "neo_sans_arabic.ttf"), Typeface.BOLD);
            tv_paymentoptions.setTypeface(Typeface.createFromAsset(getAssets(),
                    "neo_sans_arabic.ttf"), Typeface.BOLD);

            tv_da.setTypeface(Typeface.createFromAsset(getAssets(),
                    "neo_sans_arabic.ttf"), Typeface.BOLD);
            tv_dt.setTypeface(Typeface.createFromAsset(getAssets(),
                    "neo_sans_arabic.ttf"), Typeface.BOLD);
            tv_so.setTypeface(Typeface.createFromAsset(getAssets(),
                    "neo_sans_arabic.ttf"), Typeface.BOLD);
        }
        else{
            tv_items.setTypeface(Typeface.createFromAsset(getAssets(),
                    "fonts/roboto_bold.ttf"), Typeface.BOLD);
            tv_paymentoptions.setTypeface(Typeface.createFromAsset(getAssets(),
                    "fonts/roboto_bold.ttf"), Typeface.BOLD);
            tv_da.setTypeface(Typeface.createFromAsset(getAssets(),
                    "fonts/roboto_bold.ttf"), Typeface.BOLD);
            tv_dt.setTypeface(Typeface.createFromAsset(getAssets(),
                    "fonts/roboto_bold.ttf"), Typeface.BOLD);
            tv_so.setTypeface(Typeface.createFromAsset(getAssets(),
                    "fonts/roboto_bold.ttf"), Typeface.BOLD);

        }
        //TODO change hardcoded client ID
        User user = DatabaseManager.getInstance().getFirstOfClass(User.class);
        getOrderDetails(user.userId, order_id);

        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
        if (isArabic) {
            getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        } else {
            getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        }

    }

    private void initViews() {
        orderdetailItemsList =findViewById(R.id.orderdetailItemsList);
        //Toolbar
        imageViewBack =findViewById(R.id.imageViewBack);
        rlCart=findViewById(R.id.badge_view);
        rlCart.setVisibility(View.GONE);
        imageViewBack.setVisibility(View.VISIBLE);
        imageViewBack.setOnClickListener(this);
        tvToolbarTitle=findViewById(R.id.tvToolbarTitle);
        layoutPromocodeB =findViewById(R.id.layoutPromocodeB);
        layoutPromocodeA =findViewById(R.id.layoutPromocodeA);
        tvToolbarTitle.setText(getResources().getString(R.string.Order_Details));
        ratingview=findViewById(R.id.ratingview);
        tvOrderID=findViewById(R.id.tvOrderID);
        tvReOrder =findViewById(R.id.tvReOrder);
        wallet_view=findViewById(R.id.wallet_view);
        radioButtonMorning = findViewById(R.id.radioButtonMorning);
        radioButtonEvening = findViewById(R.id.radioButtonEvening);
        radioButtonAnytime =findViewById(R.id.radioButtonAnytime);
        llOrderVerified=findViewById(R.id.layoutOrderVerified);
        llOrderShipped=findViewById(R.id.layoutShipped);
        rlPayementDetailView=findViewById(R.id.paymentDetailView);
        llDelivered=findViewById(R.id.layoutDelivered);
        tvTransactionIdApplePay=findViewById(R.id.tvTransactionIdApplePay);
        tvTransactionId=findViewById(R.id.tvTransactionId);
        //llStepper=findViewById(R.id.orderdetailUpdated_llStepper);
        imageviewPlaced =findViewById(R.id.imageviewPlaced);
        imageviewVerified =findViewById(R.id.imageviewVerified);
        imageViewShipped =findViewById(R.id.imageViewShipped);
        imageViewDelivered =findViewById(R.id.imageViewDelivered);
        tvWalletDiscountValue = findViewById(R.id.tvWalletDiscountValue);

        tvOrderPlaced=findViewById(R.id.tvOrderPlaced);
        tvVerified=findViewById(R.id.tvVerified);
        tvShipped=findViewById(R.id.tvShipped);
        tvDelivered=findViewById(R.id.tvDelivered);

        viewOrderPlaced=findViewById(R.id.view_orderplaced);
        viewVerified=findViewById(R.id.view_verified);
        viewShipped=findViewById(R.id.view_shipped);

       TextView textview_addpromocode = findViewById(R.id.tvAddpromoCode);
            textview_addpromocode.setVisibility(View.GONE );
        //below RecyclerView
        radioButtonWallet =findViewById(R.id.radioButtonWallet);
        tvPaymentType = findViewById(R.id.tvPaymentType);
        tvChangePaymentMethod = findViewById(R.id.paymentOptionView_tvChange);
        tvChangePaymentMethod.setOnClickListener(this);
        tvChangePaymentMethod.setVisibility(View.GONE);
        tvDeliveryAddress = findViewById(R.id.tvDeliveryAddress);
        tvChangeAddress = findViewById(R.id.deliveryAddressView_tvChangeAddress);
        tvChangeAddress.setOnClickListener(this);
        tvChangeAddress.setVisibility(View.GONE);

        radioButtonScheduleNone = findViewById(R.id.radioButtonScheduleNone);
        radioButtonScheduleWeekly = findViewById(R.id.radioButtonScheduleWeekly);
        radioButtonScheduleEveryMonth = findViewById(R.id.radioButtonScheduleEveryMonth);
        rlPromoView=findViewById(R.id.promoView_layout);
        editTextPromocode =findViewById(R.id.editTextPromocode);

        //bottom Payment Details
        tvOrderItems=findViewById(R.id.textview_orderitemsvalue);
        tv_please_rate=findViewById(R.id.tv_please_rate);
        tvVAT=findViewById(R.id.textview_vatvalue);
        tvPromocodeValueB =findViewById(R.id.tvPromocodeValueB);
        tvPromocodeValueA =findViewById(R.id.tvPromocodeValueA);
        tvWallet=findViewById(R.id.textview_walletvalue);
        tvGrandTotal=findViewById(R.id.textview_totalvalue);
        layoutWalletDiscount=findViewById(R.id.layoutWalletDiscount);

        //Order Summary
        orderSummaryRecyclerView =findViewById(R.id.orderSummaryRecyclerView);
        orderSummarytvPaymentType =findViewById(R.id.orderSummarytvPaymentType);
        tvOrderSummery =findViewById(R.id.tvOrderSummery);
        tvUseWallet=findViewById(R.id.layout_order_summary_tvUseWallet);
        tvSummaryAddress=findViewById(R.id.layout_order_summary_tvAddress);
        tvSummaryDeliveryTime=findViewById(R.id.layout_order_summary_tvDeliveryTime);
        tvSummarySchedule=findViewById(R.id.layout_order_summary_tvScheduleOrder);
        editUserRemarks=findViewById(R.id.editUserRemarks);

        orderdetailLayoutmain =findViewById(R.id.orderdetailLayoutmain);
        layoutQitaf=findViewById(R.id.layoutQitaf);
        tv_qitaf_rewardpoints=findViewById(R.id.tv_qitaf_rewardpoints);
        layoutNoDataFound =findViewById(R.id.layoutNoDataFound);
        tvDevliveryTime=findViewById(R.id.tvDevliveryTime);
        tvDevliveryMan=findViewById(R.id.tvDevliveryMan);
        ProductQuality=findViewById(R.id.layout_order_delivered_retingProductQuality);
        DeliveryTime=findViewById(R.id.layout_order_delivered_retingDeliveryTime);
        retingDeliveryMan=findViewById(R.id.retingDeliveryMan);
        layoutProductQuality=findViewById(R.id.layoutProductQuality);
        tvSubmitRating=findViewById(R.id.tvSubmitRating);
        orderDetaiMain=findViewById(R.id.order_detai_rlmain);
       //orderDetaiMain.setVisibility(View.GONE);
        orderdetailLayoutmain.setVisibility(View.GONE);
        tvOrderSummery.setOnClickListener(this);



        tvReOrder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cart.emptyCart();
                for (OrderDetail orderDetail : orderDetailList) {
                    ProductByLocation product = new ProductByLocation();
                    product.setId(orderDetail.getDishId());
                    product.setNameAr(orderDetail.getDishTitleAr());
                    product.setNameEn(orderDetail.getDishTitleEn());
                    product.setPrice(orderDetail.getDishPrice());
                    product.setPrice_vat(orderDetail.getPrice_vat());
                    product.setImg(orderDetail.getDishImage());
                    if(orderDetail.getProd_curr_status().equals("1")&&(orderDetail.getFreeGoods().equals("0")||orderDetail.getFreeGoods().equals("")))
                        Cart.addToCart(product,-1, Integer.parseInt(orderDetail.getOrdCount()));            }
                Intent intent = new Intent(OrderDetails.this, CheckOutActivity.class);
                startActivityForResult(intent, ORDERS_SCREEN);
                ProductsSingleton.getInstance().getCustomViewPager().setCurrentItem(0);
                if (ProductsSingleton.getInstance().getProductByLocations()!=null){
                    updateCart();
                }
                finish();

            }
        });

        if (user!=null){
            if (user.hide_price.equals("1")){
                ((LinearLayout) findViewById(R.id.paymentDetailView)).setVisibility(View.GONE);
            }
        }
 }

    private void updateCart(){
        List<Cart> cartList;
        cartList = DatabaseManager.getInstance().getAllOfClass(Cart.class);
        for(int j=0;j<cartList.size();j++){
            boolean cartCheck = true;
            for (int k = 0; k < ProductsSingleton.getInstance().getProductByLocations().size(); k++) {
                Log.d("cartitemcount",  ""+ProductsSingleton.getInstance().getProductByLocations().get(k).getId().toString()+","+cartList.get(j).productId.toString());

                if (ProductsSingleton.getInstance().getProductByLocations().get(k).getId().toString().equals(cartList.get(j).productId.toString())) {
                    Log.d("cartitemcount", cartList.get(j).count + "");
                    Cart.addMultipleItem(ProductsSingleton.getInstance().getProductByLocations().get(k).getId(),cartList.get(j).count,ProductsSingleton.getInstance().getProductByLocations().get(k));
                    cartCheck = false;
                }
            }
            if (cartCheck)
            {
                Log.d("cartitemcount",  "....."+cartCheck);
                Cart.deleteProductFromCart(cartList.get(j).productId);
            }
        }


        User user  = DatabaseManager.getInstance().getFirstOfClass(User.class);
        if (user!=null){
            if (user.hide_price.equals("1")){
                ProductsSingleton.getInstance().getTv_cartamount().setVisibility(View.GONE);
            }
        }
    }

    private void getOrderDetails(String clientID, final String orderID){

        showProgress(true);
        APIManager.getInstance().getOrderDetails(new APIManager.Callback() {
            @Override
            public void onResult(boolean z, String response) {
                showProgress(false);
                if (z) {
                    try {
                        if (new JSONObject(response).getString("order").equals("false")){
                            orderdetailLayoutmain.setVisibility(View.GONE);
                            layoutNoDataFound.setVisibility(View.VISIBLE);
                        }else {
                            YourOrderDetail orderDetail = new Gson().fromJson(response, YourOrderDetail.class);
                            orderDetailList = orderDetail.getOrder().getOrderDetail();
                            setOrderDetailsViews(orderDetail);

                            saveOrderRating(order_id);
                            orderdetailLayoutmain.setVisibility(View.VISIBLE);

                        }

                    } catch (Exception e) {
                        e.printStackTrace();
                        Log.e(TAG, "onResult: "+e.getMessage() );
                        orderdetailLayoutmain.setVisibility(View.GONE);
                        layoutNoDataFound.setVisibility(View.VISIBLE);
                    }
                }else {
                    Toast.makeText(OrderDetails.this, "No Detail Found", Toast.LENGTH_SHORT).show();
                }
            }
        }, new OrderRequest(clientID,orderID,""));

        }

     private void setOrderDetailsViews(YourOrderDetail orderDetail){
         if (orderDetail.getOrder().getCurrentStatus().equals("5") ||orderDetail.getOrder().getCurrentStatus().equals("2")){
             llOrderVerified.setVisibility(View.VISIBLE);
             llOrderShipped.setVisibility(View.GONE);
             llDelivered.setVisibility(View.GONE);

             imageviewPlaced.setImageResource(R.drawable.icon_orderplaced_green);
             tvOrderPlaced.setTextColor(getResources().getColor(R.color.tab_selected));
             viewOrderPlaced.setBackgroundColor(getResources().getColor(R.color.tab_selected));

             if (orderDetail.getOrder().getCurrentStatus().equals("5")){
                 imageviewVerified.setImageResource(R.drawable.icon_verified_purple);
                 tvVerified.setTextColor(getResources().getColor(R.color.text_purple));
             }else {
                 imageviewVerified.setImageResource(R.drawable.icon_verified_green);
                 tvVerified.setTextColor(getResources().getColor(R.color.tab_selected));
             }

             imageViewShipped.setImageResource(R.drawable.icon_shipped_purple);
             imageViewDelivered.setImageResource(R.drawable.icon_delivered_purple);
             tvShipped.setTextColor(getResources().getColor(R.color.text_purple));
             tvDelivered.setTextColor(getResources().getColor(R.color.text_purple));

         }

         if (orderDetail.getOrder().getCurrentStatus().equals("3")){
             llOrderVerified.setVisibility(View.GONE);
             llOrderShipped.setVisibility(View.VISIBLE);
             llDelivered.setVisibility(View.GONE);
             imageviewPlaced.setImageResource(R.drawable.icon_orderplaced_green);
             imageviewVerified.setImageResource(R.drawable.icon_verified_green);
             imageViewShipped.setImageResource(R.drawable.icon_shipped_green);
             imageViewDelivered.setImageResource(R.drawable.icon_delivered_purple);

             tvOrderPlaced.setTextColor(getResources().getColor(R.color.tab_selected));
             tvVerified.setTextColor(getResources().getColor(R.color.tab_selected));
             tvShipped.setTextColor(getResources().getColor(R.color.tab_selected));
             tvDelivered.setTextColor(getResources().getColor(R.color.text_purple));

         }else if (orderDetail.getOrder().getCurrentStatus().equals("4")){
             llOrderVerified.setVisibility(View.GONE);
             llOrderShipped.setVisibility(View.GONE);
             llDelivered.setVisibility(View.VISIBLE);
             rlPayementDetailView.setVisibility(View.GONE);
             imageviewPlaced.setImageResource(R.drawable.icon_orderplaced_green);
             imageviewVerified.setImageResource(R.drawable.icon_verified_green);
             imageViewShipped.setImageResource(R.drawable.icon_shipped_green);
             imageViewDelivered.setImageResource(R.drawable.icon_delivered_green);

             tvOrderPlaced.setTextColor(getResources().getColor(R.color.tab_selected));
             tvVerified.setTextColor(getResources().getColor(R.color.tab_selected));
             tvShipped.setTextColor(getResources().getColor(R.color.tab_selected));
             tvDelivered.setTextColor(getResources().getColor(R.color.tab_selected));


             if (orderDetail.getOrder().getQitaf_rewardpoints().equals("0")||orderDetail.getOrder().getQitaf_rewardpoints().equals("")){
                 layoutQitaf.setVisibility(View.GONE);
             }else {

                 tv_qitaf_rewardpoints.setText(orderDetail.getOrder().getQitaf_rewardpoints()+" "+getResources().getString(R.string.st_qitaf_rewardpoints_points));

             }
/*
             tvOrderSummery.setOnClickListener(new View.OnClickListener() {
                 @Override
                 public void onClick(View v) {

                 }
             });*/


         }

         tvOrderID.setText(getResources().getString(R.string.Order_id)+orderDetail.getOrder().getOrdId());
         if (orderDetail.getOrder().getIsreorderable().equals("1")){tvReOrder.setVisibility(View.VISIBLE);}

         if (!orderDetail.getOrder().getPaymentTransaction().equals("")) {
             tvTransactionId.setText(""+getResources().getString(R.string.st_transaction_created) +":"  + orderDetail.getOrder().getPaymentTransaction());
             tvTransactionId.setVisibility(View.VISIBLE);
         }

      /*   if (!orderDetail.getOrder().getApple_pay_trans().equals("")) {
             tvTransactionIdApplePay.setText("Apple Pay "+getResources().getString(R.string.st_transaction_created)+":\n" + orderDetail.getOrder().getApple_pay_trans());
             tvTransactionIdApplePay.setVisibility(View.VISIBLE);
         }*/

         orderdetailItemsList.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
         orderAdapter = new YourOrderDetailRecycler(this, orderDetailList);
         orderdetailItemsList.setAdapter(orderAdapter);

         if (isArabic){
             tvPaymentType.setText(orderDetail.getOrder().getPaymentTypeAr());
         }
         else {
             tvPaymentType.setText(orderDetail.getOrder().getPaymentTypeEn());
         }

         radioButtonWallet.setEnabled(false);

         if(Double.parseDouble(orderDetail.getOrder().getWalletAmount())>0){
             radioButtonWallet.setChecked(true);
         }
         else{
             radioButtonWallet.setChecked(false);
             radioButtonWallet.setVisibility(View.GONE);
         }

         tvDeliveryAddress.setText(orderDetail.getOrder().getAddress());

         radioButtonMorning.setEnabled(false);
         radioButtonEvening.setEnabled(false);
         radioButtonAnytime.setEnabled(false);
         radioButtonScheduleNone.setEnabled(false);
         radioButtonScheduleWeekly.setEnabled(false);
         radioButtonScheduleEveryMonth.setEnabled(false);
         if(orderDetail.getOrder().getPreferedTime().equals("1")){
             radioButtonMorning.setChecked(true);
             radioButtonMorning.setVisibility(View.VISIBLE);
         }
         else if(orderDetail.getOrder().getPreferedTime().equals("2")){
             radioButtonEvening.setChecked(true);
             radioButtonEvening.setVisibility(View.VISIBLE);

         }
         else if(orderDetail.getOrder().getPreferedTime().equals("3")){
             radioButtonAnytime.setChecked(true);
             radioButtonAnytime.setVisibility(View.VISIBLE);
         }

         if(orderDetail.getOrder().getRecurring().equals("0")){
             radioButtonScheduleNone.setChecked(true);
         }
         else if(orderDetail.getOrder().getRecurring().equals("2")){
             radioButtonScheduleWeekly.setChecked(true);
         }
         else if(orderDetail.getOrder().getRecurring().equals("3")){
             radioButtonScheduleEveryMonth.setChecked(true);
         }

         if (orderDetail.getOrder().getPromocode()!=null){
             editTextPromocode.setText(orderDetail.getOrder().getPromocode());
             editTextPromocode.setEnabled(false);
         }else {
             rlPromoView.setVisibility(View.GONE);
         }

         orderSummaryRecyclerView.setHasFixedSize(true);
         orderSummaryRecyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
         orderSummaryRecyclerView.setAdapter(new OrderSummaryRecycler(orderDetailList));

         if(isArabic)
         {
             orderSummarytvPaymentType.setText(orderDetail.getOrder().getPaymentTypeAr());
             tvUseWallet.setVisibility(View.GONE);
             tvSummaryAddress.setText(orderDetail.getOrder().getAddress());
             tvSummaryDeliveryTime.setText(orderDetail.getOrder().getDeliveryTimeAr());
             tvSummarySchedule.setText(getResources().getString(R.string.st_none));
         }else {
             orderSummarytvPaymentType.setText(orderDetail.getOrder().getPaymentTypeEn());
             tvUseWallet.setVisibility(View.GONE);
             tvSummaryAddress.setText(orderDetail.getOrder().getAddress());
             tvSummaryDeliveryTime.setText(orderDetail.getOrder().getDeliveryTimeEn());
             tvSummarySchedule.setText(getResources().getString(R.string.st_none));
         }
         editUserRemarks.setText(""+orderDetail.getOrder().getCustomer_comments());
         if (orderDetail.getOrder().getDeliveryTimeRating().equals("")&&orderDetail.getOrder().getCustomerServRating().equals("")
                 &&orderDetail.getOrder().getProdQualityRating().equals("")){
             tvDevliveryMan.setText(""+getResources().getString(R.string.st_staisfaction_with_representative));
             tvDevliveryTime.setText(""+getResources().getString(R.string.st_ratting_experience_with_berain));
             editUserRemarks.setVisibility(View.VISIBLE);
             editUserRemarks.setEnabled(true);
             editUserRemarks.setText("");

         }else if((orderDetail.getOrder().getProdQualityRating().equals("")&&!orderDetail.getOrder().getCustomerServRating().equals("")
                 &&!orderDetail.getOrder().getDeliveryTimeRating().equals(""))){
             tvDevliveryMan.setText(""+getResources().getString(R.string.st_staisfaction_with_representative));
             tvDevliveryTime.setText(""+getResources().getString(R.string.st_ratting_experience_with_berain));
             retingDeliveryMan.setRating(Float.parseFloat(orderDetail.getOrder().getCustomerServRating()));
             retingDeliveryMan.setIsIndicator(true);

             DeliveryTime.setRating(Float.parseFloat(orderDetail.getOrder().getDeliveryTimeRating()));
             DeliveryTime.setIsIndicator(true);
             tv_please_rate.setVisibility(View.GONE);
             editUserRemarks.setEnabled(false);

         }
         else {
             editUserRemarks.setEnabled(false);
             layoutProductQuality.setVisibility(View.VISIBLE);
             ProductQuality.setRating(Float.parseFloat(orderDetail.getOrder().getProdQualityRating()));
            // ProductQuality.setIndicator(true);
             ProductQuality.setIsIndicator(true);

             retingDeliveryMan.setRating(Float.parseFloat(orderDetail.getOrder().getDeliveryTimeRating()));
             retingDeliveryMan.setIsIndicator(true);

             DeliveryTime.setRating(Float.parseFloat(orderDetail.getOrder().getCustomerServRating()));
            // DeliveryTime.setIndicator(true);
             DeliveryTime.setIsIndicator(true);
             tv_please_rate.setVisibility(View.GONE);

         }



         if (orderDetail.getOrder().getQitaf_rewardpoints().equals("0")||orderDetail.getOrder().getQitaf_rewardpoints().equals("")){
             layoutQitaf.setVisibility(View.GONE);
         }else {
             tv_qitaf_rewardpoints.setText(orderDetail.getOrder().getQitaf_rewardpoints()+" "+getResources().getString(R.string.st_qitaf_rewardpoints_points));
         }

         if(isArabic){
             tvOrderItems.setText(Utils.convertString(orderDetail.getOrder().getPriceWithoutVat()) + " " + getResources().getString(R.string.currency));
             tvVAT.setText(Utils.convertString(orderDetail.getOrder().getAmountVat()) + " " + getResources().getString(R.string.currency));
             tvWalletDiscountValue.setText("-" +Utils.convertString( orderDetail.getOrder().getWallet_discount()) + " " + getResources().getString(R.string.currency));
             tvWallet.setText("-" +Utils.convertString( orderDetail.getOrder().getWalletAmount()) + " " + getResources().getString(R.string.currency));
             tvGrandTotal.setText(Utils.convertString(orderDetail.getOrder().getGrandTotal()) + " " + getResources().getString(R.string.currency));
             if (orderDetail.getOrder().getAfter_vat().equals("1"))
                 tvPromocodeValueA.setText("-" +Utils.convertString( orderDetail.getOrder().getDiscountAmount()) + " " + getResources().getString(R.string.currency));
                 else
                     tvPromocodeValueB.setText("-" +Utils.convertString( orderDetail.getOrder().getDiscountAmount()) + " " + getResources().getString(R.string.currency));

         }
         else {
             tvOrderItems.setText(orderDetail.getOrder().getPriceWithoutVat() + " " + getResources().getString(R.string.currency));
             tvVAT.setText(orderDetail.getOrder().getAmountVat() + " " + getResources().getString(R.string.currency));
             tvWalletDiscountValue.setText("-" + orderDetail.getOrder().getWallet_discount() + " " + getResources().getString(R.string.currency));
             tvWallet.setText("-" + orderDetail.getOrder().getWalletAmount() + " " + getResources().getString(R.string.currency));
             tvGrandTotal.setText(orderDetail.getOrder().getGrandTotal() + " " + getResources().getString(R.string.currency));
             if (orderDetail.getOrder().getAfter_vat().equals("1"))
             tvPromocodeValueA.setText("-" + orderDetail.getOrder().getDiscountAmount() + " " + getResources().getString(R.string.currency));
             else
                 tvPromocodeValueB.setText("-" + orderDetail.getOrder().getDiscountAmount() + " " + getResources().getString(R.string.currency));

         }

         if(!orderDetail.getOrder().getPromocode().equals("")){
             if (orderDetail.getOrder().getAfter_vat().equals("1"))
                 layoutPromocodeA.setVisibility(View.VISIBLE);
             else
                 layoutPromocodeB.setVisibility(View.VISIBLE);
         }
         else{
             layoutPromocodeB.setVisibility(View.GONE);
             layoutPromocodeA.setVisibility(View.GONE);
         }

         if(Double.parseDouble(orderDetail.getOrder().getWalletAmount())>0){
             wallet_view.setVisibility(View.VISIBLE);
         }
         else{
             wallet_view.setVisibility(View.GONE);
         }


         if(Double.parseDouble(orderDetail.getOrder().getWallet_discount())>0){
             layoutWalletDiscount.setVisibility(View.VISIBLE);
         }
         else{
             layoutWalletDiscount.setVisibility(View.GONE);
         }

     }

    private void showProgress(boolean show) {
        if (show) {
            mProgressDialog = new ProgressDialog(this);
            mProgressDialog.setMessage(getResources().getString(R.string.please_wait));
            mProgressDialog.setIndeterminate(false);
            mProgressDialog.setCancelable(false);
            mProgressDialog.show();
        } else {
            if (mProgressDialog != null && mProgressDialog.isShowing()) {
                mProgressDialog.dismiss();
            }
        }
    }

    private void saveOrderRating(final String productID) {

   /*      DeliveryTime.setOnRatingBarChangeListener(new SimpleRatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(SimpleRatingBar simpleRatingBar, float rating, boolean fromUser) {

               if (rating>0 && retingDeliveryMan.getRating()>0){
                    tvSubmitRating.setVisibility(View.VISIBLE);
                }else {
                    tvSubmitRating.setVisibility(View.GONE);
                }

            }
        });*/


    /*    retingDeliveryMan.setOnRatingBarChangeListener(new SimpleRatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(SimpleRatingBar simpleRatingBar, float rating, boolean fromUser) {


                if (rating>0 && DeliveryTime.getRating()>0){
                    tvSubmitRating.setVisibility(View.VISIBLE);
                }else {
                    tvSubmitRating.setVisibility(View.GONE);
                }

            }
        });
*/


        DeliveryTime.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {

            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating,
                                        boolean fromUser) {
                Log.d("rating",""+rating);
                if (rating>0 && retingDeliveryMan.getRating()>0){
                    tvSubmitRating.setVisibility(View.VISIBLE);
                }else {
                    tvSubmitRating.setVisibility(View.GONE);
                }

            }
        });

        retingDeliveryMan.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {

            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating,
                                        boolean fromUser) {
                if (rating>0 && DeliveryTime.getRating()>0){
                    tvSubmitRating.setVisibility(View.VISIBLE);
                }else {
                    tvSubmitRating.setVisibility(View.GONE);
                }

            }
        });



        tvSubmitRating.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                APIManager.getInstance().saveOrderRating(new APIManager.Callback() {
                    @Override
                    public void onResult(boolean z, String response) {
                        try {
                            Toast.makeText(OrderDetails.this, ""+getResources().getString(R.string.st_rating_submitted), Toast.LENGTH_SHORT).show();
                            tvSubmitRating.setVisibility(View.GONE);
                            editUserRemarks.setEnabled(false);
                            DeliveryTime.setIsIndicator(true);
                            retingDeliveryMan.setIsIndicator(true);
                        } catch (Exception ex) {

                        }
                    }
                }, new RetingRequest(user.userId, order_id, retingDeliveryMan.getRating()+"", ""+DeliveryTime.getRating(), editUserRemarks.getText().toString().trim(),"0"));

            }
        });

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.imageViewBack:
                finish();
                break;
                case R.id.tvOrderSummery:
                    llOrderShipped.setVisibility(View.VISIBLE);
                    llDelivered.setVisibility(View.GONE);
                    if (user.hide_price.equals("1")){
                        rlPayementDetailView.setVisibility(View.GONE);

                    }else {
                        rlPayementDetailView.setVisibility(View.VISIBLE);
                    }
                    isViewSummery = true;
                break;
        }
    }

    @Override
    public void onBackPressed() {
        if (isViewSummery){
        llOrderShipped.setVisibility(View.GONE);
        llDelivered.setVisibility(View.VISIBLE);
        rlPayementDetailView.setVisibility(View.GONE);
        isViewSummery = false;}else
            {
        super.onBackPressed();
            }
    }

    @Override
    protected void attachBaseContext(Context newBase) {
        Context context = BerainContextWrapper.wrap(newBase, new Locale(UserSession.getInstance().getUserLanguage()));
        super.attachBaseContext(ViewPumpContextWrapper.wrap(context));
    }
}
