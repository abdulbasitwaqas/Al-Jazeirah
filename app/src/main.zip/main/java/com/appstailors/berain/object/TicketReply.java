package com.appstailors.berain.object;

public class TicketReply {

    String client_name;
    String reply_person_id;
    String reply_message;
    String reply_file_name;
    String date;

    public String getClient_name() {
        return client_name;
    }

    public void setClient_name(String client_name) {
        this.client_name = client_name;
    }

    public String getReply_person_id() {
        return reply_person_id;
    }

    public void setReply_person_id(String reply_person_id) {
        this.reply_person_id = reply_person_id;
    }

    public String getReply_message() {
        return reply_message;
    }

    public void setReply_message(String reply_message) {
        this.reply_message = reply_message;
    }

    public String getReply_file_name() {
        return reply_file_name;
    }

    public void setReply_file_name(String reply_file_name) {
        this.reply_file_name = reply_file_name;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
