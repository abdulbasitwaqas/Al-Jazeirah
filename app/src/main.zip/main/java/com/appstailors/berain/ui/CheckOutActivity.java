package com.appstailors.berain.ui;


import android.annotation.TargetApi;
import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatCheckBox;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.appsflyer.AFInAppEventParameterName;
import com.appsflyer.AFInAppEventType;
import com.appsflyer.AppsFlyerLib;
import com.appstailors.berain.AppController;
import com.appstailors.berain.R;
import com.appstailors.berain.UserSession;
import com.appstailors.berain.adapter.CartRecyclerAdapter;
import com.appstailors.berain.adapter.PromotionGroupAdapter;
import com.appstailors.berain.adapter.SelectPaymentMethodAdapter;
import com.appstailors.berain.object.Areas;
import com.appstailors.berain.object.Cart;
import com.appstailors.berain.object.CartParamResponse.CartParamResponse;
import com.appstailors.berain.object.CartParamResponse.LatestOrder;
import com.appstailors.berain.object.CartParamResponse.OrderItems;
import com.appstailors.berain.object.CartParamResponse.PaymentMethod;
import com.appstailors.berain.object.Cart_Params;
import com.appstailors.berain.object.Cities;
import com.appstailors.berain.object.CompanySetting;
import com.appstailors.berain.object.PlaceOrder;
import com.appstailors.berain.object.ProductByLocation;
import com.appstailors.berain.object.Promotions.Foc_prod;
import com.appstailors.berain.object.YourOrderDetails.OrderDetail;
import com.appstailors.berain.object.YourOrderDetails.YourOrderDetail;
import com.appstailors.berain.object.addressData;
import com.appstailors.berain.object.login.User;
import com.appstailors.berain.object.request.CheckStcRequest;
import com.appstailors.berain.object.request.OrderRequest;
import com.appstailors.berain.object.request.PromocodeRequest;
import com.appstailors.berain.object.request.TokenRequest;
import com.appstailors.berain.utils.APIManager;
import com.appstailors.berain.utils.BerainContextWrapper;
import com.appstailors.berain.utils.Constants;
import com.appstailors.berain.utils.CoreManager;
import com.appstailors.berain.utils.ProductsSingleton;
import com.appstailors.berain.utils.Utils;
import com.appstailors.berain.utils.recycler.DividerItemDecoration;
import com.clevertap.android.sdk.CleverTapAPI;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.gson.Gson;
import com.roam.appdatabase.DatabaseManager;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import io.github.inflationx.viewpump.ViewPumpContextWrapper;

import static com.appstailors.berain.utils.Constants.AMOUNT;
import static com.appstailors.berain.utils.Constants.validate_promocode;

/**
 * A simple {@link Fragment} subclass.
 */
public class CheckOutActivity extends AppCompatActivity implements View.OnClickListener,
        CartRecyclerAdapter.ICategory, CompoundButton.OnCheckedChangeListener {
    public static Activity orderdetailactivity;
    public final int REQUEST_FOR_ADDRESS = 102;
    public boolean isArabic;
    public RecyclerView rvcartProduct;
    public String AreaId, cityId = "";
    public TextView tvBasketBagde;
    public RelativeLayout rlBadgeView;
    public TextView textview_addpromocode;
    public final String TAG = "OrderDetailedUpdated";
    public User user;
    double totalprice = 0;
    //private String promocode_valuefromserver="",promocode_quantityfromserver="";
    com.appstailors.berain.object.addressData addressData;
    public CartParamResponse cartParamResponse;
    private String preffered_time_id = "3";

    public TextView tvPaymentType, tvChangePaymentMethod, tvChangeAddress,tv_free_group_promotion;
    public EditText et_promocode;
    public RadioButton rbMorning, rbEvening, deliveryTimeView_rbanytime;
    public RadioButton rbNone, rbWeekly, rbMonthly;
    public String paymentype = "";
    public RelativeLayout rlStepperLayer;
    public View refferalview;
    public boolean getIntentValue;
    public String vat_value_server="", vat_value = "",min_quantity="";
    public TextView textview_orderitemsvalue,tvWalletDiscountValue, textview_vatvalue, textview_walletvalue, textview_totalvalue;
    public AppCompatCheckBox rb_wallet;
    public double promoCode_value = 0.0;
    public double promoCode_valueS = 0.0;
    public String after_vat = "0";
    public double wallet_discount = 0.0;
    //public int promocode_quantity ;
    public TextView tvPromocodeValueB;
    public TextView tvPromocodeValueA;
    public View layoutPromocodeB;
    public View layoutPromocodeA;
    public View layoutWalletDiscount;
   // public double promo_min_value;
    public JSONArray jsonArray_cart;
    public String recurring = "";
    public Button btn_checkout;
    List<Cart> cartList= new ArrayList<>();
    List<PlaceOrder.Cart> cartListPlaceOrder = new ArrayList<>();
    EditText et_refferal;
    PlaceOrder placeOrder;
    Dialog payment_Dialog,confirmDialog;
    public TextView deliveryAddressView_tvAddress;
    private ProgressDialog mProgressDialog;
    private View promoView_layout;
    private String promocode_type="";
    private String stc_promo_code="";
    private ArrayList<String> allowed_products=new ArrayList<>();
    private String discount_level="";
    public Dialog dialog;
    private boolean edit_order;
    TextView orderdetailUpdated_tvOrderID;
    private View stc_layout;
    private EditText et_otp;
    private TextView textview_addotp;
    private AppCompatCheckBox rb_stc;
    private View view_stcline;
    private TextView textview_stctitle;
    private String stc_tamayouz_min_qty="0";
    private String address_id="";
    private double total_discountitems,total_items_without_discount,total_items_price;
    ArrayList<Foc_prod> foc_prodList = new ArrayList<>();
    int add_on=0;
    List<PlaceOrder.CartPromotion> cartListPromotion = new ArrayList<>();
    private String promoCode = "";
    private String checkout_time = "";


    @TargetApi(Build.VERSION_CODES.N)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        user = DatabaseManager.getInstance().getFirstOfClass(User.class);
        isArabic = AppController.setLocale();
        orderdetailactivity = this;
        setContentView(R.layout.activity_checkout);
        getIntentValue = getIntent().getBooleanExtra("order", false);
        edit_order = getIntent().getBooleanExtra("edit_order", false);
        initViews();
        if (edit_order) {
            User user = DatabaseManager.getInstance().getFirstOfClass(User.class);
            getOrderDetails(user.userId, getIntent().getStringExtra("order_id"));
        } else {

            if (user!=null) {
                setPromotion();
                getCartParams();
            }else {
                finish();
            }

        }

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
        String currentDateandTime = sdf.format(new Date());
        checkout_time = ""+currentDateandTime;

        Log.d("cdscdscfsdcfds",currentDateandTime);




    }

    public void showOpenOrdersDialog(String ordersList) {
        dialog = new Dialog(CheckOutActivity.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.custom_dialog);
        TextView title = dialog.findViewById(R.id.title);
        title.setText(getResources().getString(R.string.open_orders));
        TextView message = dialog.findViewById(R.id.message);
        String msg = getResources().getString(R.string.open_order_dialog_message);
        msg += "\n";
        msg += getResources().getString(R.string.current_orders);
        if (ordersList.length() > 20) {
            msg += ordersList.substring(0, 20);
            msg += "...";
        } else {
            msg += ordersList;
        }
        message.setText(msg);

        Button ok = dialog.findViewById(R.id.okBtn);
        ok.setText(getResources().getString(R.string.yes));
        Button cancel = dialog.findViewById(R.id.cancelBtn);
        cancel.setText(getResources().getString(R.string.go_to_orders));
        dialog.setCancelable(true);

        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();


            }
        });
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ProductsSingleton.getInstance().getCustomViewPager().setCurrentItem(2);

                dialog.dismiss();
                finish();
            }
        });
        dialog.show();
    }

    private void initViews() {
        setToolbar();
        Button btnAddItems = findViewById(R.id.activity_order_detailed_btn_additems);
        Button btnCheckout = findViewById(R.id.activity_order_detailed_btn_checkout);
        rvcartProduct = findViewById(R.id.orderdetailItemsList);
        View locationview = findViewById(R.id.locationview);
        View orderdetail_llOrderID = findViewById(R.id.orderdetail_llOrderID);
        tvBasketBagde = findViewById(R.id.basket_badge);
        rlBadgeView = findViewById(R.id.badge_view);
        rb_wallet = findViewById(R.id.radioButtonWallet);
        refferalview = findViewById(R.id.refferalview);
        layoutPromocodeB = findViewById(R.id.layoutPromocodeB);
        layoutPromocodeA = findViewById(R.id.layoutPromocodeA);
        layoutWalletDiscount = findViewById(R.id.layoutWalletDiscount);
        layoutPromocodeB.setVisibility(View.GONE);
        layoutPromocodeA.setVisibility(View.GONE);
        layoutWalletDiscount.setVisibility(View.GONE);
        et_promocode = findViewById(R.id.editTextPromocode);
        tvPromocodeValueB = findViewById(R.id.tvPromocodeValueB);
        tvPromocodeValueA = findViewById(R.id.tvPromocodeValueA);
        btn_checkout = findViewById(R.id.activity_order_detailed_btn_checkout);
        textview_addpromocode = findViewById(R.id.tvAddpromoCode);
        deliveryAddressView_tvAddress=findViewById(R.id.tvDeliveryAddress);
        orderdetailUpdated_tvOrderID=findViewById(R.id.tvOrderID);
        et_refferal = findViewById(R.id.et_refferal);
        promoView_layout= findViewById(R.id.promoView_layout);
        tv_free_group_promotion= findViewById(R.id.tv_free_group_promotion);
        textview_stctitle= findViewById(R.id.textview_stctitle);
        view_stcline= findViewById(R.id.view_stcline);
        stc_layout= findViewById(R.id.stc_layout);
        et_otp= findViewById(R.id.et_otp);
        textview_addotp= findViewById(R.id.textview_addotp);
        rb_stc= findViewById(R.id.rb_stc);
        textview_addotp.setOnClickListener(this);
        tv_free_group_promotion.setOnClickListener(this);

        rlBadgeView.setVisibility(View.GONE);
        stc_layout.setVisibility(View.GONE);

        view_stcline.setVisibility(View.GONE);
        textview_stctitle.setVisibility(View.GONE);
        View orderdetailcircleview = findViewById(R.id.orderdetailcircleview);
        btnAddItems.setOnClickListener(this);
        btnCheckout.setOnClickListener(this);
        btn_checkout.setOnClickListener(this);
        textview_addpromocode.setOnClickListener(this);
        AppController.getInstance().setActivity(this);
        if (!getIntentValue) {
            locationview.setVisibility(View.GONE);
            orderdetailcircleview.setVisibility(View.GONE);
            orderdetail_llOrderID.setVisibility(View.GONE);
        }
        if(edit_order){
            orderdetail_llOrderID.setVisibility(View.VISIBLE);
        }
        else{
            orderdetail_llOrderID.setVisibility(View.GONE);

        }


        tvPaymentType = findViewById(R.id.tvPaymentType);
        tvChangePaymentMethod = findViewById(R.id.paymentOptionView_tvChange);
        tvChangePaymentMethod.setOnClickListener(this);

        tvChangeAddress = findViewById(R.id.deliveryAddressView_tvChangeAddress);
        tv_free_group_promotion = findViewById(R.id.tv_free_group_promotion);

        rbMorning = findViewById(R.id.radioButtonMorning);
        rbEvening = findViewById(R.id.radioButtonEvening);
        rbNone = findViewById(R.id.radioButtonScheduleNone);
        rbWeekly = findViewById(R.id.radioButtonScheduleWeekly);
        rbMonthly = findViewById(R.id.radioButtonScheduleEveryMonth);
        deliveryTimeView_rbanytime = findViewById(R.id.radioButtonAnytime);
        rlStepperLayer = findViewById(R.id.orderdetailcircleview);

        textview_orderitemsvalue = findViewById(R.id.textview_orderitemsvalue);
        tvWalletDiscountValue = findViewById(R.id.tvWalletDiscountValue);
        textview_vatvalue = findViewById(R.id.textview_vatvalue);
        textview_walletvalue = findViewById(R.id.textview_walletvalue);
        textview_totalvalue = findViewById(R.id.textview_totalvalue);




        rlStepperLayer.setVisibility(View.GONE);
        rbMorning.setOnCheckedChangeListener(this);
        rbEvening.setOnCheckedChangeListener(this);
        deliveryTimeView_rbanytime.setOnCheckedChangeListener(this);
        rbNone.setOnCheckedChangeListener(this);
        rbMonthly.setOnCheckedChangeListener(this);
        rbWeekly.setOnCheckedChangeListener(this);
        rb_wallet.setOnCheckedChangeListener(this);
        rb_stc.setOnCheckedChangeListener(this);
        et_refferal.setText("");
        rbMorning.setChecked(false);
        rbEvening.setChecked(false);
        deliveryTimeView_rbanytime.setChecked(true);
        rbNone.setChecked(true);
        rbMonthly.setChecked(false);
        rbWeekly.setChecked(false);
        refferalview.setVisibility(View.GONE);
        setAddress();
        View addressview=findViewById(R.id.addressview);
        addressview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ChangeAddressAlert();

            }
        });

        User user  = DatabaseManager.getInstance().getFirstOfClass(User.class);
        if (user!=null){
            if (user.add_address.equals("0")){
                // tvcreditAmount.setVisibility(View.VISIBLE);
                findViewById(R.id.paymentDetailView).setVisibility(View.GONE);
                tvChangePaymentMethod.setVisibility(View.GONE);

            }else {
                // tvcreditAmount.setVisibility(View.GONE);
                findViewById(R.id.paymentDetailView).setVisibility(View.VISIBLE);
            }
        }

    }

    private void ChangeAddressAlert(){
        dialog = new Dialog(CheckOutActivity.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.setContentView(R.layout.change_alert_dialog);
        dialog.setCancelable(true);

        TextView title=dialog.findViewById(R.id.title);
        TextView message=dialog.findViewById(R.id.message);
        Button okBtn=dialog.findViewById(R.id.okBtn);
        Button cancelBtn=dialog.findViewById(R.id.cancelBtn);

        title.setTypeface(Typeface.createFromAsset(getAssets(), "roboto_bold.ttf"), Typeface.NORMAL);
        message.setTypeface(Typeface.createFromAsset(getAssets(), "roboto_regular.ttf"), Typeface.NORMAL);
        okBtn.setTypeface(Typeface.createFromAsset(getAssets(), "roboto_regular.ttf"), Typeface.NORMAL);
        cancelBtn.setTypeface(Typeface.createFromAsset(getAssets(), "roboto_regular.ttf"), Typeface.NORMAL);

        dialog.show();
        okBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent adressintent = new Intent(CheckOutActivity.this, ChooseAddressActivity.class);
                startActivityForResult(adressintent, REQUEST_FOR_ADDRESS);
                dialog.dismiss();
            }
        });

        cancelBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
    }

    private void setPromotion() {
        tv_free_group_promotion.setVisibility(View.GONE);
        foc_prodList = new ArrayList<>();
        int promoGroupCount = 0;
        cartList = DatabaseManager.getInstance().getAllOfClass(Cart.class);
        boolean check=true;
        if(ProductsSingleton.getInstance().getPromotionList()!=null &&
                ProductsSingleton.getInstance().getPromotionList().size()>0){
            for (int i = 0; i < ProductsSingleton.getInstance().getPromotionList().size(); i++) {

                if (ProductsSingleton.getInstance().getPromotionList().get(i).getPromotion_level().equals("group"))
                {
                    for(int j=0;j<cartList.size();j++){

                        if (ProductsSingleton.getInstance().getPromotionList().get(i).getProduct_id_list().size()==0){
                            promoGroupCount = promoGroupCount + cartList.get(j).count;
                        }
                        else {

                            for (int k = 0; k < ProductsSingleton.getInstance().getPromotionList().get(i).getProduct_id_list().size(); k++) {
                                if (ProductsSingleton.getInstance().getPromotionList().get(i).getProduct_id_list().get(k).equals(cartList.get(j).productId)) {
                                    promoGroupCount = promoGroupCount + cartList.get(j).count;
                                }
                            }
                        }
                    }

                    Log.d("promocount",promoGroupCount+"");
                    add_on=Integer.parseInt(ProductsSingleton.getInstance().getPromotionList().get(i).getAddOn())*(promoGroupCount / Integer.parseInt(ProductsSingleton.getInstance().getPromotionList().get(i).getQuantity()));

                    if (promoGroupCount>=Double.parseDouble(ProductsSingleton.getInstance().getPromotionList().get(i).getQuantity())){
                        tv_free_group_promotion.setVisibility(View.VISIBLE);
                        tv_free_group_promotion.setText(getResources().getString(R.string.st_promotion_dialouge_title)+" "+add_on);

                        for (int l= 0; l<ProductsSingleton.getInstance().getPromotionList().get(i).getFoc_prod().size(); l++){
                            if(l==0) {
                                Foc_prod foc_prod = new Foc_prod();
                                foc_prod.setCount(add_on);
                                foc_prod.setId(ProductsSingleton.getInstance().getPromotionList().get(i).getFoc_prod().get(l).getId());
                                foc_prod.setName_ar(ProductsSingleton.getInstance().getPromotionList().get(i).getFoc_prod().get(l).getName_ar());
                                foc_prod.setName_en(ProductsSingleton.getInstance().getPromotionList().get(i).getFoc_prod().get(l).getName_en());
                                this.foc_prodList.add(foc_prod);
                            }else {
                                Foc_prod foc_prod = new Foc_prod();
                                foc_prod.setCount(ProductsSingleton.getInstance().getPromotionList().get(i).getFoc_prod().get(l).getCount());
                                foc_prod.setId(ProductsSingleton.getInstance().getPromotionList().get(i).getFoc_prod().get(l).getId());
                                foc_prod.setName_ar(ProductsSingleton.getInstance().getPromotionList().get(i).getFoc_prod().get(l).getName_ar());
                                foc_prod.setName_en(ProductsSingleton.getInstance().getPromotionList().get(i).getFoc_prod().get(l).getName_en());
                                this.foc_prodList.add(foc_prod);
                            }
                        }
                    }
                }

            }
        }

        cartListPromotion.clear();
        for (int i = 0; i < foc_prodList.size(); i++) {
            PlaceOrder.CartPromotion cartPromotion = new PlaceOrder.CartPromotion();
            if (foc_prodList.get(i).getCount() > 0) {
                cartPromotion.setCount(foc_prodList.get(i).getCount());
                cartPromotion.setId(foc_prodList.get(i).getId());
                cartListPromotion.add(cartPromotion);
            }
        }

        InitCart();
    }

    private void getOrderDetails(String clientID, final String orderID){
        showProgress(true);
        APIManager.getInstance().getOrderDetails(new APIManager.Callback() {
            @Override
            public void onResult(boolean z, String response) {
                Log.e("test", " z = [" + z + "], response = [" + response + "]");
                showProgress(false);
                if (z) {
                    try {
                        YourOrderDetail orderDetails = new Gson().fromJson(response, YourOrderDetail.class);
                        List<OrderDetail> orderDetailList=new ArrayList<>();
                        orderDetailList = orderDetails.getOrder().getOrderDetail();
                        orderdetailUpdated_tvOrderID.setText(getResources().getString(R.string.Order_id)+
                                orderDetails.getOrder().getOrdId());
                        setinfoToViews(orderDetails);
                        Cart.emptyCart();

                        for (OrderDetail orderDetail : orderDetailList) {

                            if(orderDetail.getProd_curr_status().equals("1")){
                                ProductByLocation product = new ProductByLocation();
                                product.setId(orderDetail.getDishId());
                                product.setNameAr(orderDetail.getDishTitleAr());
                                product.setNameEn(orderDetail.getDishTitleEn());
                                product.setPrice(orderDetail.getDishPrice());
                                product.setImg(orderDetail.getDishImage());

                                Cart.addToCart(product,-1, Integer.parseInt(orderDetail.getOrdCount()));
                            }

                        }
                        setPromotion();
                        getCartParams();


                    } catch (Exception e) {
                        Log.e("OrderDetailexception",e.toString());
                        e.printStackTrace();
                    }
                }else {
                    Toast.makeText(CheckOutActivity.this, "Something went wrong ty again", Toast.LENGTH_SHORT).show();
                }
            }
        }, new OrderRequest(clientID,orderID,""));

    }

    private void setinfoToViews(YourOrderDetail yourOrderDetail) {
        deliveryAddressView_tvAddress.setText(yourOrderDetail.getOrder().getAddress());
        if (isArabic) {
            tvPaymentType.setText(yourOrderDetail.getOrder().getPaymentTypeAr());
        } else {
            tvPaymentType.setText(yourOrderDetail.getOrder().getPaymentTypeEn());
        }

        if (yourOrderDetail.getOrder().getPreferedTime().equals("1")) {
            rbMorning.setChecked(true);
            rbEvening.setChecked(false);
            deliveryTimeView_rbanytime.setChecked(false);

        } else if (yourOrderDetail.getOrder().getPreferedTime().equals("2")) {
            rbMorning.setChecked(false);
            rbEvening.setChecked(true);
            deliveryTimeView_rbanytime.setChecked(false);


        } else {
            rbMorning.setChecked(false);
            rbEvening.setChecked(false);
            deliveryTimeView_rbanytime.setChecked(true);

        }


        if(yourOrderDetail.getOrder().getRecurring().equals("0")){
            rbNone.setChecked(true);
            rbMonthly.setChecked(false);
            rbWeekly.setChecked(false);
        }

        else if(yourOrderDetail.getOrder().getRecurring().equals("2")){
            rbNone.setChecked(false);
            rbMonthly.setChecked(false);
            rbWeekly.setChecked(true);
        }
        else if(yourOrderDetail.getOrder().getRecurring().equals("3")){
            rbNone.setChecked(false);
            rbMonthly.setChecked(true);
            rbWeekly.setChecked(false);
        }

    }

    private CartParamResponse getCartParams() {
        showProgress(true);
        setArray();
        Log.d("getcartperameter", new Gson().toJson(new Cart_Params(AreaId,address_id,Integer.parseInt(user.userId),UserSession.getInstance().getToken(), cartListPlaceOrder)));
        APIManager.getInstance().getCartParemeters(new APIManager.Callback() {
            @Override
            public void onResult(boolean z, String response) {
                //Log.d(TAG, "onResult: ApiResponse: " + response);
                if (z) {

                    if (response.contains("Access denied") || response.contains("Invalid Key!")) {
                        CoreManager.getInstance().removeUserData();
                        Toast.makeText(CheckOutActivity.this, "" + getResources().getString(R.string.logout), Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(CheckOutActivity.this, SplashScreenActivity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        finish();
                        startActivity(intent);
                    } else {
                        try {
                            showProgress(false);
                            JSONObject jsonObject = new JSONObject(response);
                            if (jsonObject.getString("is_valid_order").equals("0")) {
                                if (isArabic) {
                                    alertDialogError(jsonObject.getString("Message_ar"));
                                } else {
                                    alertDialogError(jsonObject.getString("Message_en"));
                                }
                            } else {
                                cartParamResponse = new Gson().fromJson(response, CartParamResponse.class);
                                setTokenToServer();
                                setViewsfromCartParams(cartParamResponse);
                                if (!jsonObject.optString("promo_object").equals("") && !jsonObject.getString("default_promo").equals("")) {
                                    setPromocoderesponse(jsonObject.getJSONObject("promo_object"));
                                    et_promocode.setText("" + jsonObject.getString("default_promo"));
                                    promoCode = et_promocode.getText().toString();
                                } else if (!jsonObject.getString("default_promo").equals("")) {
                                    et_promocode.setText(cartParamResponse.getDefault_promo());
                                    promoCode = et_promocode.getText().toString();
                                    applypromocode();
                                }
                                if (!new JSONObject(response).getString("duplicate_orders").equals(""))
                                    showOpenOrdersDialog(new JSONObject(response).getString("duplicate_orders"));
                            }
                        } catch (Exception e) {
                            Log.e("Ex_cartitems", e.toString());
                            e.printStackTrace();
                        }
                    }
                } else {
                    showProgress(false);
                    Toast.makeText(CheckOutActivity.this, "Something went wrong plz try again", Toast.LENGTH_SHORT).show();
                    finish();
                }

            }
        }, new Cart_Params(AreaId,address_id,Integer.parseInt(user.userId),UserSession.getInstance().getToken(), cartListPlaceOrder));

        return cartParamResponse;
    }

    private void setTokenToServer(){
        DatabaseReference mDatabase;
            TokenRequest tokenRequest=new TokenRequest();
            tokenRequest.setUserid(user.userId);
            tokenRequest.setToken(UserSession.getInstance().getToken());
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("Token");

        myRef.setValue(tokenRequest);
    }

    private void setViewsfromCartParams(CartParamResponse cartParamResponse) {
        //region Check DeliverySlots
        for (int i = 0; i < cartParamResponse.getDeliverySlots().size(); i++) {
            if (cartParamResponse.getDeliverySlots().get(i).getTitleEn().equalsIgnoreCase("Morning") &&
                    cartParamResponse.getDeliverySlots().get(i).getStatus().equals("1")) {
                rbMorning.setVisibility(View.VISIBLE);

            }

            if (cartParamResponse.getDeliverySlots().get(i).getTitleEn().equalsIgnoreCase("Evening") &&
                    cartParamResponse.getDeliverySlots().get(i).getStatus().equals("1")) {
                rbEvening.setVisibility(View.VISIBLE);

            }

            if (cartParamResponse.getDeliverySlots().get(i).getTitleEn().equalsIgnoreCase("Anytime") &&
                    cartParamResponse.getDeliverySlots().get(i).getStatus().equals("1")) {
                deliveryTimeView_rbanytime.setVisibility(View.VISIBLE);
            }
        }

        if (Double.parseDouble(cartParamResponse.getClientWalletBalance()) < 1) {
            rb_wallet.setVisibility(View.GONE);
        } else if (Double.parseDouble(cartParamResponse.getClientWalletBalance()) > 0) {
            rb_wallet.setVisibility(View.VISIBLE);
            rb_wallet.setChecked(true);
        } else if (Cart.getTotalPrice() <= Double.parseDouble(cartParamResponse.getClientWalletBalance())) {
            rb_wallet.setVisibility(View.VISIBLE);
            rb_wallet.setChecked(true);
        }
        if (cartParamResponse.getShowReferral().equals("1")) {
            refferalview.setVisibility(View.VISIBLE);
        } else {
            refferalview.setVisibility(View.GONE);
        }
        stc_tamayouz_min_qty=cartParamResponse.getStc_tamayouz_min_qty();

        if(Cart.getTotalItems()>=Integer.parseInt(stc_tamayouz_min_qty) && cartParamResponse.getShow_stc_tamayouz().equals("1")){
            rb_stc.setVisibility(View.VISIBLE);
            textview_stctitle.setVisibility(View.VISIBLE);
            view_stcline.setVisibility(View.VISIBLE);
        }
        else{
            rb_stc.setVisibility(View.GONE);
            textview_stctitle.setVisibility(View.GONE);
            view_stcline.setVisibility(View.GONE);
        }


        for(int i = 0; i< cartParamResponse.getPaymentMethods().size();i++){
            if (cartParamResponse.getPaymentMethods().get(i).getTitleEn().equals("Apple Pay")){
                cartParamResponse.getPaymentMethods().remove(i);
            }
        }


        if (isArabic)
            tvPaymentType.setText(cartParamResponse.getPaymentMethods().get(0).getTitleAr());
        else
            tvPaymentType.setText(cartParamResponse.getPaymentMethods().get(0).getTitleEn());

            cartParamResponse.getPaymentMethods().get(0).setSelected(true);

        if (!cartParamResponse.getPaymentMethods().get(0).getTitleEn().toLowerCase().equals("cash on delivery"))
            btn_checkout.setText(getResources().getString(R.string.proceed));


        if (cartParamResponse.getWallet_discount().equals("")||cartParamResponse.getWallet_discount()==null){
            layoutWalletDiscount.setVisibility(View.GONE);
        }else if (Double.parseDouble(cartParamResponse.getWallet_discount())>0){
            rb_wallet.setVisibility(View.VISIBLE);
            rb_wallet.setChecked(true);
            layoutWalletDiscount.setVisibility(View.VISIBLE);
            wallet_discount = Double.parseDouble(cartParamResponse.getWallet_discount());
        }

        setPayment();
        setPaymentServer(tvPaymentType.getText().toString());
    }

    private void openPromotionGroupDialog(final ArrayList<Foc_prod> focProdArrayList, final int add_on) {
        final Dialog dialog = new Dialog(CheckOutActivity.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.promotion_group_dialog_with_recyclerview);
        TextView title = (TextView) dialog.findViewById(R.id.title);
        title.setText(getResources().getString(R.string.st_promotion_dialouge_title)+" "+add_on);
        RecyclerView promotion_list = dialog.findViewById(R.id.promotion_list);
        RecyclerView.LayoutManager manager = new LinearLayoutManager(this);
        promotion_list.setLayoutManager(manager);
        promotion_list.setHasFixedSize(true);
        final PromotionGroupAdapter adapter = new PromotionGroupAdapter(focProdArrayList,add_on);
        promotion_list.setAdapter(adapter);
        adapter.updateArray(focProdArrayList);
        promotion_list.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL_LIST));
        Button ok = dialog.findViewById(R.id.okBtn);
        Button cancel = dialog.findViewById(R.id.cancelBtn);
        dialog.setCancelable(false);
        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cartListPromotion.clear();
                foc_prodList.clear();
                foc_prodList = adapter.returnFocArray();

                for (int i = 0; i < foc_prodList.size(); i++) {
                    PlaceOrder.CartPromotion cartPromotion = new PlaceOrder.CartPromotion();

                    if (foc_prodList.get(i).getCount() > 0) {
                        cartPromotion.setCount(foc_prodList.get(i).getCount());
                        cartPromotion.setId(foc_prodList.get(i).getId());
                        cartListPromotion.add(cartPromotion);
                    }
                }
                dialog.dismiss();

            }
        });
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    private void InitCart() {
            CompanySetting companySetting = DatabaseManager.getInstance().getFirstOfClass(CompanySetting.class);
            vat_value_server = companySetting.vat + "";
            min_quantity=companySetting.minOrder+"";
            CartRecyclerAdapter productAdapter = new CartRecyclerAdapter(CheckOutActivity.this,
                CheckOutActivity.this, cartList, this, this);
        LinearLayoutManager linearLayoutManager=new LinearLayoutManager(CheckOutActivity.this);
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        rvcartProduct.setLayoutManager(linearLayoutManager);
        rvcartProduct.setItemAnimator(new DefaultItemAnimator());
        rvcartProduct.setAdapter(productAdapter);
    }

    private void setToolbar() {
        View toolbar = findViewById(R.id.toolbar);
        TextView title_textview = toolbar.findViewById(R.id.tvToolbarTitle);
        ImageView iv_backbtn = toolbar.findViewById(R.id.imageViewBack);
        iv_backbtn.setVisibility(View.VISIBLE);
        iv_backbtn.setOnClickListener(this);
        if (!getIntent().getBooleanExtra("order", false)) {
            if (isArabic) {
                title_textview.setText(getResources().getString(R.string.Your_Cart));
            } else {
                title_textview.setText(getResources().getString(R.string.Your_Cart));
            }
        } else {
            if (isArabic) {
                title_textview.setText(getResources().getString(R.string.Order_Details));
            } else {
                title_textview.setText(getResources().getString(R.string.Order_Details));
            }
        }


    }

    private void applypromocode() {
        setArray();
        if (et_promocode.getText().toString().equals("")) {
            Toast.makeText(this, "Enter PromoCode", Toast.LENGTH_SHORT).show();
        } else {

                    Log.d("requestbodyyy", new Gson().toJson(new PromocodeRequest(Integer.parseInt(AreaId),
                           "1", et_promocode.getText().toString(),
                            Cart.getTotalPrice() + "",
                            Integer.parseInt(user.userId), cartListPlaceOrder)));
            showProgress(true);
            APIManager.getInstance().getPromoCode(new APIManager.Callback() {
                @Override
                public void onResult(boolean z, String response) {
                    if (z) {
                        try {
                            showProgress(false);
                            JSONObject jsonObject = new JSONObject(response);
                            setPromocoderesponse(jsonObject.getJSONObject("rows"));
                        } catch (Exception e) {
                            showProgress(false);
                            Log.e("Ex_cartitems", e.toString());
                            e.printStackTrace();
                        }
                    }
                    else{
                        showProgress(false);
                    }


                }
            }, new PromocodeRequest(Integer.parseInt(AreaId),"1",
                    et_promocode.getText().toString(),
                    Cart.getTotalPrice() + "",
                    Integer.parseInt(user.userId), cartListPlaceOrder));
        }
    }

    private void setPromocoderesponse(JSONObject promocoderesponse) {
        try {
            if (promocoderesponse.getString("is_promo_valid").equals("1")){
                textview_addpromocode.setText(""+getResources().getString(R.string.st_remove));
                et_promocode.setEnabled(false);
                validate_promocode=true;
                promoCode =  et_promocode.getText().toString();
                stc_layout.setVisibility(View.GONE);
                et_otp.setText("");
                rb_stc.setVisibility(View.GONE);
                rb_stc.setChecked(false);
                textview_stctitle.setVisibility(View.GONE);
                view_stcline.setVisibility(View.GONE);
                promoView_layout.setVisibility(View.VISIBLE);
                et_promocode.setText(promoCode);

                after_vat = promocoderesponse.optString("after_vat");
                promocode_type=promocoderesponse.getString("type");
                promoCode_valueS = Double.parseDouble(promocoderesponse.getString("value"));

                discount_level=promocoderesponse.getString("discount_level");
                if(discount_level.equals("order")){
                    setPayment();
                }
                else if(discount_level.equals("product")){
                    JSONArray jsonArray=promocoderesponse.getJSONArray("allowed_products");
                    allowed_products.clear();
                    for(int i=0;i<jsonArray.length();i++){
                        allowed_products.add(jsonArray.getString(i));
                    }
                    if(allowed_products.size()>0){
                        setPaymentProductLevel();
                    }
                    else {
                        setPayment();
                    }
                }

            }else {
                et_promocode.setEnabled(true);
                et_promocode.setText("");
                textview_addpromocode.setText(""+getResources().getString(R.string.st_apply));
                promoCode_value = 0;
                promoCode_valueS =0;
                promocode_type="";

                if (isArabic)
                    Toast.makeText(CheckOutActivity.this, ""+promocoderesponse.optString("message_ar"), Toast.LENGTH_SHORT).show();
                else Toast.makeText(CheckOutActivity.this, ""+promocoderesponse.optString("message_en"), Toast.LENGTH_SHORT).show();

            }

        } catch (Exception ex) {
            Log.e("Exception", ex.toString());
        }
    }

    private void setOtpresponse(JSONObject jsonObject) {
        try {
            textview_addotp.setText(""+getResources().getString(R.string.st_remove));
            et_otp.setEnabled(false);
            JSONObject promocoderesponse = jsonObject.getJSONObject("rows");
            if (promocoderesponse.getString("is_promo_valid").equals("0")) {
                et_otp.setEnabled(true);
                et_otp.setText("");
                textview_addotp.setText(""+getResources().getString(R.string.st_apply));
                promoCode_value = 0;
                promoCode_valueS = 0;
                promocode_type="";
                stc_promo_code="";
                discount_level="";

                if (isArabic)
                Toast.makeText(this, promocoderesponse.optString("stc_validation_error_ar"), Toast.LENGTH_SHORT).show();
                else
                Toast.makeText(this, promocoderesponse.optString("stc_validation_error_en"), Toast.LENGTH_SHORT).show();


            /*    if (!promocoderesponse.getString("promo_expired_error").equals("")) {
                    Toast.makeText(this, getResources().getString(R.string.st_prom_expired), Toast.LENGTH_SHORT).show();
                    return;
                } else if (!promocoderesponse.getString("promo_city_error").equals("")) {
                    Toast.makeText(this, getResources().getString(R.string.st_prom_not_available), Toast.LENGTH_SHORT).show();
                    return;
                } else if (!promocoderesponse.getString("promo_min_value_error").equals("")) {
                    Toast.makeText(this, getResources().getString(R.string.st_prom_notless), Toast.LENGTH_SHORT).show();
                    return;
                } else if (!promocoderesponse.getString("promo_max_used_error").equals("")) {
                    Toast.makeText(this, getResources().getString(R.string.st_prom_used), Toast.LENGTH_SHORT).show();
                    return;
                } else if (!promocoderesponse.getString("promo_min_qty_error").equals("")) {
                    Toast.makeText(this, getResources().getString(R.string.st_prom_notless), Toast.LENGTH_SHORT).show();
                    return;
                }
                else if (!promocoderesponse.getString("promo_not_found").equals("")) {
                    Toast.makeText(this, getResources().getString(R.string.st_prom_notfound), Toast.LENGTH_SHORT).show();
                    return;
                }
                else {
                    if(isArabic) {
                        Toast.makeText(this, promocoderesponse.getString("stc_validation_error_ar"), Toast.LENGTH_SHORT).show();
                    }
                    else{
                        Toast.makeText(this, promocoderesponse.getString("stc_validation_error_en"), Toast.LENGTH_SHORT).show();

                    }
                    return;
                }*/

            } else {
               // promoCode =  et_promocode.getText().toString();
                   // promo_min_value = Double.parseDouble(promocoderesponse.getString("minimum_order_value"));
                    promocode_type=promocoderesponse.getString("type");
                    promoCode_valueS = Double.parseDouble(promocoderesponse.getString("value"));
                    stc_promo_code=promocoderesponse.getString("stc_promo_code");
                    discount_level=promocoderesponse.getString("discount_level");

                if(discount_level.equals("order")){

                }
                else{
                    JSONArray jsonArray=promocoderesponse.getJSONArray("allowed_products");
                    for(int i=0;i<jsonArray.length();i++){
                        allowed_products.add(jsonArray.getString(i));
                    }
                    if(allowed_products.size()>0){
                        setPaymentProductLevel();
                    }
                    else {
                        setPayment();
                    }
                }
                if(discount_level.equals("order")){
                    setPayment();
                }
                else{
                    JSONArray jsonArray=promocoderesponse.getJSONArray("allowed_products");
                    allowed_products.clear();
                    for(int i=0;i<jsonArray.length();i++){
                        allowed_products.add(jsonArray.getString(i));
                    }
                    setPaymentProductLevel();
                }
            }
        } catch (Exception ex) {
            Log.e("Exception", ex.toString());
        }
    }

    private void setPlaceOrder() {
        vat_value="0";
        int check_wallet = 0;

        if (rb_wallet.isChecked()) {
            check_wallet = 1;
        } else {
            check_wallet = 0;
        }

        String stc_otp="";
        if(rb_stc.isChecked()){
            stc_otp="1";
            double vat=Double.parseDouble(vat_value_server)*total_items_price;
            vat=vat/100;
            vat_value=String.format("%.2f",vat);
        }
        else{
            stc_otp="0";
            double vat=Double.parseDouble(vat_value_server)*Cart.getTotalPrice();
            vat=vat/100;
            vat_value=String.format("%.2f",vat);
        }


        Calendar c = Calendar.getInstance();
        c.add(Calendar.DATE, 1);
        String date = c.get(Calendar.DATE) + "-" + c.get(Calendar.MONTH) + "-" + c.get(Calendar.YEAR);
        setArray();
        placeOrder = new PlaceOrder();
        vat_value=Utils.convertString(vat_value);
        placeOrder.setAmount_vat(vat_value + "");
        placeOrder.setCheckout_time(""+checkout_time);

        placeOrder.setUser_id(user.userId);
        placeOrder.setInclude_wallet(check_wallet + "");
            if(!et_promocode.getText().toString().trim().isEmpty()
            || !et_promocode.getText().toString().trim().equals("")
            ) {
                if(promoCode_value != 0){
                    placeOrder.setPromocode(et_promocode.getText().toString());
                }
                else{
                    placeOrder.setPromocode("");
                }
            }
            else{
                if(promoCode_value != 0){
                    placeOrder.setPromocode(stc_promo_code);
                }
                else{
                    placeOrder.setPromocode("");
                }
            }

        placeOrder.setPayment_type(paymentype);
        placeOrder.setAddressData(addressData);

        if((!et_promocode.getText().toString().trim().isEmpty()
                || !et_promocode.getText().toString().trim().equals(""))
                && total_items_price>0

        ){
            if(promoCode_value != 0){
                String total_items_price_string=String.format("%.2f",total_items_price);
                total_items_price_string=convertString(total_items_price_string);
                total_items_price = Double.parseDouble(total_items_price_string);
                placeOrder.setPrice_without_vat(total_items_price + "");
            }
            else{
                placeOrder.setPrice_without_vat(Cart.getTotalPrice() + "");
            }


        }
        else if((et_otp.getText().toString().trim().isEmpty()
                || et_otp.getText().toString().trim(    ).equals(""))&& total_items_price>0 ){

            if(promoCode_value != 0){
                String total_items_price_string=String.format("%.2f",total_items_price);
                total_items_price_string=convertString(total_items_price_string);
                total_items_price = Double.parseDouble(total_items_price_string);
                placeOrder.setPrice_without_vat(total_items_price + "");
            }
            else{
                placeOrder.setPrice_without_vat(Cart.getTotalPrice() + "");
            }

        }

        else {

            placeOrder.setPrice_without_vat(Cart.getTotalPrice() + "");
        }


        placeOrder.setPrefered_time(preffered_time_id);
        placeOrder.setPrefered_date(date);
        placeOrder.setReferral(et_refferal.getText().toString());
        placeOrder.setRecurring(recurring);
        placeOrder.setStc_otp(stc_otp);
        placeOrder.setCart(cartListPlaceOrder);
        placeOrder.setFoc_items(cartListPromotion);

        Log.e("Request", checkForLatestOrders()+"");

        Map<String, Object> eventValue = new HashMap<String, Object>();
        eventValue.put("Products", new Gson().toJson(cartListPlaceOrder));
        eventValue.put("Quantity",""+Cart.getTotalItems());
        eventValue.put("payment method",""+tvPaymentType.getText().toString());
        CleverTapAPI.getDefaultInstance(CheckOutActivity.this).pushEvent("Begin checkout:",eventValue);





        if(!checkForLatestOrders()){
        if(tvPaymentType.getText().toString().contains("Cash on Delivery")
                || tvPaymentType.getText().toString().contains("الدفع عند الإستلام")
                || user.hide_price.equals("1")||tvPaymentType.getText().toString().toLowerCase().contains("wallet")
                || tvPaymentType.getText().toString().contains("المحفظة النقدية")){
                    Log.d("requestbody", new Gson().toJson(placeOrder));
                    Log.d("addresss", new Gson().toJson(addressData));
                    showProgress(true);
                    APIManager.getInstance().placeOrder(new APIManager.Callback() {
                        @Override
                        public void onResult(boolean z, String response) {

                            if (z) {

                                if (response.contains("Access denied") || response.contains("Invalid Key!")|| response.contains("Invalid Key")) {
                                    CoreManager.getInstance().removeUserData();
                                    Toast.makeText(CheckOutActivity.this, "" + getResources().getString(R.string.logout), Toast.LENGTH_SHORT).show();
                                    Intent intent = new Intent(CheckOutActivity.this, SplashScreenActivity.class);
                                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                    finish();
                                    startActivity(intent);
                                }
                                else {
                                    final double amountForTax = (Double.parseDouble(Utils.convertString("" + Cart.getTotalPrice())) * Double.parseDouble(vat_value)) / 100;
                                    try {
                                        showProgress(false);
                                        JSONObject jsonObject = new JSONObject(response);
                                        if (jsonObject.getString("is_valid_order").equals("0")) {
                                            if (isArabic) {
                                                alertDialogError(jsonObject.getString("Message_ar"));
                                            } else {
                                                alertDialogError(jsonObject.getString("Message_en"));
                                            }

                                        } else {
                                            Constants.validate_promocode = false;
                                            Intent intent = new Intent(CheckOutActivity.this, SuccessfullOrder.class);
                                            intent.putExtra("address_id", new JSONObject(response).getString("address_id"));

                                            intent.putExtra("id", new JSONObject(response).getString("id"));
                                            intent.putExtra("cc", false);
                                            intent.putExtra(AMOUNT, Cart.getFormattedAmount(Double.parseDouble("" + Cart.getTotalPrice()) + amountForTax));
                                            intent.putExtra("amount_Vat", amountForTax + "");
                                            intent.putExtra("amount_withoutVat", String.valueOf(Cart.getTotalPrice()));
                                            startActivity(intent);
                                            overridePendingTransition(R.anim.enter_anim, 0);
                                            saveAddressId(new JSONObject(response).getString("address_id"));

                                            Map<String, Object> eventValue = new HashMap<String, Object>();
                                            eventValue.put("Products",new Gson().toJson(cartListPlaceOrder));
                                            eventValue.put("Total Price",totalprice);
                                            eventValue.put("Quantity",Cart.getTotalItems());
                                            eventValue.put("payment method",""+tvPaymentType.getText().toString());
                                            eventValue.put("Delivery Preferred Time",""+preffered_time_id);
                                            eventValue.put("Preferred schedule",""+recurring);
                                            eventValue.put("address_lat",""+addressData.getAdd_latitude());
                                            eventValue.put("address_lng",""+addressData.getAdd_longitude());



                                            Areas areas = DatabaseManager.getInstance().getFirstMatching("areaId", addressData.getAdd_area(), Areas.class);
                                            Cities cities = DatabaseManager.getInstance().getFirstMatching("cityId", cityId, Cities.class);

                                            eventValue.put("address_city",""+cities.cityTitleEn);
                                            eventValue.put("address_area",""+areas.areaTitleEn);



                                            if(promoCode_value != 0)
                                                eventValue.put("with a discount:","Yes:"+ promoCode_value);
                                            else
                                                eventValue.put("with a discount:","NO");

                                            if(!promoCode.equals(""))
                                                eventValue.put("with a promo code","Yes:"+promoCode);
                                            else
                                                eventValue.put("with a promo code","No");

                                            CleverTapAPI.getDefaultInstance(CheckOutActivity.this).pushEvent("Checkout Complete:",eventValue);

                                        }

                                    } catch (Exception e) {
                                        Log.e("Ex_cartitems", e.toString());
                                        e.printStackTrace();
                                    }

                                }
                            }


                        }
                    }, placeOrder,CheckOutActivity.this);

        }
        else{
            Intent intent = new Intent(getApplicationContext(), HyperpayPaymentActivity.class);
            intent.putExtra("price", totalprice+"");
            intent.putExtra("promo", promoCode_value);

            for (int i = 0; i < cartParamResponse.getPaymentMethods().size();i++){
                if (tvPaymentType.getText().toString().trim().toLowerCase().equals(cartParamResponse.getPaymentMethods().get(i).getTitleEn().toLowerCase())
                        ||tvPaymentType.getText().toString().trim().toLowerCase().equals(cartParamResponse.getPaymentMethods().get(i).getTitleAr().toLowerCase()
                ))
                {
                    Log.d("paymentmethod",cartParamResponse.getPaymentMethods().get(i).getTitleEn());
                    intent.putExtra("payment_type",cartParamResponse.getPaymentMethods().get(i).getId());
                    intent.putExtra("payment_method",cartParamResponse.getPaymentMethods().get(i).getTitleEn());
                }
            }
            intent.putExtra("placeorder", new Gson().toJson(placeOrder));
            startActivity(intent);
            overridePendingTransition(R.anim.enter_anim, 0);

        }
    }
            else {
                Toast.makeText(CheckOutActivity.this, getResources().getString(R.string.st_adresserror), Toast.LENGTH_SHORT).show();
            }
    }

    private void saveAddressId(String address_id){
        try {
            JSONObject addressObj = new JSONObject(UserSession.getInstance().getSaveAddressObject());
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("lat", addressObj.getString("lat")+"");
            jsonObject.put("lng", addressObj.getString("lng")+"");
            jsonObject.put("areaId", ""+addressObj.getString("areaId"));
            jsonObject.put("cityId", ""+addressObj.getString("cityId"));
            jsonObject.put("addressName", "Address: " + addressObj.getString("addressName"));
            jsonObject.put("details", ""+addressObj.getString("details"));
            jsonObject.put("address_id", address_id);
            jsonObject.put("add_type", addressObj.getString("add_type"));
            UserSession.getInstance().setSaveHomeAddressObject(jsonObject + "");
        } catch (JSONException ex) {
            ex.printStackTrace();
        }

    }

    void setArray() {
        try {
            cartListPlaceOrder.clear();
            jsonArray_cart = new JSONArray();
            for (int i = 0; i < cartList.size(); i++) {
                if (cartList.get(i).count == 0) {

                } else {
                    PlaceOrder.Cart cart = new PlaceOrder.Cart();
                    cart.setCount(cartList.get(i).count);
                    cart.setDishId(cartList.get(i).productId);
                    cart.setPrice(cartList.get(i).amount);
                    cart.setProduct_price(cartList.get(i).price);
                    cart.setProductTitleEn(cartList.get(i).productTitleEn);
                    cartListPlaceOrder.add(cart);
                }

            }


        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void attachBaseContext(Context newBase) {
        Context context = BerainContextWrapper.wrap(newBase, new Locale(UserSession.getInstance().getUserLanguage()));
        super.attachBaseContext(ViewPumpContextWrapper.wrap(context));
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.activity_order_detailed_btn_checkout:
                if(Cart.getTotalItems()<Double.parseDouble(min_quantity)){
                    Toast.makeText(CheckOutActivity.this,
                            getResources().getString(R.string.min_order_amount)+" "+min_quantity, Toast.LENGTH_SHORT).show();

                }
                else {
                    Log.d("credit_limit",""+totalprice);
                    User user  = DatabaseManager.getInstance().getFirstOfClass(User.class);
                    if (user!=null){
                        if (user.add_address.equals("0")){
                            if (totalprice<=Double.parseDouble(cartParamResponse.getCredit_limit())){
                                setPlaceOrder();
                            }else {
                                Toast.makeText(orderdetailactivity,
                                        ""+getResources().getString(R.string.st_credit_insufficient_message),
                                        Toast.LENGTH_SHORT).show();
                            }
                        }else {
                            if(!validate_promocode && promoCode_value ==0){
                                setPlaceOrder();
                            }
                            else if (validate_promocode && (!et_promocode.getText().toString().isEmpty() ||
                                    !et_otp.getText().toString().isEmpty())) {
                                setPlaceOrder();
                            }
                            else{
                                ConfirmOrder();
                            }
                        }
                    }
                }
                break;
            case R.id.activity_order_detailed_btn_additems:
                finish();
                overridePendingTransition(0, R.anim.exit_anim);
                break;
            case R.id.imageViewBack:
                finish();
                overridePendingTransition(0, R.anim.exit_anim);
                break;
            case R.id.paymentOptionView_tvChange:
                if (totalprice==0&&rb_wallet.isChecked())
                {
                }
                else  selectPaymentMethod();
                break;

            case R.id.tvAddpromoCode:
                if (textview_addpromocode.getText().toString().equals(""+getResources().getString(R.string.st_apply))) {
                    if(!et_promocode.getText().toString().equals("")) {
                        applypromocode();
                    }
                    InputMethodManager imm = (InputMethodManager) getSystemService(Activity.INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(et_promocode.getWindowToken(), 0);
                } else {
                    et_promocode.setEnabled(true);
                    et_promocode.setText("");
                    textview_addpromocode.setText(""+getResources().getString(R.string.st_apply));
                     promoCode_value = 0;
                     promoCode_valueS =0;
                    promocode_type="";
                    total_discountitems=0;
                    total_items_without_discount=0;
                    total_items_price=0;
                    setPayment();
                }
                break;
            case R.id.textview_addotp:

                if (textview_addotp.getText().toString().equals(""+getResources().getString(R.string.st_apply))) {
                    if(!et_otp.getText().toString().equals("")) {
                        applyOtp();
                    }
                    InputMethodManager imm = (InputMethodManager) getSystemService(Activity.INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(et_otp.getWindowToken(), 0);
                } else {
                    total_discountitems=0;
                    total_items_without_discount=0;
                    total_items_price=0;
                    reversal_stc_tamayouz_discount();
                    et_otp.setEnabled(true);
                    et_otp.setText("");
                    rb_stc.setChecked(false);
                    textview_addotp.setText(""+getResources().getString(R.string.st_apply));
                    promoCode_value = 0;
                    promoCode_valueS =0;
                    promocode_type="";
                    setPayment();
                }
                break;
            case R.id.tv_free_group_promotion:
                openPromotionGroupDialog(foc_prodList,add_on);
                break;

        }

    }

    public void setPayment() {
        try {
            totalprice = 0;
            promoCode_value = 0;
            double vat=0;


            totalprice = (double)(Cart.getTotalPrice());

            if (after_vat.equals("1")){
                vat = totalprice / 100;

                vat = vat * Double.parseDouble(vat_value_server);
                totalprice = ((double) totalprice + vat);

                if (promocode_type.equals("percentage")) {
                    promoCode_value = promoCode_valueS * (totalprice / 100);
                }else {
                    promoCode_value = promoCode_valueS;
                }

                if (promoCode_value >totalprice)
                {
                    totalprice = 0.0;
                }else {
                    totalprice = totalprice - promoCode_value;
                }

                tvPromocodeValueA.setText("-" + convertString(String.format("%.2f", promoCode_value)) +
                        getResources().getString(R.string.currency));

            }else {

                if (promocode_type.equals("percentage")) {
                    promoCode_value = promoCode_valueS * (totalprice / 100);
                }else {
                    promoCode_value = promoCode_valueS;
                }

                if (promoCode_value >totalprice)
                {
                    totalprice = 0.0;
                }else {
                    totalprice = totalprice - promoCode_value;
                }

                vat = totalprice / 100;
                vat = vat * Double.parseDouble(vat_value_server);
                totalprice = ((double) totalprice + vat);
                tvPromocodeValueB.setText("-" + convertString(String.format("%.2f", promoCode_value)) +
                        getResources().getString(R.string.currency));
            }

            layoutWalletDiscount.setVisibility(View.GONE);


    /*        if (wallet_discount>totalprice&&rb_wallet.isChecked()){
                layoutWalletDiscount.setVisibility(View.VISIBLE);
                tvWalletDiscountValue.setText("-"+convertString(String.format("%.2f", totalprice)+getResources().getString(R.string.currency)));
                totalprice = 0.0;

                for(int i = 0; i< cartParamResponse.getPaymentMethods().size();i++){
                    Log.d("paymentoption",""+cartParamResponse.getPaymentMethods().get(i).getTitleEn());

                    if (cartParamResponse.getPaymentMethods().get(i).getTitleEn().toLowerCase().equals("wallet")){
                        if (isArabic)
                            tvPaymentType.setText(cartParamResponse.getPaymentMethods().get(i).getTitleAr());
                        else
                            tvPaymentType.setText(cartParamResponse.getPaymentMethods().get(i).getTitleEn());

                        btn_checkout.setText(getResources().getString(R.string.check_out));
                        cartParamResponse.getPaymentMethods().get(i).setSelected(true);
                    }else {
                        cartParamResponse.getPaymentMethods().get(i).setSelected(false);
                    }
                }

                setPaymentServer(tvPaymentType.getText().toString());

            }else if (rb_wallet.isChecked()){
                totalprice = totalprice-wallet_discount;
                layoutWalletDiscount.setVisibility(View.VISIBLE);
                tvWalletDiscountValue.setText("-"+wallet_discount+getResources().getString(R.string.currency));

                if (wallet_discount==0){
                    layoutWalletDiscount.setVisibility(View.GONE);
                }

            }else {
                layoutWalletDiscount.setVisibility(View.GONE);
            }
*/

            if (promoCode_value > 0) {
                if (after_vat.equals("1")) {
                    layoutPromocodeA.setVisibility(View.VISIBLE);
                    layoutPromocodeB.setVisibility(View.GONE);
                }
                else {
                    layoutPromocodeA.setVisibility(View.GONE);
                    layoutPromocodeB.setVisibility(View.VISIBLE);
                }

            } else {
                layoutPromocodeB.setVisibility(View.GONE);
                layoutPromocodeA.setVisibility(View.GONE);
            }

            if (rb_wallet.isChecked()){
                if ((Double.parseDouble(cartParamResponse.getClientWalletBalance())) >= totalprice) {
                    for(int i = 0; i< cartParamResponse.getPaymentMethods().size();i++){
                        if (cartParamResponse.getPaymentMethods().get(i).getTitleEn().toLowerCase().equals("wallet")){
                            if (isArabic)
                                tvPaymentType.setText(cartParamResponse.getPaymentMethods().get(i).getTitleAr());
                            else
                                tvPaymentType.setText(cartParamResponse.getPaymentMethods().get(i).getTitleEn());

                            btn_checkout.setText(getResources().getString(R.string.check_out));
                            cartParamResponse.getPaymentMethods().get(i).setSelected(true);
                        }else {
                            cartParamResponse.getPaymentMethods().get(i).setSelected(false);
                        }
                    }
                    setPaymentServer(tvPaymentType.getText().toString());

                    textview_orderitemsvalue.setText(convertString(String.format("%.2f",
                            Cart.getTotalPrice()).replace(",", ".")) +
                            getResources().getString(R.string.currency));
                    textview_vatvalue.setText(convertString(String.format("%.2f", vat)) +
                            getResources().getString(R.string.currency));
                    textview_totalvalue.setText(convertString("0.00") + getResources().getString(R.string.currency));
                    textview_walletvalue.setText("-" + convertString(String.format("%.2f",((double) totalprice)) +
                            getResources().getString(R.string.currency)));
                    View walletview = findViewById(R.id.wallet_view);
                    if (totalprice>0)
                    walletview.setVisibility(View.VISIBLE);
                    else
                        walletview.setVisibility(View.GONE);

                    totalprice=0.00;

                }else {
                    totalprice = totalprice - Double.parseDouble(cartParamResponse.getClientWalletBalance());
                    textview_orderitemsvalue.setText(convertString( String.format("%.2f", Cart.getTotalPrice())) +
                            getResources().getString(R.string.currency));
                    textview_vatvalue.setText(convertString(String.format("%.2f", vat)) +
                            getResources().getString(R.string.currency));
                    textview_walletvalue.setText("-" + convertString(String.format("%.2f",
                            Double.parseDouble(cartParamResponse.getClientWalletBalance())))
                            + getResources().getString(R.string.currency));
                    textview_totalvalue.setText(convertString(String.format("%.2f", totalprice)) +
                            getResources().getString(R.string.currency));

                    View walletview = findViewById(R.id.wallet_view);

                    if (Double.parseDouble(cartParamResponse.getClientWalletBalance())>0)
                    walletview.setVisibility(View.VISIBLE);
                    else walletview.setVisibility(View.GONE);
                    
                    if (tvPaymentType.getText().toString().toLowerCase().contains("wallet")
                            || tvPaymentType.getText().toString().contains("المحفظة النقدية")){
                        if (isArabic)
                        tvPaymentType.setText(cartParamResponse.getPaymentMethods().get(0).getTitleAr());
                        else
                        tvPaymentType.setText(cartParamResponse.getPaymentMethods().get(0).getTitleEn());

                        cartParamResponse.getPaymentMethods().get(0).setSelected(true);

                        if (!cartParamResponse.getPaymentMethods().get(0).getTitleEn().toLowerCase().equals("cash on delivery"))
                        btn_checkout.setText(getResources().getString(R.string.proceed));
                        setPaymentServer(tvPaymentType.getText().toString());
                    }
                }
            }else {
                textview_orderitemsvalue.setText(convertString(String.format("%.2f", Cart.getTotalPrice())) + getResources().getString(R.string.currency));
                textview_vatvalue.setText(convertString( String.format("%.2f", vat)) + getResources().getString(R.string.currency));
                textview_walletvalue.setText("-" + convertString( String.format("%.2f", Double.parseDouble(cartParamResponse.getClientWalletBalance()))) + getResources().getString(R.string.currency));
                textview_totalvalue.setText(convertString( String.format("%.2f", totalprice)) + getResources().getString(R.string.currency));
                View walletview = findViewById(R.id.wallet_view);
                walletview.setVisibility(View.GONE);
            }

        }catch (Exception ex){
            Log.e("Exception_Cart",ex.toString());
        }
    }

    private String convertString(String number){

        number=number.replace("١","1")
                .replace("١","1")
                .replace("٢","2").
                        replace("٣","3").replace("٤","4")
                .replace("٥","5")
                .replace("٦","6")
                .replace("٧","7")
                .replace("٨","8")
                .replace("٩","9")
                .replace("٠","0")
                .replace("٫",".")
        .replace(",",".");
        return number;
    }

    public void selectPaymentMethod() {
        final Dialog dialog = new Dialog(this);
        dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.setContentView(R.layout.alert_dialog_select_payment_method_list);
        TextView tvTitle = dialog.findViewById(R.id.tvTitle);
        tvTitle.setText("" + getResources().getString(R.string._string_select_payment_method));
        ListView listViewChooseTime = dialog.findViewById(R.id.listViewChoosePayment);

        List<PaymentMethod> paymentMethods = new ArrayList<>();
        for (int i = 0; i< cartParamResponse.getPaymentMethods().size();i++){
            if (cartParamResponse.getPaymentMethods().get(i).getTitleEn().toLowerCase().equals("wallet")||
                    cartParamResponse.getPaymentMethods().get(i).getTitleAr().equals("المحفظة النقدية"))
            {

            }else {
                paymentMethods.add(cartParamResponse.getPaymentMethods().get(i));
            }
        }

        SelectPaymentMethodAdapter selectTimeListAdapter = new SelectPaymentMethodAdapter(this, paymentMethods);
        listViewChooseTime.setAdapter(selectTimeListAdapter);

        listViewChooseTime.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                if (isArabic)
                    setPaymentServer(cartParamResponse.getPaymentMethods().get(position).getTitleAr());
                else
                    setPaymentServer(cartParamResponse.getPaymentMethods().get(position).getTitleEn());

                if (cartParamResponse.getPaymentMethods().get(position).getTitleEn().toString().toLowerCase().equals("cash on delivery"))
                {
                    btn_checkout.setText(getResources().getString(R.string.check_out));

                }else {
                    btn_checkout.setText(getResources().getString(R.string.proceed));
                }

                for (int i = 0; i < cartParamResponse.getPaymentMethods().size(); i++) {
                    if (i == position) {
                        cartParamResponse.getPaymentMethods().get(i).setSelected(true);
                    } else {
                        cartParamResponse.getPaymentMethods().get(i).setSelected(false);
                    }
                }
                dialog.dismiss();
            }
        });


        dialog.show();
        dialog.setCancelable(true);
        //dialog.setCancelable(false);
    }

    private void setPaymentServer(String method_name) {

        if (cartParamResponse != null) {
            for (int i = 0; i < cartParamResponse.getPaymentMethods().size(); i++) {

                if (method_name.toLowerCase().contains(cartParamResponse.getPaymentMethods().get(i).getTitleEn().toLowerCase())) {
                    Log.e("String",cartParamResponse.getPaymentMethods().get(i).getTitleAr());
                    tvPaymentType.setText(cartParamResponse.getPaymentMethods().get(i).getTitleEn());
                    paymentype = cartParamResponse.getPaymentMethods().get(i).getId();
                    break;
                }
                if (method_name.contains(cartParamResponse.getPaymentMethods().get(i).getTitleAr())) {
                    Log.e("String",cartParamResponse.getPaymentMethods().get(i).getTitleAr());
                    paymentype = cartParamResponse.getPaymentMethods().get(i).getId();
                    if(isArabic) {
                        tvPaymentType.setText(cartParamResponse.getPaymentMethods().get(i).getTitleAr());

                    }
                    else{
                        tvPaymentType.setText(cartParamResponse.getPaymentMethods().get(i).getTitleEn());
                    }

                    break;
                }

            }
        }
        Map<String, Object> eventValue = new HashMap<String, Object>();
        eventValue.put(AFInAppEventParameterName.USER_SCORE,"Source:"+"Android");
        eventValue.put(AFInAppEventParameterName.PAYMENT_INFO_AVAILIBLE,""+method_name);
        AppsFlyerLib.getInstance().trackEvent(CheckOutActivity.this , AFInAppEventType.ADD_PAYMENT_INFO , eventValue);

    }

    private void alertDialogError(String message) {
        final Dialog confirmDialog = new Dialog(CheckOutActivity.this);
        confirmDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        confirmDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        confirmDialog.setContentView(R.layout.dialog_place_order_error);
        TextView tv_message = confirmDialog.findViewById(R.id.tv_message);
        tv_message.setText(""+message);
        TextView btn_ok=confirmDialog.findViewById(R.id.btn_ok);
        btn_ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                confirmDialog.dismiss();
                finish();
            }
        });

        confirmDialog.setCancelable(false);
        confirmDialog.show();
    }

    @Override
    public void onQuantityChanged() {
        if(!stc_tamayouz_min_qty.equals("")) {
            if(Cart.getTotalItems()>=Integer.parseInt(stc_tamayouz_min_qty) &&
                    cartParamResponse.getShow_stc_tamayouz().equals("1")){
                rb_stc.setVisibility(View.VISIBLE);
                textview_stctitle.setVisibility(View.VISIBLE);
                view_stcline.setVisibility(View.VISIBLE);
            }
            else{
                rb_stc.setVisibility(View.GONE);
                textview_stctitle.setVisibility(View.GONE);
                view_stcline.setVisibility(View.GONE);
            }
            if(rb_stc.isChecked()){
                reversal_stc_tamayouz_discount();
            }
        }
        else{
            rb_stc.setVisibility(View.GONE);
            textview_stctitle.setVisibility(View.GONE);
            view_stcline.setVisibility(View.GONE);
        }

        et_otp.setEnabled(true);
        et_otp.setText("");
        textview_addotp.setText(""+getResources().getString(R.string.st_apply));
        et_promocode.setEnabled(true);
        et_promocode.setText("");
        textview_addpromocode.setText(""+getResources().getString(R.string.st_apply));
        promoCode_value = 0;
        promoCode_valueS =0;
        discount_level="";
        promocode_type="";
        total_discountitems=0;
        total_items_without_discount=0;
        total_items_price=0;
        setPayment();
        rb_stc.setChecked(false);
        setPromotion();
//        tvBasketBagde.setText(String.valueOf(size));
    }

    @Override
    protected void onStart() {
        super.onStart();
        tvBasketBagde.setText(String.valueOf(Cart.getTotalItems()));
    }

    @Override
    public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
        if (compoundButton.equals(rbMorning)) {
            if (b) {
                setTimeId(rbMorning.getText().toString());
                rbMorning.setChecked(true);
                rbEvening.setChecked(false);
                deliveryTimeView_rbanytime.setChecked(false);
            }
        } else if (compoundButton.equals(rbEvening)) {
            if (b) {
                setTimeId(rbEvening.getText().toString());
                rbMorning.setChecked(false);
                rbEvening.setChecked(true);
                deliveryTimeView_rbanytime.setChecked(false);
            }
        } else if (compoundButton.equals(deliveryTimeView_rbanytime)) {
            if (b) {
                setTimeId(deliveryTimeView_rbanytime.getText().toString());
                rbMorning.setChecked(false);
                rbEvening.setChecked(false);
                deliveryTimeView_rbanytime.setChecked(true);
            }
        }

        if (compoundButton.equals(rbNone)) {
            if (b) {
                recurring="0";
                rbNone.setChecked(true);
                rbMonthly.setChecked(false);
                rbWeekly.setChecked(false);
            }
        } else if (compoundButton.equals(rbMonthly)) {
            if (b) {
                recurring="3";
                rbNone.setChecked(false);
                rbMonthly.setChecked(true);
                rbWeekly.setChecked(false);
            }
        } else if (compoundButton.equals(rbWeekly)) {
            if (b) {
                recurring="2";
                rbNone.setChecked(false);
                rbMonthly.setChecked(false);
                rbWeekly.setChecked(true);
            }
        } else if (compoundButton.equals(rb_wallet)) {


            if (isArabic)
                tvPaymentType.setText(cartParamResponse.getPaymentMethods().get(0).getTitleAr());
            else
                tvPaymentType.setText(cartParamResponse.getPaymentMethods().get(0).getTitleEn());

            cartParamResponse.getPaymentMethods().get(0).setSelected(true);

            if (!cartParamResponse.getPaymentMethods().get(0).getTitleEn().toLowerCase().equals("cash on delivery"))
                btn_checkout.setText(getResources().getString(R.string.proceed));

            for (int i =0; i<cartParamResponse.getPaymentMethods().size();i++) {
                if (i != 0) {
                    cartParamResponse.getPaymentMethods().get(i).setSelected(false);
                }
            }
            setPaymentServer(tvPaymentType.getText().toString());
            setPayment();

        }

        else if (compoundButton.equals(rb_stc)) {

            if(b){
                et_otp.setEnabled(true);
                et_otp.setText("");
                et_promocode.setEnabled(true);
                et_promocode.setText("");
                textview_addotp.setText(""+getResources().getString(R.string.st_apply));
                promoCode_value = 0;
                promoCode_valueS =0;
                promocode_type="";
                setPayment();
                applyStc();

            }
            else{

                promoView_layout.setVisibility(View.VISIBLE);
                stc_layout.setVisibility(View.GONE);
                et_otp.setEnabled(true);
                et_otp.setText("");
                et_promocode.setEnabled(true);
                et_promocode.setText("");
                textview_addotp.setText(""+getResources().getString(R.string.st_apply));
                promoCode_value = 0;
                promoCode_valueS =0;
                promocode_type="";
                setPayment();
            }

        }
    }

    private void setTimeId(String slot){
        if(cartParamResponse!=null) {
            for (int i = 0; i < cartParamResponse.getDeliverySlots().size(); i++) {

            }

            for (int i = 0; i < cartParamResponse.getDeliverySlots().size(); i++) {
                if (slot.equals(cartParamResponse.getDeliverySlots().get(i).getTitleEn())) {
                    preffered_time_id = cartParamResponse.getDeliverySlots().get(i).getId();
                    break;
                }
                if (slot.contains(cartParamResponse.getDeliverySlots().get(i).getTitleAr())) {
                    preffered_time_id = cartParamResponse.getDeliverySlots().get(i).getId();
                    break;
                }

            }
        }
    }

    private void applyStc() {
        showProgress(true);
        CheckStcRequest checkStcRequest;
        if(isArabic){
            checkStcRequest=new CheckStcRequest(user.userId, user.mobile,"1");
        }
        else{
            checkStcRequest=new CheckStcRequest(user.userId, user.mobile,"2");
        }
        APIManager.getInstance().is_stc_tamayouz_user(new APIManager.Callback() {
            @Override
            public void onResult(boolean z, String response) {
                if (z) {
                    try {
                        showProgress(false);
                        JSONObject jsonObject = new JSONObject(response);
                        if(jsonObject.getString("status").equals("true")){
                            if(jsonObject.getString("otp_result").equals("true")){
                                promoView_layout.setVisibility(View.GONE);
                                stc_layout.setVisibility(View.VISIBLE);
                                if(isArabic)
                                    Toast.makeText(CheckOutActivity.this, jsonObject.getString("success_ar"), Toast.LENGTH_SHORT).show();
                                else
                                    Toast.makeText(CheckOutActivity.this, jsonObject.getString("success_en"), Toast.LENGTH_SHORT).show();
                            }
                            else{
                                rb_stc.setChecked(false);
                                promoView_layout.setVisibility(View.VISIBLE);
                                stc_layout.setVisibility(View.GONE);

                                if(isArabic)
                                Toast.makeText(CheckOutActivity.this, jsonObject.getString("error_ar"), Toast.LENGTH_SHORT).show();
                                  else
                                    Toast.makeText(CheckOutActivity.this, jsonObject.getString("error_en"), Toast.LENGTH_SHORT).show();

                            }
                        }else {
                            rb_stc.setChecked(false);
                            promoView_layout.setVisibility(View.VISIBLE);
                            stc_layout.setVisibility(View.GONE);
                            if(isArabic)
                                Toast.makeText(CheckOutActivity.this, jsonObject.optString("error_ar"), Toast.LENGTH_SHORT).show();
                            else
                                Toast.makeText(CheckOutActivity.this, jsonObject.optString("error_en"), Toast.LENGTH_SHORT).show();

                        }
                    } catch (Exception e) {
                        showProgress(false);
                        rb_stc.setChecked(false);
                        Log.e("Ex_checkStc", e.toString());
                        e.printStackTrace();
                    }
                }
                else{
                    showProgress(false);
                    rb_stc.setChecked(false);
                    Toast.makeText(CheckOutActivity.this, "Something went wrong.try again", Toast.LENGTH_SHORT).show();
                    Log.e("error",z+"");
                }
            }
        }, checkStcRequest);

    }

    private void reversal_stc_tamayouz_discount () {
        CheckStcRequest checkStcRequest;
        if(isArabic){
            checkStcRequest=new CheckStcRequest(user.userId,"1");
        }
        else{
            checkStcRequest=new CheckStcRequest(user.userId,"2");

        }
        APIManager.getInstance().reversal_stc_tamayouz_discount (new APIManager.Callback() {
            @Override
            public void onResult(boolean z, String response) {

                if (z) {
                    try {

                    } catch (Exception e) {
                        showProgress(false);
                        Log.e("Ex_checkStc", e.toString());
                        e.printStackTrace();
                    }
                }
            }
        }, checkStcRequest);


    }

    private void applyOtp() {
        setArray();
        showProgress(true);
        String stc_otp="";
        if(rb_stc.isChecked()){
            stc_otp="1";
        }
        else{
            stc_otp="0";
        }

        Log.d("getstcotp", new Gson().toJson(new PromocodeRequest(Integer.parseInt(AreaId),"1",
                et_otp.getText().toString(),
                Cart.getTotalPrice() + "",
                Integer.parseInt(user.userId), cartListPlaceOrder,stc_otp,user.mobile)));

        APIManager.getInstance().validate_stc_tamayouz_otp(new APIManager.Callback() {

            @Override
            public void onResult(boolean z, String response) {
                if (z) {
                    try {
                            showProgress(false);
                            JSONObject jsonObject = new JSONObject(response);
                            setOtpresponse(jsonObject);

                    } catch (Exception e) {
                        showProgress(false);
                        Log.e("Ex_checkStc", e.toString());
                        e.printStackTrace();
                    }
                }
            }
        }, new PromocodeRequest(Integer.parseInt(AreaId),"1",
                et_otp.getText().toString(),
                Cart.getTotalPrice() + "",
                Integer.parseInt(user.userId), cartListPlaceOrder,stc_otp,user.mobile));


    }

    private void setAddress(){
        try {
            JSONObject addressObj = new JSONObject(UserSession.getInstance().getSaveAddressObject());
            AreaId=""+Integer.parseInt(addressObj.getString("areaId"));
            address_id =""+addressObj.getString("address_id");
            cityId=""+Integer.parseInt(addressObj.getString("cityId"));
            deliveryAddressView_tvAddress.setText(""+addressObj.getString("details"));
            addressData = new addressData();
            addressData.setAdd_area(addressObj.getString("areaId"));
            addressData.setOrd_address_id(addressObj.getString("address_id"));
            addressData.setAdd_name("" +addressObj.getString("addressName"));
            addressData.setAdd_detail(addressObj.getString("details"));
            addressData.setAdd_latitude(addressObj.getString("lat"));
            addressData.setAdd_longitude(addressObj.getString("lng"));
            addressData.setAdd_type(addressObj.getString("add_type"));
        } catch (JSONException ex) {
            ex.printStackTrace();
        }

    }

    private void showProgress(boolean show) {
        if (show) {
            if (mProgressDialog != null && mProgressDialog.isShowing()) {
                mProgressDialog.dismiss();
            }
            mProgressDialog = new ProgressDialog(CheckOutActivity.this);
            mProgressDialog.setMessage(getResources().getString(R.string.please_wait));
            mProgressDialog.setIndeterminate(false);
            mProgressDialog.setCancelable(false);
            mProgressDialog.show();
        } else {
            if (mProgressDialog != null && mProgressDialog.isShowing()) {
                mProgressDialog.dismiss();
            }
        }
    }

    public void setPaymentProductLevel() {
        try {
            totalprice = 0;
            promoCode_value = 0;
            calculate_product_level_discount();

            double vat=0;
            vat = (double)( total_items_price- promoCode_value) / 100;
            vat = vat * Double.parseDouble(vat_value_server);


            if ((Double.parseDouble(cartParamResponse.getClientWalletBalance()))
                    >= ((double) Cart.getTotalPrice()- promoCode_value + vat)) {
                if (rb_wallet.isChecked()) {


                    totalprice = (total_items_price-totalprice )+vat;

                    totalprice = Double.parseDouble(cartParamResponse.getClientWalletBalance()) -

                            totalprice;

                } else {

                }


            } else {

                if (rb_wallet.isChecked()) {
                    totalprice =total_items_price- promoCode_value -
                            Double.parseDouble(cartParamResponse.getClientWalletBalance());
                    totalprice = totalprice+vat;


                } else {
                    totalprice = total_items_price + vat;
                    totalprice = totalprice - promoCode_value;
                }

            }

            if (Double.parseDouble(cartParamResponse.getClientWalletBalance()) >=
                    (double) Cart.getTotalPrice() + Double.parseDouble(vat_value_server)) {
                if (rb_wallet.isChecked()) {
                    String st_cart = String.format("%.2f", total_items_price);
                    String st_vat = String.format("%.2f", vat);
                    String st_wallet = String.format("%.2f",(total_items_price - promoCode_value)+vat);
                    String st_promocode = String.format("%.2f", promoCode_value);
                    String st_totalprice = String.format("%.2f", totalprice);


                    textview_orderitemsvalue.setText(convertString(st_cart.replace(",", ".")) + getResources().getString(R.string.currency));
                    textview_vatvalue.setText(convertString(st_vat) + getResources().getString(R.string.currency));
                    textview_totalvalue.setText(convertString("0") + getResources().getString(R.string.currency));
                    textview_walletvalue.setText("-" + convertString(st_wallet) + getResources().getString(R.string.currency));
                    tvPromocodeValueB.setText("-" + convertString(st_promocode) + getResources().getString(R.string.currency));
                    if (promoCode_value > 0) {
                        layoutPromocodeB.setVisibility(View.VISIBLE);
                    } else {
                        layoutPromocodeB.setVisibility(View.GONE);
                    }

                    View walletview = findViewById(R.id.wallet_view);
                    walletview.setVisibility(View.VISIBLE);
                    totalprice=0;
                } else {
                    String st_cart = String.format("%.2f", total_items_price);
                    String st_vat = String.format("%.2f", vat);
                    String st_wallet = String.format("%.2f", Double.parseDouble(cartParamResponse.getClientWalletBalance()));

                    String st_totalprice = String.format("%.2f", totalprice);
                    String st_promocode = String.format("%.2f", promoCode_value);


                    textview_orderitemsvalue.setText(convertString(st_cart) + getResources().getString(R.string.currency));
                    textview_vatvalue.setText(convertString(st_vat) + getResources().getString(R.string.currency));
                    textview_walletvalue.setText("-" + convertString(st_wallet) + getResources().getString(R.string.currency));
                    textview_totalvalue.setText(convertString(st_totalprice) + getResources().getString(R.string.currency));
                    tvPromocodeValueB.setText("-" + convertString(st_promocode) + getResources().getString(R.string.currency));
                    if (promoCode_value > 0) {
                        layoutPromocodeB.setVisibility(View.VISIBLE);
                    } else {
                        layoutPromocodeB.setVisibility(View.GONE);
                    }
                    View walletview = findViewById(R.id.wallet_view);
                    walletview.setVisibility(View.GONE);

                }

            } else {
                if (rb_wallet.isChecked()) {
                    String st_cart = String.format("%.2f", total_items_price);
                    String st_vat = String.format("%.2f", vat);
                    String st_wallet = String.format("%.2f", Double.parseDouble(cartParamResponse.getClientWalletBalance()));
                    String st_promocode = String.format("%.2f", promoCode_value);
                    String st_totalprice = String.format("%.2f", totalprice);

                    textview_orderitemsvalue.setText(convertString(st_cart) + getResources().getString(R.string.currency));
                    textview_vatvalue.setText(convertString(st_vat) + getResources().getString(R.string.currency));
                    textview_walletvalue.setText("-" + convertString(st_wallet) + getResources().getString(R.string.currency));
                    textview_totalvalue.setText(convertString(st_totalprice) + getResources().getString(R.string.currency));
                    tvPromocodeValueB.setText("-" + convertString(st_promocode) + getResources().getString(R.string.currency));
                    if (promoCode_value > 0) {
                        layoutPromocodeB.setVisibility(View.VISIBLE);
                    } else {
                        layoutPromocodeB.setVisibility(View.GONE);
                    }
                    View walletview = findViewById(R.id.wallet_view);
                    walletview.setVisibility(View.VISIBLE);
                } else {

                    String st_cart = String.format("%.2f",total_items_price);
                    String st_vat = String.format("%.2f", vat);
                    String st_wallet = String.format("%.2f", Double.parseDouble(cartParamResponse.getClientWalletBalance()));
                    String st_totalprice = String.format("%.2f", totalprice);
                    String st_promocode = String.format("%.2f", promoCode_value);


                    textview_orderitemsvalue.setText(convertString(st_cart.replace(",", ".")) + getResources().getString(R.string.currency));

                    //  textview_orderitemsvalue.setText(st_cart + getResources().getString(R.string.currency));
                    textview_vatvalue.setText(convertString(st_vat) + getResources().getString(R.string.currency));
                    textview_walletvalue.setText("-" + convertString(st_wallet) + getResources().getString(R.string.currency));
                    textview_totalvalue.setText(convertString(st_totalprice) + getResources().getString(R.string.currency));
                    tvPromocodeValueB.setText("-" + convertString(st_promocode) + getResources().getString(R.string.currency));
                    if (promoCode_value > 0) {
                        layoutPromocodeB.setVisibility(View.VISIBLE);
                    } else {
                        layoutPromocodeB.setVisibility(View.GONE);
                    }
                    View walletview = findViewById(R.id.wallet_view);
                    walletview.setVisibility(View.GONE);
                }
            }
            if (Double.parseDouble(cartParamResponse.getClientWalletBalance()) > 0 &&
                    Double.parseDouble(cartParamResponse.getClientWalletBalance()) <
                            (double) Cart.getTotalPrice() + vat) {
                View walletview = findViewById(R.id.wallet_view);
                if (rb_wallet.isChecked()) {
                    String st_cart = String.format("%.2f", total_items_price);
                    String st_vat = String.format("%.2f", vat);
                    String st_wallet = String.format("%.2f", Double.parseDouble(cartParamResponse.getClientWalletBalance()));
                    String st_promocode = String.format("%.2f", promoCode_value);
                    String st_totalprice = String.format("%.2f", totalprice);
                    textview_walletvalue.setText("-" + st_wallet + getResources().getString(R.string.currency));
                    if (promoCode_value > 0) {
                        layoutPromocodeB.setVisibility(View.VISIBLE);
                    } else {
                        layoutPromocodeB.setVisibility(View.GONE);
                    }
                    textview_vatvalue.setText(st_vat + getResources().getString(R.string.currency));
                    textview_walletvalue.setVisibility(View.VISIBLE);
                    walletview.setVisibility(View.VISIBLE);
                    textview_totalvalue.setText(st_totalprice + getResources().getString(R.string.currency));
                }
            }

        }catch (Exception ex){

        }
    }

    private void calculate_product_level_discount() {

        for (int i = 0; i < allowed_products.size(); i++) {
            for (int j = 0; j < cartListPlaceOrder.size(); j++) {


                if (allowed_products.get(i).equals(cartListPlaceOrder.get(j).getDishId())) {
                      cartListPlaceOrder.get(j).haspromocode=true;
                }
            }
        }

        for (int i = 0; i < cartListPlaceOrder.size(); i++) {


            if (cartListPlaceOrder.get(i).haspromocode) {

                double amount= cartListPlaceOrder.get(i).getCount()*Double.parseDouble(cartListPlaceOrder.get(i).getProduct_price());
                total_discountitems =total_discountitems+ amount;
            }
        }

        for (int i = 0; i < cartListPlaceOrder.size(); i++) {

            if (!cartListPlaceOrder.get(i).haspromocode) {

                double amount= cartListPlaceOrder.get(i).getCount()*Double.parseDouble(cartListPlaceOrder.get(i).getProduct_price());
                total_items_without_discount=total_items_without_discount+ amount;
            }
        }


        Log.e("before"+total_discountitems+"",total_items_without_discount+"");

            promoCode_value = promoCode_value;
            if (promocode_type.equals("fixed")) {
                et_promocode.setEnabled(false);

            } else if (promocode_type.equals("percentage")) {
                et_promocode.setEnabled(false);
                promoCode_value = promoCode_value * ((total_discountitems) / 100);

            }

        total_items_price=total_discountitems+total_items_without_discount;

        total_discountitems = total_items_price - promoCode_value;

            total_items_price=total_discountitems;
        Log.e("after"+ promoCode_value +"",total_items_price+"");

    }

    private boolean checkForLatestOrders(){
        if(address_id.equals("")){
            return false;
        }

        if(cartParamResponse.getLatest_orders()!=null && cartParamResponse.getLatest_orders().size()>0){
            ArrayList<LatestOrder> latestOrders=cartParamResponse.getLatest_orders();
            boolean isIdMatching = false;
            for (LatestOrder latestOrder : latestOrders) {
                if(latestOrder.getAddress_id().equals(address_id)){

                    ArrayList<OrderItems> orderItems = latestOrder.getOrder_items();

                    for (OrderItems orderItem : orderItems) {
                        for (Cart cart : cartList) {
                            Log.e(cart.productId,cart.productId);
                            if(cart.productId.equals(orderItem.getProduct_id()) &&
                                    cart.count==Integer.parseInt(orderItem.getQty())){
                                return true;
                            }

                        }
                    }



                }


            }
            return false;

        }


        return false;
    }

    private void ConfirmOrder() {
        confirmDialog = new Dialog(CheckOutActivity.this);
        confirmDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        confirmDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        confirmDialog.setContentView(R.layout.confirm_dialog);
        Button btn_proceed=confirmDialog.findViewById(R.id.btn_proceed);
        Button btn_dismiss=confirmDialog.findViewById(R.id.btn_dismiss);
        btn_proceed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                  confirmDialog.dismiss();
                setPlaceOrder();
            }
        });

        btn_dismiss.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                et_promocode.setText(""+promoCode);
                applypromocode();
                confirmDialog.dismiss();
            }
        });

        confirmDialog.setCancelable(false);
        confirmDialog.show();


    }

    @Override
    protected void onDestroy() {
        LocalBroadcastManager.getInstance(this).unregisterReceiver(mReceiverOnAddressChange);
        super.onDestroy();
        if(payment_Dialog!=null && payment_Dialog.isShowing()){
            payment_Dialog.dismiss();
        }
        if(confirmDialog!=null && confirmDialog.isShowing()){
            confirmDialog.dismiss();
        }

        if(mProgressDialog!=null && mProgressDialog.isShowing()){
            mProgressDialog.dismiss();
        }
    }

    @Override
    protected void onResume() {
        registerReceiver(mReceiverOnAddressChange, new IntentFilter("data_action_add_change"));
        super.onResume();
    }

    private BroadcastReceiver mReceiverOnAddressChange = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            try {
                String string = (String) intent.getSerializableExtra("onAddressChange");
                Log.d("changeddd", string + "....");
                if (string.equals("changed")) {
                    setAddress();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    };
}

