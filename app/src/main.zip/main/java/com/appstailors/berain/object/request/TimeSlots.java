package com.appstailors.berain.object.request;

public class TimeSlots {
    private String pref_date;
    private String area_id;

    public TimeSlots(String pref_date, String area_id) {
        this.pref_date = pref_date;
        this.area_id = area_id;
    }
}
