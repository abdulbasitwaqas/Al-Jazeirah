package com.appstailors.berain.ui.fragment;


import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.appstailors.berain.AppController;
import com.appstailors.berain.R;
import com.appstailors.berain.UserSession;
import com.appstailors.berain.adapter.ProductbyLocationAdapterPlastic;
import com.appstailors.berain.object.Cart;
import com.appstailors.berain.object.ProductByLocation;
import com.appstailors.berain.utils.ProductsSingleton;
import com.roam.appdatabase.DatabaseManager;

import java.util.ArrayList;
import java.util.List;

public class CategoryFragmentPlastic extends Fragment {

    private View rootview;
    private ProductbyLocationAdapterPlastic productbyLocationAdapter;
    ArrayList<ProductByLocation> productByLocations=new ArrayList<>();

    RecyclerView recyclerView;
    private boolean isArabic;

    private boolean haveItemInCart = false;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        rootview=inflater.inflate(R.layout.fragment_products_new_plastic, container, false);
        setViews(rootview);
        isArabic = AppController.setLocale();
        return rootview;
    }


    private void setViews(View rootview){

        recyclerView = rootview.findViewById(R.id.rc_category);


        GridLayoutManager gridLayoutManager=new GridLayoutManager(getActivity(),2);
        recyclerView.setLayoutManager(gridLayoutManager);

        productByLocations = new ArrayList<>();




        }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        productbyLocationAdapter = new ProductbyLocationAdapterPlastic(CategoryFragmentPlastic.this,getActivity(),getActivity(), productByLocations);
        recyclerView.setAdapter(productbyLocationAdapter);
           setCatgories();



    }


    @Override
    public void onStart() {
        super.onStart();

    }

    @Override
    public void onResume() {
        super.onResume();
        try {
            updateListing();
            getCartNumber();
        }catch (Exception ex){

        }

    }

    public void getCartNumber(){
        if(Cart.getTotalItems()>0){
            ProductsSingleton.getInstance().getBasket_badge().setText(Cart.getTotalItems()+"");
            ProductsSingleton.getInstance().getBasket_badge().setVisibility(View.VISIBLE);
        }
        else{
            ProductsSingleton.getInstance().getBasket_badge().setVisibility(View.GONE);
        }
    }


    private void setCatgories() {


        new Thread(new Runnable() {
            @Override
            public void run() {
                if (ProductsSingleton.getInstance().getProductByLocations() != null) {
                        productByLocations.clear();
                    for (int i = 0; i < ProductsSingleton.getInstance().getProductByLocations().size(); i++) {
                        if (ProductsSingleton.getInstance().getProductByLocations().
                                get(i).getCategory_id().equals("1")) {
                            Cart cart = DatabaseManager.getInstance().getFirstMatching("productId",
                                    ProductsSingleton.getInstance().getProductByLocations().
                                            get(i).getId(), Cart.class);
                            if (cart != null) {
                                haveItemInCart = true;
                                ProductsSingleton.getInstance().getProductByLocations().
                                        get(i).setAddedToCart(true);
                                ProductsSingleton.getInstance().getProductByLocations().
                                        get(i).setCount(cart.count);
                            }
                            else{

                            }
                            productByLocations.add(ProductsSingleton.getInstance().getProductByLocations().
                                    get(i));

                        }
                    }

                    getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            updateListing();
                        }
                    });
                }
            }
        }).start();


    }

    private void updateListing() {
        haveItemInCart = false;
        for (int i = 0; i < ProductsSingleton.getInstance().getProductByLocations().size(); i++) {
            ProductByLocation product = ProductsSingleton.getInstance().getProductByLocations().get(i);
            Cart cart = DatabaseManager.getInstance().getFirstMatching("productId", product.getId(), Cart.class);
            if (cart != null) {
                haveItemInCart = true;
                product.setAddedToCart(true);
                product.setCount(cart.count);
            } else {
                product.setAddedToCart(false);
                product.setCount(0);
            }
        }
        productbyLocationAdapter.setProductList(productByLocations);

        if (haveItemInCart) {
            ProductsSingleton.getInstance().getCartView().setVisibility(View.VISIBLE);
        } else {
            ProductsSingleton.getInstance().getCartView().setVisibility(View.GONE);
        }
    }

    public void showCartLayout() {
        ProductsSingleton.getInstance().getCartView().setVisibility(View.VISIBLE);

    }

}
