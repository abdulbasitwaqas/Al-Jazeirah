package com.appstailors.berain.object.request;

public class ProductsRequest {

    private int area_id;
    private String customer_id;
    private String add_type;

    public ProductsRequest(int area_id,String customer_id,String add_type) {
        this.area_id = area_id;
        this.customer_id = customer_id;
        this.add_type = add_type;
    }


}
