package com.appstailors.berain.adapter;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.appstailors.berain.AppController;
import com.appstailors.berain.R;
import com.appstailors.berain.UserSession;
import com.appstailors.berain.object.login.Address;
import com.appstailors.berain.object.login.User;
import com.appstailors.berain.object.request.DeleteAddress;
import com.appstailors.berain.utils.APIManager;
import com.roam.appdatabase.DatabaseManager;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;

import static android.app.Activity.RESULT_OK;
import static com.appstailors.berain.utils.Constants.fromore;

/**

 */
public class AddressAdapter extends RecyclerView.Adapter<AddressAdapter.MyViewHolder> {

    private List<Address> addressList;
    private Context mContext;
    private Activity activity;
    boolean isArabic;

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView addressName, addressDetail;
        private ImageView deleteAddress, defaultImage;
        private LinearLayout mainView;

        public MyViewHolder(View view) {
            super(view);
            addressName =  view.findViewById(R.id.address_name);
            addressDetail =  view.findViewById(R.id.address_detail);
            deleteAddress =  view.findViewById(R.id.delete_address);
            defaultImage =  view.findViewById(R.id.default_address);
            mainView =  view.findViewById(R.id.mainView);
        }
    }


    public AddressAdapter(List<Address> addressList, Context context,Activity activity) {
        this.addressList = addressList;
        this.mContext = context;
        this.activity=activity;
        isArabic= AppController.setLocale();
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.address_item, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, final int position) {


        final Address address = addressList.get(position);
        holder.addressName.setText(address.addName);
        String street = "", buildingNumber = "", floorNumber = "", completeAddress = "";
        completeAddress = address.addDetail;
        if (!address.addStreetName.isEmpty()) {
      //      completeAddress += "," + mContext.getResources().getString(R.string.street_name) + " : " + address.addStreetName;
        }
        if (!address.addBlock.isEmpty()) {
        //    completeAddress += "," + mContext.getResources().getString(R.string.block) + " : " + address.addBlock;
        }
        if (!address.addFloor.isEmpty()) {
        //    completeAddress += "," + mContext.getResources().getString(R.string.floor_num) + " : " + address.addFloor;
        }
        holder.addressDetail.setText(completeAddress);

        holder.deleteAddress.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                openDeleteAddressDialog(address);
            }
        });


        try {
            JSONObject addressObj = new JSONObject(UserSession.getInstance().getSaveAddressObject());

            if (addressObj.getString("address_id").equals(address.addId)) {
                holder.defaultImage.setVisibility(View.VISIBLE);
                holder.deleteAddress.setVisibility(View.GONE);
            } else {
                holder.defaultImage.setVisibility(View.GONE);
                holder.deleteAddress.setVisibility(View.VISIBLE);
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }

        holder.mainView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                        openChangeAddressDialog(addressList.get(position));
            }
        });
    }

    @Override
    public int getItemCount() {
        return addressList.size();
    }

    public void setAddressList(List<Address> moviesList) {
        this.addressList = moviesList;
        notifyDataSetChanged();
    }


    private void openDeleteAddressDialog(final Address address) {

        final Dialog dialog = new Dialog(mContext);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.custom_dialog);
        TextView title = (TextView) dialog.findViewById(R.id.title);
        title.setText(mContext.getResources().getString(R.string.deleting_confirm));
        TextView message = (TextView) dialog.findViewById(R.id.message);
        message.setText(mContext.getResources().getString(R.string.deleting_address));

        Button ok = (Button) dialog.findViewById(R.id.okBtn);
        Button cancel = (Button) dialog.findViewById(R.id.cancelBtn);
        dialog.setCancelable(false);

        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Address.changeDefaultAddress(address.addId);
                User user = DatabaseManager.getInstance().getFirstOfClass(User.class);
                DeleteAddress deleteAddress = new DeleteAddress(user.userId, address.addId);
                APIManager.getInstance().deleteAddress(new APIManager.Callback() {
                    @Override
                    public void onResult(boolean z, String response) {
                        if (z) {
                            try {
                                JSONObject jsonObject = new JSONObject(response);
                                if (jsonObject.getString("status").toLowerCase().equals("true")) {
                                    address.delete();
                                    addressList.remove(address);
                                    notifyDataSetChanged();
                                }else {
                                    Toast.makeText(mContext, ""+jsonObject.optString("Message"), Toast.LENGTH_SHORT).show();
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }
                    }
                }, deleteAddress);
                dialog.dismiss();

            }
        });
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        dialog.show();
//        DisplayMetrics metrics = mContext.getResources().getDisplayMetrics();
//        int width = metrics.widthPixels;
//        int height = metrics.heightPixels;
//        dialog.getWindow().setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
    }


    private void openChangeAddressDialog(final Address address) {

        final Dialog dialog = new Dialog(mContext);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.custom_dialog);
        TextView title = (TextView) dialog.findViewById(R.id.title);
        title.setText(mContext.getResources().getString(R.string.alert));
        TextView message = (TextView) dialog.findViewById(R.id.message);
        message.setText(mContext.getResources().getString(R.string.change_address));

        Button ok = (Button) dialog.findViewById(R.id.okBtn);
        Button cancel = (Button) dialog.findViewById(R.id.cancelBtn);
        dialog.setCancelable(false);

        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                Address.changeDefaultAddress(address.addId);
                addressList = DatabaseManager.getInstance().getAllOfClass(Address.class);
                setAddressList(addressList);
                JSONObject jsonObject = new JSONObject();
                try {
                    jsonObject.put("lat", address.addLatitude+"");
                    jsonObject.put("lng", address.addLongitude+"");
                    jsonObject.put("areaId", ""+address.addArea);
                    jsonObject.put("cityId", ""+address.addCity);
                    jsonObject.put("addressName", "Address: " + address.addName );
                    jsonObject.put("details", ""+address.addDetail);
                    jsonObject.put("address_id", ""+address.addId);
                    jsonObject.put("add_type", address.add_type);

                } catch (JSONException e) {
                    e.printStackTrace();
                }

                UserSession.getInstance().setSaveHomeAddressObject(jsonObject+"");
                broadcastData();
                activity.finish();


            }
        });
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        dialog.show();

    }
    private void broadcastData() {
        Intent intent = new Intent("data_action_add_change");
        intent.putExtra("onAddressChange", "" + "changed");
        mContext.sendBroadcast(intent);
    }
}
