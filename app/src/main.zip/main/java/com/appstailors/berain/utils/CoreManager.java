package com.appstailors.berain.utils;

import android.content.Context;

import com.appstailors.berain.object.Areas;
import com.appstailors.berain.object.Cart;
import com.appstailors.berain.object.Channels;
import com.appstailors.berain.object.Cities;
import com.appstailors.berain.object.CompanySetting;
import com.appstailors.berain.object.Favourites;
import com.appstailors.berain.object.PopupPromo;
import com.appstailors.berain.object.SubChannels;
import com.appstailors.berain.object.Tips;
import com.appstailors.berain.object.login.Address;
import com.appstailors.berain.object.login.User;
import com.appstailors.berain.object.request.Area;
import com.roam.appdatabase.DatabaseManager;

public class CoreManager {
    private static final String TAG = "CoreManager";
    private static final CoreManager instance = new CoreManager();
    public Context context;

    public static synchronized CoreManager getInstance() {
        CoreManager coreManager;
        synchronized (CoreManager.class) {
            coreManager = instance;
        }
        return coreManager;
    }

    public void setContext(Context context) {
        if (this.context == null) {
            this.context = context.getApplicationContext();
            initDatabase(context);
        }
    }

    private void initDatabase(Context context) {
        DatabaseManager.beginSetup(context)
                .setDBName("berainDb")
                .setDBVersion(28)
                .wipeOnVersionChange()
                .registerClass(User.class)
                .registerClass(Address.class)
                .registerClass(Channels.class)
                .registerClass(SubChannels.class)
                .registerClass(Cities.class)
                .registerClass(Tips.class)
                .registerClass(Cart.class)
                .registerClass(CompanySetting.class)
                .registerClass(PopupPromo.class)
                .registerClass(Areas.class)
                .registerClass(Favourites.class)
                .save();
    }

    public void removeLocaleData() {
        DatabaseManager.getInstance().destroyAllForClass(User.class, true);
        DatabaseManager.getInstance().destroyAllForClass(Address.class, true);
        DatabaseManager.getInstance().destroyAllForClass(Channels.class, true);
        DatabaseManager.getInstance().destroyAllForClass(SubChannels.class, true);
        DatabaseManager.getInstance().destroyAllForClass(Cities.class, true);
        DatabaseManager.getInstance().destroyAllForClass(Tips.class, true);
        DatabaseManager.getInstance().destroyAllForClass(Cart.class, true);
        DatabaseManager.getInstance().destroyAllForClass(CompanySetting.class, true);
        DatabaseManager.getInstance().destroyAllForClass(Areas.class, true);

    }

    public void removeUserData() {
        DatabaseManager.getInstance().destroyAllForClass(User.class, false);
        // DatabaseManager.getInstance().destroyAllForClass(CompanySetting.class, false);
        DatabaseManager.getInstance().destroyAllForClass(Address.class, false);
        DatabaseManager.getInstance().destroyAllForClass(Cart.class, false);
        DatabaseManager.getInstance().destroyAllForClass(Favourites.class, false);
        // DatabaseManager.getInstance().destroyAllForClass(CompanySetting.class, false);
    }

    public void removeCityAreaData(){
        DatabaseManager.getInstance().destroyAllForClass(Cities.class, true);
        DatabaseManager.getInstance().destroyAllForClass(Areas.class, true);
    }
    public void removeUserAddresses() {
        // DatabaseManager.getInstance().destroyAllForClass(CompanySetting.class, false);
        DatabaseManager.getInstance().destroyAllForClass(Address.class, false);

        // DatabaseManager.getInstance().destroyAllForClass(CompanySetting.class, false);
    }
}
