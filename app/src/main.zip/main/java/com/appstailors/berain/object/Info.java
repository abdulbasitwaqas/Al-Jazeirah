package com.appstailors.berain.object;

/**
 * Created by Mustanser Iqbal on 11/28/2017.
 */

public class Info {

    String text;
    int color;


    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public int getColor() {
        return color;
    }

    public void setColor(int color) {
        this.color = color;
    }
}
