package com.appstailors.berain.ui;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;

import com.appstailors.berain.AppController;
import com.appstailors.berain.R;
import com.appstailors.berain.UserSession;
import com.appstailors.berain.utils.BerainContextWrapper;

import java.util.Locale;

import io.github.inflationx.viewpump.ViewPumpContextWrapper;

public class ShareActivity extends AppCompatActivity {

    private boolean isArabic;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        isArabic = AppController.setLocale();

        setContentView(R.layout.share_activity);
    }

    public void closeActivity(View v) {
        finish();
    }

    public void shareContent(View v) {
        Intent sendIntent = new Intent();
        sendIntent.setAction(Intent.ACTION_SEND);
        sendIntent.putExtra(Intent.EXTRA_TEXT, getResources().getString(R.string.delicious_text));
        sendIntent.setType("text/plain");
        startActivity(Intent.createChooser(sendIntent, "Share with"));
    }

    @Override
    public void onBackPressed() {
        finish();
    }

    @Override
    protected void attachBaseContext(Context newBase) {
        Context context = BerainContextWrapper.wrap(newBase, new Locale(UserSession.getInstance().getUserLanguage()));
        super.attachBaseContext(ViewPumpContextWrapper.wrap(context));
    }
}
