package com.appstailors.berain.object;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

/**
 * Created by Mustanser Iqbal on 12/3/2017.
 */

public class ProductByLocation implements Serializable {


    @SerializedName("id")
    @Expose
    private String id;
    @SerializedName("img")
    @Expose
    private String img;
    @SerializedName("cat_ar")
    @Expose
    private String catAr;
    @SerializedName("cat_en")
    @Expose
    private String catEn;
    @SerializedName("price")
    @Expose
    private String price;
    @SerializedName("material")
    @Expose
    private String material;
    @SerializedName("unit")
    @Expose
    private String unit;
    @SerializedName("name_ar")
    @Expose
    private String nameAr;
    @SerializedName("name_en")
    @Expose
    private String nameEn;
    @SerializedName("description_ar")
    @Expose
    private String descriptionAr;
    @SerializedName("description_en")
    @Expose
    private String descriptionEn;
    @SerializedName("product_sort_app")
    @Expose
    private String productSortApp;
    @SerializedName("status")
    @Expose
    private String status;
    @SerializedName("stock")
    @Expose
    private String stock;
    @SerializedName("category_id")
    @Expose
    private String category_id;

    @SerializedName("prod_detail_en")
    @Expose
    private String prod_detail_en;

    @SerializedName("prod_detail_ar")
    @Expose
    private String prod_detail_ar;


    @SerializedName("price_vat")
    @Expose
    private String price_vat;

    @SerializedName("before_discount")
    @Expose
    private String before_discount;

    public String getBefore_discount() {
        return before_discount;
    }

    public void setBefore_discount(String before_discount) {
        this.before_discount = before_discount;
    }

    public String getPrice_vat() {
        return price_vat;
    }

    public void setPrice_vat(String price_vat) {
        this.price_vat = price_vat;
    }

    public String getProd_detail_en() {
        return prod_detail_en;
    }

    public void setProd_detail_en(String prod_detail_en) {
        this.prod_detail_en = prod_detail_en;
    }

    public String getProd_detail_ar() {
        return prod_detail_ar;
    }

    public void setProd_detail_ar(String prod_detail_ar) {
        this.prod_detail_ar = prod_detail_ar;
    }

    private int count = 0;
    private boolean isAddedToCart;
    private final static long serialVersionUID = -4214695899142089859L;
    //public boolean promotion_available=false;

    //public String base_quantity="";
    //public String free_items="";

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }

    public String getCatAr() {
        return catAr;
    }

    public void setCatAr(String catAr) {
        this.catAr = catAr;
    }

    public String getCatEn() {
        return catEn;
    }

    public void setCatEn(String catEn) {
        this.catEn = catEn;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public String getNameAr() {
        return nameAr;
    }

    public void setNameAr(String nameAr) {
        this.nameAr = nameAr;
    }

    public String getNameEn() {
        return nameEn;
    }

    public void setNameEn(String nameEn) {
        this.nameEn = nameEn;
    }

    public String getDescriptionAr() {
        return descriptionAr;
    }

    public void setDescriptionAr(String descriptionAr) {
        this.descriptionAr = descriptionAr;
    }

    public String getDescriptionEn() {
        return descriptionEn;
    }

    public void setDescriptionEn(String descriptionEn) {
        this.descriptionEn = descriptionEn;
    }

    public String getProductSortApp() {
        return productSortApp;
    }

    public void setProductSortApp(String productSortApp) {
        this.productSortApp = productSortApp;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getStock() {
        return stock;
    }

    public void setStock(String stock) {
        this.stock = stock;
    }

    public String getCategory_id() {
        return category_id;
    }

    public void setCategory_id(String category_id) {
        this.category_id = category_id;
    }
    public void setAddedToCart(boolean addedToCart) {
        isAddedToCart = addedToCart;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }


/*
    @SerializedName("id")
    @Expose
    private String id;
    @SerializedName("img")
    @Expose
    private String img;
    @SerializedName("cat_ar")
    @Expose
    private String catAr;
    @SerializedName("cat_en")
    @Expose
    private String catEn;
    @SerializedName("price")
    @Expose
    private String price;

    @SerializedName("price_vat")
    @Expose
    private String price_vat;

    public String getPrice_vat() {
        return price_vat;
    }

    public void setPrice_vat(String price_vat) {
        this.price_vat = price_vat;
    }

    @SerializedName("material")
    @Expose
    private String material;
    @SerializedName("unit")
    @Expose
    private String unit;
    @SerializedName("name_ar")
    @Expose
    private String nameAr;
    @SerializedName("name_en")
    @Expose
    private String nameEn;
    @SerializedName("description_ar")
    @Expose
    private String descriptionAr;
    @SerializedName("description_en")
    @Expose
    private String descriptionEn;
    @SerializedName("product_sort_app")
    @Expose
    private String productSortApp;
    @SerializedName("status")
    @Expose
    private String status;
    @SerializedName("stock")
    @Expose
    private String stock;
    @SerializedName("category_id")
    @Expose
    private String category_id;

    private int count = 0;
    private boolean isAddedToCart;
    private final static long serialVersionUID = -4214695899142089859L;
    public boolean promotion_available=false;

    public String base_quantity="";
    public String free_items="";

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }

    public String getCatAr() {
        return catAr;
    }

    public void setCatAr(String catAr) {
        this.catAr = catAr;
    }

    public String getCatEn() {
        return catEn;
    }

    public void setCatEn(String catEn) {
        this.catEn = catEn;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public String getNameAr() {
        return nameAr;
    }

    public void setNameAr(String nameAr) {
        this.nameAr = nameAr;
    }

    public String getNameEn() {
        return nameEn;
    }

    public void setNameEn(String nameEn) {
        this.nameEn = nameEn;
    }

    public String getDescriptionAr() {
        return descriptionAr;
    }

    public void setDescriptionAr(String descriptionAr) {
        this.descriptionAr = descriptionAr;
    }

    public String getDescriptionEn() {
        return descriptionEn;
    }

    public void setDescriptionEn(String descriptionEn) {
        this.descriptionEn = descriptionEn;
    }

    public String getProductSortApp() {
        return productSortApp;
    }

    public void setProductSortApp(String productSortApp) {
        this.productSortApp = productSortApp;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getStock() {
        return stock;
    }

    public void setStock(String stock) {
        this.stock = stock;
    }

    public String getCategory_id() {
        return category_id;
    }

    public void setCategory_id(String category_id) {
        this.category_id = category_id;
    }
    public void setAddedToCart(boolean addedToCart) {
        isAddedToCart = addedToCart;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public boolean isPromotion_available() {
        return promotion_available;
    }

    public void setPromotion_available(boolean promotion_available) {
        this.promotion_available = promotion_available;
    }

    public String getBase_quantity() {
        return base_quantity;
    }

    public void setBase_quantity(String base_quantity) {
        this.base_quantity = base_quantity;
    }

    public String getFree_items() {
        return free_items;
    }

    public void setFree_items(String free_items) {
        this.free_items = free_items;
    }*/

}