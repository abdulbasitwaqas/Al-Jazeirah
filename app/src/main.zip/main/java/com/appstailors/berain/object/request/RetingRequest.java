package com.appstailors.berain.object.request;

public class RetingRequest {

    String client_id,order_id,customer_service,delivery_time,customer_comments,block_popup;

    public RetingRequest(String client_id, String order_id, String customer_service, String delivery_time,String customer_comments, String block_popup) {
        this.client_id = client_id;
        this.order_id = order_id;
        this.customer_service = customer_service;
        this.delivery_time = delivery_time;
        this.block_popup = block_popup;
        this.customer_comments = customer_comments;
    }



}
