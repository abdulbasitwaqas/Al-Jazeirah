package com.appstailors.berain.utils;

import android.util.Log;

import androidx.annotation.NonNull;

import com.appstailors.berain.BuildConfig;
import com.appstailors.berain.object.login.User;
import com.roam.appdatabase.DatabaseManager;

import java.io.IOException;

import okhttp3.Interceptor;
import okhttp3.Request;
import okhttp3.Response;

/**
 *
 */

public class AddHeaderInterceptor implements Interceptor {


    @Override
    public Response intercept(@NonNull Chain chain) throws IOException {
        User user = DatabaseManager.getInstance().getFirstOfClass(User.class);;
        Request.Builder builder = chain.request().newBuilder();
        builder.header("AppVersion", "Android:"+BuildConfig.VERSION_NAME);
        builder.header("Content-Type", "application/json");

        if (user != null)
            builder.header("Authorization", user.authToken);
        else
            builder.header("Authorization", Constants.KEY);

        return chain.proceed(builder.build());
    }
}