package com.appstailors.berain.ui;

import android.content.Context;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.appsflyer.AFInAppEventParameterName;
import com.appsflyer.AFInAppEventType;
import com.appsflyer.AppsFlyerLib;
import com.appstailors.berain.AppController;
import com.appstailors.berain.R;
import com.appstailors.berain.UserSession;
import com.appstailors.berain.object.Cart;
import com.appstailors.berain.utils.BerainContextWrapper;
import com.appstailors.berain.utils.Constants;
import com.google.firebase.analytics.FirebaseAnalytics;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import io.github.inflationx.viewpump.ViewPumpContextWrapper;

import static com.appstailors.berain.ui.CheckOutActivity.orderdetailactivity;
import static com.appstailors.berain.utils.Constants.ORDER_REFERENCE;

public class SuccessfullOrder extends AppCompatActivity implements View.OnClickListener {
    private TextView tv_ordercreated;
    private TextView tv_transactioncreated;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_successfull_order);
        setViews();
    }

    private void setViews() {
        Constants.validate_promocode=false;
        Button gotomyorder = findViewById(R.id.successfulOrder_btnMyOrders);
        gotomyorder.setOnClickListener(this);
        tv_ordercreated = findViewById(R.id.tv_ordercreated);
        tv_transactioncreated = findViewById(R.id.tv_transactioncreated);
        setDataFromIntent();

        Cart.emptyCart();
        orderdetailactivity.finish();

        Map<String, Object> eventValue = new HashMap<String, Object>();
        eventValue.put(AFInAppEventParameterName.PAYMENT_INFO_AVAILIBLE,"TransictionId:"+getIntent().getStringExtra("id"));
        eventValue.put(AFInAppEventParameterName.CURRENCY,"SAR");
        eventValue.put(AFInAppEventParameterName.REVENUE,""+Double.parseDouble(getIntent().getStringExtra("amount_withoutVat")));
        AppsFlyerLib.getInstance().trackEvent(getApplicationContext() , AFInAppEventType.PURCHASE , eventValue);

    }

    private void setDataFromIntent() {
        tv_ordercreated.setText(getResources().getString(R.string.st_order_created)+"  "+ getIntent().getStringExtra("id"));
        if(getIntent().getBooleanExtra("cc",true))
        tv_transactioncreated.setText(getResources().getString(R.string.st_transaction_created)+"  "+getIntent().getStringExtra(ORDER_REFERENCE));
        else{

        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.successfulOrder_btnMyOrders:
                if (AppController.getInstance().getViewPager_home()!=null) {
                    AppController.getInstance().getViewPager_home().setCurrentItem(2);
                    AppController.getInstance().getActivity().finish();
                }
                finish();
                overridePendingTransition(0,R.anim.exit_anim);
                break;

        }
    }

    @Override
    protected void attachBaseContext(Context newBase) {
        Context context = BerainContextWrapper.wrap(newBase, new Locale(UserSession.getInstance().getUserLanguage()));
        super.attachBaseContext(ViewPumpContextWrapper.wrap(context));
    }
}
