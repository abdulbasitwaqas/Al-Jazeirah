package com.appstailors.berain.ui;

import android.Manifest;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.location.Location;
import android.net.Uri;
import android.os.Bundle;
import android.os.Looper;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;


import com.appsflyer.AFInAppEventParameterName;
import com.appsflyer.AFInAppEventType;
import com.appsflyer.AppsFlyerLib;
import com.appstailors.berain.AppController;
import com.appstailors.berain.BuildConfig;
import com.appstailors.berain.R;
import com.appstailors.berain.UserSession;
import com.appstailors.berain.object.Areas;
import com.appstailors.berain.object.Cities;
import com.appstailors.berain.object.CompanySetting;
import com.appstailors.berain.object.GeoCodeApi.ModelGeoCodeApi;
import com.appstailors.berain.object.YourOrderDetails.OrderDetail;
import com.appstailors.berain.object.login.User;
import com.appstailors.berain.object.request.CompanySettings;
import com.appstailors.berain.object.request.RetingRequest;
import com.appstailors.berain.ui.HomeScreen.HomeScreenActivity;
import com.appstailors.berain.utils.APIManager;
import com.appstailors.berain.utils.BerainContextWrapper;
import com.appstailors.berain.utils.Constants;
import com.appstailors.berain.utils.CoreManager;
import com.appstailors.berain.utils.HmsGmsUtil;
import com.appstailors.berain.utils.RequestPermissionHandler;
import com.appstailors.berain.utils.gpsLocation.GPSTracker;
import com.appstailors.berain.utils.gpsLocation.GetLocationByGoogleClientApi;
import com.bumptech.glide.Glide;
import com.clevertap.android.sdk.CleverTapAPI;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.huawei.agconnect.config.AGConnectServicesConfig;
import com.huawei.hms.aaid.HmsInstanceId;
import com.huawei.hms.location.FusedLocationProviderClient;
import com.huawei.hms.location.LocationRequest;
import com.roam.appdatabase.DatabaseManager;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.swiperefreshlayout.widget.CircularProgressDrawable;

import io.github.inflationx.viewpump.ViewPumpContextWrapper;

import static com.appstailors.berain.utils.Constants.IMAGE_BASE_URL;
import static com.appstailors.berain.utils.Constants.PROMO_BASE_URL;


public class SplashScreenActivity extends AppCompatActivity {
    ImageView logo;
    View progress_bar;
    Button btnGetStart;
    private boolean isArabic;
    TextView tvPleaseWait;
    private RequestPermissionHandler mRequestPermissionHandler;
    private boolean permissonCheck = false;
    GetLocationByGoogleClientApi getLocationByGoogleClientApi;
    private int cityId = 0;
    private int areaId = 0;
    private String mapCity = "";
    private String mapArea = "";
    Gson gson;
    boolean goHome = true;
    ProgressDialog mProgressDialog;
    User user = DatabaseManager.getInstance().getFirstOfClass(User.class);
    boolean isRating = false;
    boolean isPopup = false;
    String reference_id = "";
    String key = "";


    double latitude;
    double longitude;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        isArabic = AppController.setLocale();
        mRequestPermissionHandler = new RequestPermissionHandler();
        getLocationByGoogleClientApi = new GetLocationByGoogleClientApi(SplashScreenActivity.this);
        createGson();

        HmsGmsUtil.isOnlyHms(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.splash_screen);
        logo = findViewById(R.id.logo_splash);
        progress_bar = findViewById(R.id.progress_bar);
        btnGetStart = findViewById(R.id.btnGetStart);
        tvPleaseWait = findViewById(R.id.tvPleaseWait);
        progress_bar.setVisibility(View.GONE);
        btnGetStart.setVisibility(View.GONE);

        if (HmsGmsUtil.isOnlyHms(this)) {
            getHMSToken();

        } else {
            FirebaseInstanceId.getInstance().getInstanceId().addOnSuccessListener(SplashScreenActivity.this, new OnSuccessListener<InstanceIdResult>() {
                @Override
                public void onSuccess(InstanceIdResult instanceIdResult) {
                    String newToken = instanceIdResult.getToken();
                    Log.e("newToken", newToken);
                    UserSession.getInstance().setToken(newToken);
                }
            });
        }


        if (!UserSession.getInstance().getToken().equals("")) {
            Map<String, Object> eventValue = new HashMap<String, Object>();
            eventValue.put(AFInAppEventParameterName.PARAM_1, "" + "FCM Android" + "" + UserSession.getInstance().getToken());
            CleverTapAPI.getDefaultInstance(this).pushEvent("FCM Android Token:", eventValue);
            CleverTapAPI.getDefaultInstance(this).pushFcmRegistrationId(UserSession.getInstance().getToken(),true);
        }


        if (isArabic) {
            logo.setImageResource(R.drawable.bg_splash);
            btnGetStart.setText("ابدأ");
            tvPleaseWait.setText("ارجوك انتظر");
        }

        if (getIntent().getExtras() != null) {

            for (String key : getIntent().getExtras().keySet()) {
                Object value = getIntent().getExtras().get(key);
                if (key.equals("key")) {
                    this.key = value.toString();
                }
                if (key.equals("reference_id")) {
                    reference_id = value.toString();
                }
                Log.d("TAG", "Key: " + key + " Value: " + value);
            }


            Log.d("TAG", "reference_id: " + reference_id + " \nkey: " + this.key);

        }

        Log.d("Keysssss", this.key + "........");

        if (!reference_id.equals("") || !key.equals("")) {
            if (key.equals("order_detail") && user != null) {
                Intent intent = new Intent(SplashScreenActivity.this, OrderDetails.class);
                intent.putExtra("order_id", reference_id);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK
                        | Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS | Intent.FLAG_ACTIVITY_NO_ANIMATION);
                startActivity(intent);
                finish();
            } else {
                setCompanySettings();
            }
        } else {
            setCompanySettings();
        }


        btnGetStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (permissonCheck) {
                    if (getUserCurrentLatLong() && UserSession.getInstance().getSaveAddressObject().equals("")) {
                        getAddressRequest();
                    } else {
                        goToHomeScreenActivity();
                    }
                } else handlePermissions();

            }
        });
        handlePermissions();
    }

    private void getHMSToken(){
        // get token
        new Thread() {
            @Override
            public void run() {
                try {
                    String appId = AGConnectServicesConfig.fromContext(getApplicationContext()).getString("client/app_id");
                    String pushtoken = HmsInstanceId.getInstance(getApplicationContext()).getToken(appId, "HCM");
                    if(!TextUtils.isEmpty(pushtoken)) {
                        //showToken(pushtoken);
                        Log.i("TAG","getToken: " + pushtoken);

                        UserSession.getInstance().setToken(pushtoken);
                    }
                } catch (Exception e) {
                    Log.i("TAG","getToken failed, " + e);
                    Log.i("TAG","getToken failed, " + e);

                }
            }
        }.start();
    }


    private void createGson() {
        GsonBuilder gsonBuilder = new GsonBuilder();
        gsonBuilder.setDateFormat("M/d/yy hh:mm a");
        gson = gsonBuilder.create();
    }

    private void setCompanySettings() {
        progress_bar.setVisibility(View.VISIBLE);
        CompanySettings companySettings = new CompanySettings();
        if (user != null)
            companySettings.setUser_id(user.userId);
        else
            companySettings.setUser_id("");

        companySettings.setLocation_date(UserSession.getInstance().getLastAreaUpdatedDate());

        Log.d("lastareadate", UserSession.getInstance().getLastAreaUpdatedDate());
        APIManager.getInstance().getCompanySettings(new APIManager.Callback() {
            @Override
            public void onResult(boolean z, String response) {
                progress_bar.setVisibility(View.GONE);
                if (z) {
                    if (response.contains("Access denied") || response.contains("Invalid Key!") || response.contains("Invalid Key")) {
                        CoreManager.getInstance().removeUserData();
                        Toast.makeText(SplashScreenActivity.this, "" + getResources().getString(R.string.logout), Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(SplashScreenActivity.this, SplashScreenActivity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        finish();
                        startActivity(intent);
                    } else {
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            JSONObject jsonObjectRows = jsonObject.getJSONObject("rows");
                            JSONArray arrayCities = jsonObjectRows.getJSONArray("cities");
                            JSONArray arrayAreas = jsonObjectRows.getJSONArray("areas");
                            CompanySetting.fromJson(jsonObjectRows);
                            CompanySetting companySetting = DatabaseManager.getInstance().getFirstOfClass(CompanySetting.class);
                            int versionfromserver = Integer.parseInt(jsonObjectRows.getString("cur_android_ver").replace(".", ""));
                            int versionapp = Integer.parseInt(BuildConfig.VERSION_NAME.replace(".", ""));

                            if (versionfromserver > versionapp) {
                                openVersionDialog();
                            } else {
                                //User user = DatabaseManager.getInstance().getFirstOfClass(User.class);
                                if (jsonObjectRows.getString("delete_addresses").equals("1") && user != null) {
                                    UserSession.getInstance().setSaveHomeAddressObject("");
                                    CoreManager.getInstance().removeUserData();
                                    Toast.makeText(SplashScreenActivity.this, "" + getResources().getString(R.string.logout), Toast.LENGTH_SHORT).show();
                                    if (getUserCurrentLatLong() && UserSession.getInstance().getSaveAddressObject().equals("")) {
                                        getAddressRequest();
                                    }
                                }

                                if (arrayAreas.length() > 0 && arrayCities.length() > 0) {
                                    Areas.fromJson(arrayAreas);
                                    Cities.fromJson(arrayCities);
                                    btnGetStart.setVisibility(View.VISIBLE);
                                    UserSession.getInstance().setLastAreaUpdatedDate(jsonObjectRows.getString("last_area_updated_date"));
                                } else {
                                    if (jsonObjectRows.getString("feedback_order").equals("") &&
                                            (jsonObjectRows.getString("full_page_promo_en").equals("") || jsonObjectRows.getString("full_page_promo_ar").equals("")))
                                        goToHomeScreenActivity();
                                }
                                if (!jsonObjectRows.getString("feedback_order").equals("") && user != null) {
                                    rattingAlertDialog(jsonObjectRows.getString("feedback_order"), jsonObjectRows.optString("feedback_order_number"));
                                } else if (jsonObjectRows.getString("full_page_promo_en").equals("") && arrayAreas.length() <= 0) {
                                    goToHomeScreenActivity();
                                }

                                if (!jsonObjectRows.getString("full_page_promo_en").equals("") ||
                                        !jsonObjectRows.getString("full_page_promo_ar").equals("")) {

                                    if (isArabic)
                                        showPromoPopupAlert(jsonObjectRows.getString("full_page_promo_ar"));
                                    else
                                        showPromoPopupAlert(jsonObjectRows.getString("full_page_promo_en"));

                                }
                                if (!jsonObjectRows.getString("base_api_url").equals("")) {
                                    Constants.BASE_URL = jsonObjectRows.getString("base_api_url");
                                }

                            }
                        } catch (Exception e) {
                            Log.e("Exceptin", e.toString());
                        }
                    }
                } else {
                    Toast.makeText(SplashScreenActivity.this, "Something went wrong try again", Toast.LENGTH_SHORT).show();
                }
            }
        }, companySettings, SplashScreenActivity.this);
    }

    private void rattingAlertDialog(final String orderNumber, String feedback_order_number) {
        final Dialog dialog = new Dialog(this);
        dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.setContentView(R.layout.ratting_alert_dialog);
        ImageView imageClose = dialog.findViewById(R.id.imageClose);
        TextView tvOrderTitle = dialog.findViewById(R.id.tvOrderTitle);
        final EditText editUserRemarks = dialog.findViewById(R.id.editUserRemarks);
        final TextView tvSubmitRating = dialog.findViewById(R.id.tvSubmitRating);
        final RatingBar ratingYourSatisfaction = dialog.findViewById(R.id.ratingYourSatisfaction);
        final RatingBar ratingOverallEcperience = dialog.findViewById(R.id.ratingOverallEcperience);
        isRating = true;
        tvOrderTitle.setText(getResources().getString(R.string.st_orderarrived_feedback) + ": " +
                feedback_order_number + "\n" + getResources().getString(R.string.st_rateorder_feedback));

        ratingYourSatisfaction.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {

            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating,
                                        boolean fromUser) {
                Log.d("rating", "" + rating);
                if (rating > 0 && ratingOverallEcperience.getRating() > 0) {
                    tvSubmitRating.setVisibility(View.VISIBLE);
                } else {
                    tvSubmitRating.setVisibility(View.GONE);
                }

            }
        });

        ratingOverallEcperience.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {

            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating,
                                        boolean fromUser) {
                if (rating > 0 && ratingYourSatisfaction.getRating() > 0) {
                    tvSubmitRating.setVisibility(View.VISIBLE);
                } else {
                    tvSubmitRating.setVisibility(View.GONE);
                }
            }
        });

        tvSubmitRating.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Log.d("request body", "" + new Gson().toJson(new RetingRequest(user.userId, orderNumber, "" + ratingOverallEcperience.getRating(),
                        "" + ratingYourSatisfaction.getRating(), editUserRemarks.getText().toString().trim(), "0")));

                showProgress(true);
                Log.d("ratings", "" + ratingYourSatisfaction.getRating() + "," + ratingOverallEcperience.getRating());

                APIManager.getInstance().saveOrderRating(new APIManager.Callback() {
                    @Override
                    public void onResult(boolean z, String response) {
                        showProgress(false);
                        try {
                            Toast.makeText(SplashScreenActivity.this, getResources().getString(R.string.st_rating_submitted), Toast.LENGTH_SHORT).show();
                            goToHomeScreenActivity();
                        } catch (Exception ex) {

                        }
                        dialog.dismiss();
                        isRating = false;
                    }
                }, new RetingRequest(user.userId, orderNumber, "" + ratingYourSatisfaction.getRating(), "" + ratingOverallEcperience.getRating(), editUserRemarks.getText().toString().trim(), "0"));

                //dialog.dismiss();
            }
        });

        dialog.setCancelable(false);

        imageClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showProgress(true);
                APIManager.getInstance().saveOrderRating(new APIManager.Callback() {
                    @Override
                    public void onResult(boolean z, String response) {
                        showProgress(false);
                        try {
                            // Toast.makeText(HomeScreenActivity.this, new JSONObject(response).getString("status"), Toast.LENGTH_SHORT).show();
                            goToHomeScreenActivity();

                        } catch (Exception ex) {

                        }
                    }
                }, new RetingRequest(user.userId, orderNumber, "", "", "", "1"));

                dialog.dismiss();
                isRating = false;
            }
        });
        dialog.show();
    }

    private void showPromoPopupAlert(String promoUrl) {
        final Dialog dialog = new Dialog(SplashScreenActivity.this, R.style.Theme_AppCompat_Light_NoActionBar);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
        lp.copyFrom(dialog.getWindow().getAttributes());
        lp.width = WindowManager.LayoutParams.MATCH_PARENT;
        lp.height = WindowManager.LayoutParams.MATCH_PARENT;
        isPopup = true;
        dialog.setContentView(R.layout.promo_popup_layout);
        ImageButton btnClose = dialog.findViewById(R.id.btnClose);
        ImageView popupImg = dialog.findViewById(R.id.popupImg);
  /*      TextView txtPopupTitle = dialog.findViewById(R.id.txtPopupTitle);
        if (promo.title.trim().length() > 0) {
            txtPopupTitle.setText(promo.title);
            txtPopupTitle.setVisibility(View.VISIBLE);
        } else {
            txtPopupTitle.setVisibility(View.GONE);
        }*/

        CircularProgressDrawable cd = new CircularProgressDrawable(this);
        cd.setStrokeWidth(10f);
        cd.setCenterRadius(100f);
        cd.start();
        Glide.with(this)
                .load(PROMO_BASE_URL + promoUrl)
//                    .placeholder(R.drawable.loading_spinner)
                .placeholder(cd)
//                    .override(100, 100)
                .into(popupImg);
        popupImg.setVisibility(View.VISIBLE);

        btnClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
                //   drawer.removeView(popupPromoContainer);
                if (!isRating)
                    goToHomeScreenActivity();
            }
        });

        dialog.setCancelable(false);
        dialog.show();
        dialog.getWindow().setAttributes(lp);

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    private void showProgress(boolean show) {
        if (show) {
            if (mProgressDialog != null && mProgressDialog.isShowing()) {
                mProgressDialog.dismiss();
            }
            mProgressDialog = new ProgressDialog(SplashScreenActivity.this);
            mProgressDialog.setMessage(getResources().getString(R.string.please_wait));
            mProgressDialog.setIndeterminate(false);
            mProgressDialog.setCancelable(false);
            mProgressDialog.show();
        } else {
            if (mProgressDialog != null && mProgressDialog.isShowing()) {
                mProgressDialog.dismiss();
            }
        }
    }

    private void openVersionDialog() {
        Dialog dialogVersion;
        dialogVersion = new Dialog(this);
        dialogVersion.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialogVersion.setContentView(R.layout.version_dialog);
        TextView title = (TextView) dialogVersion.findViewById(R.id.title);
        title.setText(getResources().getString(R.string.update_version));
        TextView message = (TextView) dialogVersion.findViewById(R.id.message);
        message.setText(getResources().getString(R.string.update_version_msg));

        Button ok = (Button) dialogVersion.findViewById(R.id.okBtn);
        Button cancel = (Button) dialogVersion.findViewById(R.id.cancelBtn);
        dialogVersion.setCancelable(false);

        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + getPackageName())));
                } catch (android.content.ActivityNotFoundException anfe) {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + getPackageName())));
                }

            }
        });

        dialogVersion.show();
    }

    public void goToHomeScreenActivity() {
        if (permissonCheck) {
            if (goHome) {
                goHome = false;
                startActivity(new Intent(getApplicationContext(), HomeScreenActivity.class));
                overridePendingTransition(R.anim.enter_anim, 0);
                finish();
            }
        } else {
            handlePermissions();
            btnGetStart.setVisibility(View.VISIBLE);
        }
    }

    public void handlePermissions() {
        mRequestPermissionHandler.requestPermission(this, new String[]{
                Manifest.permission.ACCESS_FINE_LOCATION
        }, 123, new RequestPermissionHandler.RequestPermissionListener() {
            @Override
            public void onSuccess() {
                permissonCheck = true;
            }

            @Override
            public void onFailed() {
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        mRequestPermissionHandler.onRequestPermissionsResult(requestCode, permissions,
                grantResults);
    }

    private void getAddressRequest() {
        String language = "en";
        if (AppController.setLocale()) {
            language = "ar";
        }
        progress_bar.setVisibility(View.VISIBLE);

        APIManager.getInstance().getAddressByLatLng(new APIManager.Callback() {
            @Override
            public void onResult(boolean z, String response) {
                // Log.d("onResult: ApiResponse: ", "" + response);
                progress_bar.setVisibility(View.GONE);
                if (z) {
                    try {
                        JSONObject jsonObject = new JSONObject(response);

                        boolean flag = false;
                        boolean areaflag = false;
                        ModelGeoCodeApi geoCodeApi = gson.fromJson(jsonObject.toString(), ModelGeoCodeApi.class);
                        if (geoCodeApi.getStatus().equals("ZERO_RESULTS")) {
                            Toast.makeText(SplashScreenActivity.this, "Location not found", Toast.LENGTH_SHORT).show();
                        } else if (geoCodeApi.getStatus().equals("OVER_QUERY_LIMIT")) {
                            Toast.makeText(SplashScreenActivity.this, "Location not found", Toast.LENGTH_SHORT).show();
                        } else {
                            for (int i = 0; i < geoCodeApi.getResults().get(0).getAddressComponents().size(); i++) {
                                for (int k = 0; k < geoCodeApi.getResults().get(0).getAddressComponents().get(i).getTypes().size(); k++) {
                                    if (geoCodeApi.getResults().get(0).getAddressComponents().get(i).getTypes().get(k).equals("locality")) {
                                        mapCity = geoCodeApi.getResults().get(0).getAddressComponents().get(i).getLongName();
                                        Log.d("localitymapcity", "..." + mapCity);
                                    }

                                    if (geoCodeApi.getResults().get(0).getAddressComponents().get(i).getTypes().get(k).equals("sublocality")) {
                                        mapArea = geoCodeApi.getResults().get(0).getAddressComponents().get(i).getLongName();
                                        Log.d("localitymaparea", "..." + mapArea);
                                    }
                                }

                            }

                            List<Cities> cities = DatabaseManager.getInstance().getAllOfClass(Cities.class);

                            for (int j = 0; j < cities.size(); j++) {
                                if (cities.get(j).cityTitleEn.toLowerCase().equals(mapCity.toLowerCase()) || cities.get(j).cityTitleAr.toLowerCase().equals(mapCity.toLowerCase())) {
                                    flag = true;
                                    cityId = cities.get(j).cityId;
                                    Log.d("localitymapcity", "..." + cityId);
                                }
                            }

                            if (flag) {
                                if (cityId != 0) {
                                    //List<Areas> areas = DatabaseManager.getInstance().getAllOfClass(Areas.class);
                                    List<Areas> areas = getCityArea(cityId);

                                    for (int j = 0; j < areas.size(); j++) {
                                        if (areas.get(j).areaTitleEn.toLowerCase().equals(mapArea.toLowerCase()) || areas.get(j).areaTitleAr.toLowerCase().equals(mapArea.toLowerCase())) {
                                            areaflag = true;
                                            areaId = areas.get(j).areaId;
                                            Log.d("localitymapcity", "..." + areaId);
                                        }

                                    }
                                }

                                if (areaflag) {
                                    UserSession.getInstance().setSaveHomeAddressObject(creatJsonObject(latitude + "", longitude + "", geoCodeApi.getResults().get(0).getFormattedAddress()) + "");
                                }
                            }

                        }

                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }

                }
                goToHomeScreenActivity();
            }
        }, latitude + "," + longitude, language, SplashScreenActivity.this);
    }

    private List getCityArea(int cityId) {
        List<Areas> cityAreaList = new ArrayList<>();
        List<Areas> areasAll = DatabaseManager.getInstance().getAllOfClass(Areas.class);
        for (Areas area : areasAll) {
            if (cityId == area.areaCityId) {
                cityAreaList.add(area);
            }
        }

        return cityAreaList;
    }


    private JSONObject creatJsonObject(String lat, String lng, String addDetail) {
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("lat", lat + "");
            jsonObject.put("lng", lng + "");
            jsonObject.put("areaId", "" + areaId);
            jsonObject.put("cityId", "" + cityId);
            jsonObject.put("addressName", "Address: " + addDetail);
            jsonObject.put("details", "" + addDetail);
            jsonObject.put("address_id", "");
            jsonObject.put("add_type", "1");


        } catch (JSONException e) {
            e.printStackTrace();
        }
        return jsonObject;
    }

    @Override
    public void onResume() {
        registerReceiver(mReceiverLocation, new IntentFilter("data_action"));
        super.onResume();
    }

    @Override
    public void onPause() {
        unregisterReceiver(mReceiverLocation);
        super.onPause();
    }

    private BroadcastReceiver mReceiverLocation = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            try {
                String string = (String) intent.getSerializableExtra("onConnectedGoogleApi");
                Log.e("onConnectedGoogleApi", string);
                if (string.equals("connected"))
                    getUserCurrentLatLong();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    };

    private boolean getUserCurrentLatLong() {
        boolean isLocation = false;
        if (HmsGmsUtil.isOnlyHms(this)){
            GPSTracker tracker = new GPSTracker(this);
            Location location = tracker.getLocation();

            if(location != null) {
                latitude = location.getLatitude();
                longitude = location.getLongitude();
                isLocation = true;
            }
        }else {
            Location location = getLocationByGoogleClientApi.getMyLocation();
            if (location != null) {
                latitude = location.getLatitude();
                longitude = location.getLongitude();
                //LatLng currentLatLong = new LatLng(location.getLatitude(), location.getLongitude());
                CleverTapAPI.getDefaultInstance(this).setLocation(location); //android.location.Location
                isLocation = true;
            }
        }

        return isLocation;
    }

    @Override
    protected void attachBaseContext(Context newBase) {
        Context context = BerainContextWrapper.wrap(newBase, new Locale(UserSession.getInstance().getUserLanguage()));
        super.attachBaseContext(ViewPumpContextWrapper.wrap(context));
    }
}

