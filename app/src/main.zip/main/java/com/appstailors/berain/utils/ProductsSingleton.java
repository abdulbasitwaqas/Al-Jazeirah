package com.appstailors.berain.utils;

import android.view.View;
import android.widget.TextView;

import com.appstailors.berain.object.Areas;
import com.appstailors.berain.object.Cities;
import com.appstailors.berain.object.Orders;
import com.appstailors.berain.object.ProductByLocation;
import com.appstailors.berain.object.Promotions.Promotion;

import java.util.ArrayList;
import java.util.List;

public class ProductsSingleton {

    private static final ProductsSingleton ourInstance = new ProductsSingleton();

    public ArrayList<ProductByLocation> productByLocations;
    public View cartView,basketview;
    public TextView tv_cartamount,basket_badge;
    public ArrayList<Areas> cityAreas;
    public List<Cities> cities;
    private CustomViewPager customViewPager;
    private List<Promotion> PromotionList;
    public View slider;

    public  List<Orders> userOrdersList;

    public List<Orders> getUserOrdersList() {
        return userOrdersList;
    }

    public void setUserOrdersList(List<Orders> userOrdersList) {
        this.userOrdersList = userOrdersList;
    }

    public static ProductsSingleton getInstance() {
        return ourInstance;
    }

    private ProductsSingleton() {
    }

    public CustomViewPager getCustomViewPager() {
        return customViewPager;
    }

    public void setCustomViewPager(CustomViewPager customViewPager) {
        this.customViewPager = customViewPager;
    }

    public List<Promotion> getPromotionList() {
        return PromotionList;
    }

    public void setPromotionList(List<Promotion> promotionList) {
        PromotionList = promotionList;
    }

    public ArrayList<ProductByLocation> getProductByLocations() {
        return productByLocations;
    }

    public void setProductByLocations(ArrayList<ProductByLocation> productByLocations) {
        this.productByLocations = productByLocations;
    }


    public View getCartView() {
        return cartView;
    }

    public void setCartView(View cartView) {
        this.cartView = cartView;
    }


    public TextView getTv_cartamount() {
        return tv_cartamount;
    }

    public void setTv_cartamount(TextView tv_cartamount) {
        this.tv_cartamount = tv_cartamount;
    }

    public TextView getBasket_badge() {
        return basket_badge;
    }

    public void setBasket_badge(TextView basket_badge) {
        this.basket_badge = basket_badge;
    }

    public View getBasketview() {
        return basketview;
    }

    public void setBasketview(View basketview) {
        this.basketview = basketview;
    }

    public ArrayList<Areas> getCityAreas() {
        return cityAreas;
    }

    public void setCityAreas(ArrayList<Areas> cityAreas) {
        this.cityAreas = cityAreas;
    }

    public List<Cities> getCities() {
        return cities;
    }

    public void setCities(List<Cities> cities) {
        this.cities = cities;
    }




    public View getSlider() {
        return slider;
    }

    public void setSlider(View slider) {
        this.slider = slider;
    }
}
