package com.appstailors.berain;

import android.app.Activity;
import android.app.Application;
import android.app.NotificationManager;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.LocaleList;
import androidx.multidex.MultiDex;
import androidx.core.content.ContextCompat;
import androidx.viewpager.widget.ViewPager;

import com.appsflyer.AppsFlyerConversionListener;
import com.appsflyer.AppsFlyerLib;
import com.appstailors.berain.utils.CoreManager;
import com.appstailors.berain.utils.CustomViewWithTypefaceSupport;
import com.appstailors.berain.utils.TextField;
import com.clevertap.android.sdk.ActivityLifecycleCallback;
import com.clevertap.android.sdk.CleverTapAPI;
import com.clevertap.android.sdk.CleverTapInstanceConfig;
import com.facebook.FacebookSdk;
import com.facebook.appevents.AppEventsLogger;

import org.acra.ReportingInteractionMode;
import org.acra.annotation.ReportsCrashes;

import java.util.Locale;
import java.util.Map;

import io.github.inflationx.calligraphy3.CalligraphyConfig;
import io.github.inflationx.calligraphy3.CalligraphyInterceptor;
import io.github.inflationx.viewpump.ViewPump;

import static com.appstailors.berain.utils.Constants.ARABIC;

//import com.amitshekhar.DebugDB;
//

@ReportsCrashes(mailTo = "noreply@berain.com.sa",
        mode = ReportingInteractionMode.TOAST,
        resToastText = R.string.crash_toast_text)

public class AppController extends Application {

    public static final String TAG = AppController.class.getSimpleName();
    private Context mContext;
    private static final String AF_DEV_KEY = "n4QzPHhpEBvJhdru24Ys3h";
    public ViewPager viewPager_home;
    public Activity activity;
    public int[] colors = new int[3];
    private static AppController mInstance;



    public void onCreate() {
        ActivityLifecycleCallback.register(this);

        super.onCreate();
        mInstance = this;
        mContext = this;
        CoreManager.getInstance().setContext(this);
        UserSession.getInstance().setContext(this);

        if (UserSession.getInstance().getUserLanguage().equals(ARABIC)) {

            /*CalligraphyConfig.initDefault(new CalligraphyConfig.Builder()
                    .setDefaultFontPath("neo_sans_arabic.ttf")
                    .setFontAttrId(R.attr.fontPath)
                    .addCustomViewWithSetTypeface(CustomViewWithTypefaceSupport.class)
                    .addCustomStyle(TextField.class, R.attr.textFieldStyle)
                    .build()
            );*/

            ViewPump.init(ViewPump.builder()
                    .addInterceptor(new CalligraphyInterceptor(
                            new CalligraphyConfig.Builder()
                                    .setDefaultFontPath("neo_sans_arabic.ttf")
                                    .setFontAttrId(R.attr.fontPath)
                                    .build()))
                    .build());



//            TypefaceUtil.overrideFont(getApplicationContext(), "fonts/neo_sans_arabic.ttf");
        } else {
//            TypefaceUtil.overrideFont(getApplicationContext(), "Elgethy.ttf");

//            CalligraphyConfig.initDefault(new CalligraphyConfig.Builder()
////                    .setDefaultFontPath("fonts/neo_sans_arabic.ttf")
////                    .setFontAttrId(R.attr.fontPath)
////                    .addCustomViewWithSetTypeface(CustomViewWithTypefaceSupport.class)
////                    .addCustomStyle(TextField.class, R.attr.textFieldStyle)
////                    .build()
////            );
        }
        //ACRA.init(this);
        //  Log.e("ADDRESS", DebugDB.getAddressLog());
        colors = new int[]{ContextCompat.getColor(this, R.color.slider1),
                ContextCompat.getColor(this, R.color.slider2),
                ContextCompat.getColor(this, R.color.slider3)};

        AppsFlyerConversionListener conversionDataListener = new AppsFlyerConversionListener() {
            @Override
            public void onInstallConversionDataLoaded(Map<String, String> map) {

            }

            @Override
            public void onInstallConversionFailure(String s) {

            }

            @Override
            public void onAppOpenAttribution(Map<String, String> map) {

            }

            @Override
            public void onAttributionFailure(String s) {

            }
        };
        String appsFlyerId = AppsFlyerLib.getInstance().getAppsFlyerUID(this);
        AppsFlyerLib.getInstance().waitForCustomerUserId(true);
        AppsFlyerLib.getInstance().init(AF_DEV_KEY, conversionDataListener, getApplicationContext());
        AppsFlyerLib.getInstance().startTracking(this);
        AppsFlyerLib.getInstance().setCustomerIdAndTrack(appsFlyerId, this);
        FacebookSdk.sdkInitialize(getApplicationContext());
        AppEventsLogger.activateApp(this);

        CleverTapAPI.setDebugLevel(CleverTapAPI.LogLevel.DEBUG);   //Set Log level to DEBUG log warnings or other important messages
        CleverTapAPI.getDefaultInstance(getApplicationContext()).setOptOut(false);
        CleverTapAPI.getDefaultInstance(getApplicationContext()).enableDeviceNetworkInfoReporting(true);;

        CleverTapAPI.createNotificationChannel(getApplicationContext(),"Promotion","Promotion",
                "",NotificationManager.IMPORTANCE_MAX,true);
    }

    public Context getContext() {
        return mContext;
    }

    @Override
    protected void attachBaseContext(Context base) {

        super.attachBaseContext(base);
        MultiDex.install(this);

    }

    public static synchronized AppController getInstance() {
        return mInstance;
    }

    public static boolean setLocale() {

        String lang = UserSession.getInstance().getUserLanguage();

        Locale current = AppController.getInstance().getResources().getConfiguration().locale;

        Locale myLocale = new Locale(lang);
        Resources res = AppController.getInstance().getResources();
        Configuration conf = res.getConfiguration();
        if (lang.equals(ARABIC)) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                conf.setLocale(myLocale);

                LocaleList localeList = new LocaleList(myLocale);
                LocaleList.setDefault(localeList);
                conf.setLocales(localeList);

                AppController.getInstance().createConfigurationContext(conf);

            } else {
                conf.locale = myLocale;
            }

            //   DisplayMetrics dm = res.getDisplayMetrics();
            //   res.updateConfiguration(conf, dm);
            //   conf.setLayoutDirection(new Locale(lang));
            return true;
        } else {

            //    conf.locale = Locale.US;
            //     DisplayMetrics dm = res.getDisplayMetrics();
            //    res.updateConfiguration(conf, dm);
            //    conf.setLayoutDirection(new Locale(lang));
            return false;
        }

    }

    public ViewPager getViewPager_home() {
        return viewPager_home;
    }

    public void setViewPager_home(ViewPager viewPager_home) {
        this.viewPager_home = viewPager_home;
    }

    public Activity getActivity() {
        return activity;
    }

    public void setActivity(Activity activity) {
        this.activity = activity;
    }

    public static boolean isNetworkAvailable() {
        ConnectivityManager cm = (ConnectivityManager) AppController.getInstance().getContext().getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
        if (null != activeNetwork) {
            if (activeNetwork.getType() == ConnectivityManager.TYPE_WIFI) {
                return true;
            }
            if (activeNetwork.getType() == ConnectivityManager.TYPE_MOBILE) {
                return true;
            }
        }
        return false;
    }
}