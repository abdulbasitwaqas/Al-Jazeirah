package com.appstailors.berain.utils;

import com.appstailors.berain.object.Cart_Params;
import com.appstailors.berain.object.PlaceOrder;
import com.appstailors.berain.object.hyperpayPayment.GetChectoutId;
import com.appstailors.berain.object.request.AddComplaint;
import com.appstailors.berain.object.request.CancelOrderRequest;
import com.appstailors.berain.object.request.Channel;
import com.appstailors.berain.object.request.Check;
import com.appstailors.berain.object.request.CheckOpenOrder;
import com.appstailors.berain.object.request.CheckOut;
import com.appstailors.berain.object.request.CheckOutWithPayment;
import com.appstailors.berain.object.request.CheckOutWithSadadID;
import com.appstailors.berain.object.request.CheckStcRequest;
import com.appstailors.berain.object.request.CheckUserOTP;
import com.appstailors.berain.object.request.CompanySettings;
import com.appstailors.berain.object.request.ComplaintReply;
import com.appstailors.berain.object.request.DeleteAddress;
import com.appstailors.berain.object.request.FavouriteRequest;
import com.appstailors.berain.object.request.ForgetPass;
import com.appstailors.berain.object.request.GetComplaintDetails;
import com.appstailors.berain.object.request.Language;
import com.appstailors.berain.object.request.Login;
import com.appstailors.berain.object.request.LoginRegister;
import com.appstailors.berain.object.request.OrderRequest;
import com.appstailors.berain.object.request.PaymentStatus;
import com.appstailors.berain.object.request.ProductsRequest;
import com.appstailors.berain.object.request.PromocodeRequest;
import com.appstailors.berain.object.request.RegAddress;
import com.appstailors.berain.object.request.Register;
import com.appstailors.berain.object.request.RetingRequest;
import com.appstailors.berain.object.request.TimeSlots;
import com.appstailors.berain.object.request.UpdateProfile;
import com.appstailors.berain.object.request.UpdateProfileWithPass;
import com.appstailors.berain.object.request.UpdateUsername;
import com.appstailors.berain.object.request.VerifyEmailOTP;
import com.appstailors.berain.object.request.WalletRequest;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;
import retrofit2.http.Query;

import static com.appstailors.berain.utils.Constants.ADD_ORDERS_WITH_PAYMENT;
import static com.appstailors.berain.utils.Constants.CANCEL_ORDER;
import static com.appstailors.berain.utils.Constants.CANCEL_ORDER_REASON;
import static com.appstailors.berain.utils.Constants.CHANNELS;
import static com.appstailors.berain.utils.Constants.CHECKUSEROTP;
import static com.appstailors.berain.utils.Constants.CHECK_OPEN_ORDER;
import static com.appstailors.berain.utils.Constants.CITIES;
import static com.appstailors.berain.utils.Constants.CITY_AREA;
import static com.appstailors.berain.utils.Constants.COMPANY_SETTINGS;
import static com.appstailors.berain.utils.Constants.DELETE_ADDRESS;
import static com.appstailors.berain.utils.Constants.FORGET_PASSWORD;
import static com.appstailors.berain.utils.Constants.FORGET_PASSWORD_VERIFY_CODE;
import static com.appstailors.berain.utils.Constants.GET_ADDRESS_GOOGLE;
import static com.appstailors.berain.utils.Constants.GET_CART_PARAMETERS;
import static com.appstailors.berain.utils.Constants.LOGIN;
import static com.appstailors.berain.utils.Constants.LOGINREGISTER;
import static com.appstailors.berain.utils.Constants.MAKE_ORDER_FAV;
import static com.appstailors.berain.utils.Constants.NEW_ADDRESS;
import static com.appstailors.berain.utils.Constants.ORDERS;
import static com.appstailors.berain.utils.Constants.ORDERS_DETAIL;
import static com.appstailors.berain.utils.Constants.PAYMENT;
import static com.appstailors.berain.utils.Constants.PAYMENT_STATUS;
import static com.appstailors.berain.utils.Constants.POPUP_PROMO;
import static com.appstailors.berain.utils.Constants.PROCESS_PY;
import static com.appstailors.berain.utils.Constants.PRODUCTSBYLOCATION;
import static com.appstailors.berain.utils.Constants.REFRESH_TOKEN;
import static com.appstailors.berain.utils.Constants.RESEND_CODE;
import static com.appstailors.berain.utils.Constants.RESET_PASSWORD;
import static com.appstailors.berain.utils.Constants.SAVE_ORDER_RATING;
import static com.appstailors.berain.utils.Constants.SIGNUP;
import static com.appstailors.berain.utils.Constants.SUB_CHANNELS;
import static com.appstailors.berain.utils.Constants.TIME_SLOTS;
import static com.appstailors.berain.utils.Constants.TIPS;
import static com.appstailors.berain.utils.Constants.UPDATEUSERNAME;
import static com.appstailors.berain.utils.Constants.UPDATE_PROFILE;
import static com.appstailors.berain.utils.Constants.VERIFY_ACCOUNT;

import static com.appstailors.berain.utils.Constants.VerifyEmail;
import static com.appstailors.berain.utils.Constants.add_complaint;
import static com.appstailors.berain.utils.Constants.add_complaint_reply;
import static com.appstailors.berain.utils.Constants.complaint_detail;
import static com.appstailors.berain.utils.Constants.get_promo_discount;
import static com.appstailors.berain.utils.Constants.get_wallet_details;

import static com.appstailors.berain.utils.Constants.is_stc_tamayouz_user;
import static com.appstailors.berain.utils.Constants.list_complaints;
import static com.appstailors.berain.utils.Constants.load_complaint_data;
import static com.appstailors.berain.utils.Constants.reversal_stc_tamayouz_discount;
import static com.appstailors.berain.utils.Constants.save_order_new;
import static com.appstailors.berain.utils.Constants.save_temp_order_payment;
import static com.appstailors.berain.utils.Constants.validate_stc_tamayouz_otp;

/**
 * Created by Mustanser Iqbal on 11/24/2017.
 */

public interface APIService {

    @POST(LOGIN)
//    @POST("")
    Call<ResponseBody> login(@Body Login login);

    @POST(LOGINREGISTER)
    Call<ResponseBody> loginRegister(@Body LoginRegister loginRegister);

    @POST(CHECKUSEROTP)
    Call<ResponseBody> checkUserOTP(@Body CheckUserOTP checkUserOTP);

    @POST(VerifyEmail)
    Call<ResponseBody> verifyEmailOTP(@Body VerifyEmailOTP verifyEmailOTP);

    @POST(UPDATEUSERNAME)
    Call<ResponseBody> updateUsername(@Body UpdateUsername updateUsername);

    @POST(FORGET_PASSWORD)
    Call<ResponseBody> sendForgetPassEmail(@Body ForgetPass login);

    @POST(FORGET_PASSWORD_VERIFY_CODE)
    Call<ResponseBody> verifyCodeForgetPassEmail(@Body ForgetPass login);

    /*@POST(FORGET_PASSWORD)
    Call<ResponseBody> sendForgetPassEmail(@Body Login login);*/

    @POST(CITIES)
    Call<ResponseBody> getCities();

    @POST(CITY_AREA)
    Call<ResponseBody> getCityArea();

    @POST(CHANNELS)
    Call<ResponseBody> getChannels(@Body Channel channel);

    @POST(SUB_CHANNELS)
    Call<ResponseBody> getSubChannels(@Body Channel channel);

    @POST(SIGNUP + "/{language}")
    Call<ResponseBody> signUp(@Body Register register, @Path("language") String lang);

    @POST(TIPS)
    Call<ResponseBody> getTips();

    @POST(COMPANY_SETTINGS)
    Call<ResponseBody> getCompanySetting(@Body CompanySettings channel);


    @POST(get_promo_discount)
    Call<ResponseBody> getPromoCode(@Body PromocodeRequest channel);

    @POST(is_stc_tamayouz_user)
    Call<ResponseBody> is_stc_tamayouz_user(@Body CheckStcRequest channel);

    @POST(reversal_stc_tamayouz_discount)
    Call<ResponseBody> reversal_stc_tamayouz_discount(@Body CheckStcRequest channel);

    @POST(validate_stc_tamayouz_otp)
    Call<ResponseBody> validate_stc_tamayouz_otp(@Body PromocodeRequest channel);


    @POST(save_order_new)
    Call<ResponseBody> placeorder(@Body PlaceOrder placeOrder);

    @POST(get_wallet_details )
    Call<ResponseBody> get_wallet_details (@Body WalletRequest placeOrder);

    @POST(list_complaints)
    Call<ResponseBody> get_list_complaints(@Body WalletRequest placeOrder);

    @POST(save_temp_order_payment)
    Call<ResponseBody> save_temp_order_payment(@Body CheckOutWithSadadID placeOrder);

    @POST(load_complaint_data)
    Call<ResponseBody> load_complaint_data(@Body WalletRequest placeOrder);

    @POST(add_complaint)
    Call<ResponseBody> add_complaint(@Body AddComplaint addcomplaint);
    @POST(complaint_detail)
    Call<ResponseBody> complaint_detail(@Body GetComplaintDetails getComplaintDetails);

    @POST(add_complaint_reply)
    Call<ResponseBody> add_complaint_reply(@Body ComplaintReply complaintReply);

    @POST(PRODUCTSBYLOCATION)
    Call<ResponseBody> getProducts(@Body ProductsRequest product);

    @POST(ORDERS)
    Call<ResponseBody> getOrders(@Body OrderRequest request);

    @POST(NEW_ADDRESS)
    Call<ResponseBody> addAddress(@Body RegAddress request);

    @POST(DELETE_ADDRESS)
    Call<ResponseBody> deleteAddress(@Body DeleteAddress deleteAddress);

    @POST(VERIFY_ACCOUNT + "/{id}" + "/{code}" + "/{language}")
    Call<ResponseBody> verifyAccount(@Path("id") String user_id, @Path("code") String code, @Path("language") String language);

    @POST(RESEND_CODE + "{email}")
    Call<ResponseBody> resend_code(@Path("email") String user_id);

    @POST(ORDERS_DETAIL)
    Call<ResponseBody> getOrdersDetail(@Body OrderRequest request);

    @POST(UPDATE_PROFILE)
    Call<ResponseBody> updateProfile(@Body UpdateProfile updateProfile);

    @POST(UPDATE_PROFILE)
    Call<ResponseBody> updateProfileWithPass(@Body UpdateProfileWithPass updateProfile);
    @POST(MAKE_ORDER_FAV)
    Call<ResponseBody> makeOrderFavourite(@Body FavouriteRequest request);

    @POST(SAVE_ORDER_RATING)
    Call<ResponseBody> saveOrderRating(@Body RetingRequest request);
    //    @POST(ADD_ORDERS)
    @POST(ADD_ORDERS_WITH_PAYMENT)
    Call<ResponseBody> checkOut(@Body CheckOut checkOut);

    @POST(save_order_new)
    Call<ResponseBody> checkOutWithCard(@Body CheckOutWithPayment checkOut);

    @POST(save_order_new)
    Call<ResponseBody> checkOutWithSadadId(@Body CheckOutWithSadadID checkOut);

    @POST(PAYMENT_STATUS)
    Call<ResponseBody> getPaymentStatus(@Body PaymentStatus paymentStatus);

    @POST(REFRESH_TOKEN)
//    @POST("1igmzpq1")
    Call<ResponseBody> refreshToken(@Body Check Check);

    @GET("/")
    Call<ResponseBody> getPublicIP();

    @GET(GET_ADDRESS_GOOGLE)
    Call<ResponseBody> getAddressFromGoogle(@Query("latlng") String latlang,
                                            @Query("sensor") boolean sensor, @Query("language") String language, @Query("key") String apiKey);

    @POST(RESET_PASSWORD)
    Call<ResponseBody> resetPassword(@Body ForgetPass login);

    @GET(CANCEL_ORDER_REASON)
    Call<ResponseBody> getCancelOrderReason();

    @POST(CANCEL_ORDER)
    Call<ResponseBody> postCancelOrderReason(@Body CancelOrderRequest cancelOrderRequest);

    @POST(TIME_SLOTS)
    Call<ResponseBody> getTimeSlots(@Body TimeSlots timeSlots);

    @POST(CHECK_OPEN_ORDER)
    Call<ResponseBody> checkOpenOrders(@Body CheckOpenOrder checkOpenOrder);



    @POST(POPUP_PROMO)
    Call<ResponseBody> getPopupPromo(@Body Language lang);

    @POST(GET_CART_PARAMETERS)
    Call<ResponseBody> getCartParameters(@Body Cart_Params params);

    @POST(PROCESS_PY)
    Call<ResponseBody> getCheckoutId(@Body GetChectoutId params);
    @GET(PAYMENT)
    Call<ResponseBody> getPaymentStatus();
}
